#include "peer.h"

void peer_attach(register struct peer *p, register int socket)
{
  peer_zero(p); peer_set(p, socket);
}
