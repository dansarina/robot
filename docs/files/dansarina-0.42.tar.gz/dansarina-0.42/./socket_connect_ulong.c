#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <netinet/in.h>
#include "byte.h"
#include "ndelay.h"
#include "socket.h"

int socket_connect_ulong(int s, unsigned long ip, unsigned int port)
{
  struct sockaddr_in sa; int r;

  byte_zero(&sa, sizeof sa);
  sa.sin_family = AF_INET;
  sa.sin_port = htons(port);
  sa.sin_addr.s_addr = htonl(ip);

  /* byte_copy(&sa.sin_addr.s_addr,sizeof ip,htonl(ip)); */

  if (ndelay_off(s) == -1) return -1;
  r = connect(s, (struct sockaddr *) &sa, sizeof sa);
  if (r == -1) return -1;
  if (ndelay_on(s) == -1) return -1;

  return r;
}
