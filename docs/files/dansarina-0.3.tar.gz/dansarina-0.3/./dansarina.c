/* WARNING: ****************************************
 * This file has been automatically generated. Do  *
 * not edit this file. Edit dansarina.src instead. *
 ***************************************************/
#include <poll.h>  /* poll */
#include <errno.h> /* EINTR */

#include <sys/types.h>  
#include <sys/socket.h>
#include <inttypes.h>   /* integers */
#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>      /* gethostbyname */
#include <stdio.h>      /* perror */
#include <unistd.h>     /* close */
#include <string.h>     /* bzero */
#include <stdio.h>      /* printf */
#include <stdlib.h>     /* malloc */
#include <signal.h>
#include <time.h>

#define fatal9(str) fatal( (str), 9)
#define fatal8(str) fatal( (str), 8)
#define fatal6(str) fatal( (str), 6)
#define fatal2(str) fatal( (str), 2)
#define fatal1(str) fatal( (str), 1)
#define fatal0(str) fatal( (str), 0)

#define out(s) fprintf(irc_out,(s)); fflush(irc_out)

#define RD_SIZE 8192

#define strjoin1(s1) strjoin((s1),0,0,0,0,0)
#define strjoin2(s1,s2) strjoin((s1),(s2),0,0,0,0)
#define strjoin3(s1,s2,s3) \
        strjoin((s1),(s2),(s3),0,0,0)
#define strjoin4(s1,s2,s3,s4) \
        strjoin((s1),(s2),(s3),(s4),0,0)

#define NICKLEN 16 /* RFC says 9 minimum */
#define USERLEN 16 /* RFC says what? */
#define HOSTLEN 64 /* RFC says what? */
#define COMMLEN 32 /* RFC says what? */
#define PARALEN 32 /* RFC says what? */
#define TEXTLEN 512 

#define PASSLEN 8
#define PROFLEN 10

/* 4 spaces + \r\n + end of string = 7 */
#define DB_USER_LEN NICKLEN + USERLEN + \
                    HOSTLEN + PASSLEN + \
                    PROFLEN + 7

#define DB_TOPIC_LEN PARALEN + NICKLEN + \
                     + 512 /* to make sure */
#define LN_SIZE_SAY 72

struct message 
{
  char nick[NICKLEN];
  char user[USERLEN];
  char host[HOSTLEN];
  char para[PARALEN];
  char text[TEXTLEN];
};

/* stores event names and event handlers */
typedef struct 
{
  char *name;
  void  (*f)(register char *buffer);
} com;

struct topic_entry
{
  char channel[PARALEN];
  char nick[NICKLEN];
  time_t time;
  char topic[512];
};

typedef struct list_e_ {
  void *data;
  struct list_e_ *prev;
  struct list_e_ *next;
} list_e;

typedef struct list_ {
  int           size;
  void          (*destroy)(void *data);
  list_e        *head;
  list_e        *tail;
} list;

int telnet_open(char *addr, uint16_t port);

void fatal(char *s, int e);

int poll_wait(struct pollfd *f, unsigned int n);

ssize_t read_once(int f, char *buf, size_t len);

unsigned int how_many_lines(register char *s);

void doit();

char * handle_last_line(register char *buffer, 
                        register char *piece, 
                        unsigned int *len);

void hub_dispatch_event(register char *b);

com *find(register char *event);

void ev_ping(register char *buffer);

void ev_topic(register char *buffer);

void ev_join(register char *buffer);

void do_something(struct message *m);

void ev_quit(register char *buffer);

void ev_part(register char *buffer);

void ev_privmsg(register char *buffer);

void ev_error(register char *buffer);

void parse_common(struct message *m,register char *b);

void line_append(char *path, char *line);

void user_append(struct message *m);

void topic_history(struct message *m);

void get_topic_entry(struct topic_entry *e,
                     char *line);
void topic_append(struct message *m);

int user_exists(struct message *m);

void say_file_to(char *to, char *path);

void say_channel_to(struct message *m,char *msg);

char * strjoin(const char *s1, const char *s2,
               const char *s3, const char *s4,
               const char *s5, const char *s6);

void terminate(int sig);

void quitme();

void list_init(list *_list, 
               void (*destroy)(void *data));

int list_i_next(list *_list, list_e *e, 
                const void *data);

int list_delete(list *_list, list_e *e, 
                void **data);

void list_destroy(list *_list);

int irc_socket; FILE *irc_out; /* output */

/* an array of events and event handlers */
com events[] = 
{
  { "PING",     ev_ping         },
  { "TOPIC",    ev_topic        },
  { "JOIN",     ev_join         },
  { "QUIT",     ev_quit         },
  { "PART",     ev_part         },
  { "PRIVMSG",  ev_privmsg      },
  { "ERROR",    ev_error        },
  { 0,          0               }
};

com *find(register char *event) 
{
  int i;

  for (i=0; events[i].name; ++i)
    if (! strncmp(event, events[i].name, 
          sizeof(events[i].name)))
      return &events[i];

  return 0;
}

int telnet_open(char *addr, uint16_t port)
{ 
  unsigned int s; struct sockaddr_in n; 
  struct hostent *h; int i;

  s = socket(AF_INET,SOCK_STREAM,0);
  if (s < 0) fatal1("telnet_open: cannot "
                    "create socket.\r\n");
  bzero(&n, sizeof(struct sockaddr_in));
  n.sin_family = AF_INET;
  n.sin_port = htons(port);
 
  h = gethostbyname(addr);
  if(!h) 
  {
    close(s);
    fatal1("telnet_open: cannot resolve hostname\r\n");
  }

  bcopy(h->h_addr, &n.sin_addr.s_addr,h->h_length);

  i = connect(s, (struct sockaddr *) &n, 
                 sizeof(struct sockaddr_in));
  if( i < 0 ) 
  {
    close(s);
    perror("telnet_open: connect said: ");
    fatal1("telnet_open: cannot connect "
           "to server\r\n");
  }

  return s;
}

void fatal(char *s, int e) 
{
  fprintf(stderr,"fatal: %s",s); exit(e);
}

int poll_wait(struct pollfd *f, unsigned int n) 
{
  int i;

  again:
  i = poll(f, n, -1);
  if (i < 0) 
  {
    if (errno == EINTR) goto again;
    fatal1("poll_wait: fatal error\n");
  }
  
  return i;
}

ssize_t read_once(int f, char *buf, size_t len) 
{
  ssize_t n;

  read_again:
  n = read(f, buf, len);

  if (n < 0) 
  {
    if (errno == EINTR)
      goto read_again;
    return n;
  }

 if (n == 0)
   return 0;

 buf[n] = 0; /* close for us */
 return n;
}

unsigned int how_many_lines(register char *s) 
{
  register unsigned int c; c = 0;
  while (*s) { if (*s == '\n') ++c; ++s; }
  return c;
}

void doit()
{
  char readbuffer[RD_SIZE]; 

  size_t free_bytes; ssize_t read_bytes; 
  char *position; unsigned int n_lines;
  
  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  free_bytes = RD_SIZE - 1; 
  position = &readbuffer[0];

  buffer_again: 
  read_bytes = read_once(irc_socket, position, free_bytes); 

  if (read_bytes < 0) 
  {
    perror("read_once");
    fatal1("doit: unrecoverable\r\n");
  }

  free_bytes = free_bytes - read_bytes;  

  /* if no whole line was received */
  n_lines = how_many_lines(readbuffer);
  if (n_lines < 1) 
  { 
    position = &readbuffer[0] + read_bytes;

    if( free_bytes <= 0) free_bytes = RD_SIZE - 1;
    goto buffer_again;
  }

  piece = strtok (readbuffer, "\r\n");

  while (piece) 
  {
    if ( n_lines-- <= 0 ) 
    { 
      position = handle_last_line(readbuffer, 
                                  piece, 
                                  &last_len);
      free_bytes = RD_SIZE - 1 - last_len;
      goto buffer_again;
    }
    printf ("### %s\n", piece);
    hub_dispatch_event(piece);
    piece = strtok (NULL, "\r\n");
  }
}
  
char * handle_last_line(register char *buffer, 
                        register char *piece, 
                        unsigned int *len) 
{
   unsigned int slen; register char *new;
   slen = strlen(piece);
  
   /* take a copy, must free */
   new = strjoin1(piece);

   memset(buffer, 0, slen);
   strncpy(buffer, new, slen + 1); free(new);

   *len = slen;
   return buffer + slen;
}

void hub_dispatch_event(register char *b) 
{
  register int i; register char *t;
  char command[COMMLEN]; com *handler;

  t = b; i = 0;

  if( *t == ':') { /* foreign */
      while (*t && *++t != ' ');
      ++t;      
  }

  while( *t && *t != ' ' && i < (COMMLEN - 1)) 
    command[i++] = *t++;
  command[i] = 0;

  /* find handler */
  handler = find(command);

  if( !handler ) {
    printf("--- %s\r\n",b);
    return;
  }

  /* dispatch event */
  (*handler->f)(b);
}

void ev_ping(register char *buffer) 
{
  register char *p; p = buffer;
  while( *p && *p++ != ':');
  printf("+++ PONG :%s\r\n",p);
  fprintf(irc_out,"PONG :%s\r\n",p);
  fflush(irc_out);
}

void ev_topic(register char *buffer) 
{
  struct message m;
  printf("+++ topic: %s\r\n",buffer);
  parse_common(&m,buffer);
  topic_append(&m);
}

void ev_join(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  printf("+++ join: %s\r\n",buffer);

  if ( strncmp(m.host, "64-109-150-120", 14) ) 
    if ( strlen(buffer) % 2 ) 
      do_something(&m);
}

void do_something(struct message *m)
{
  say_channel_to(m,"you look lovely today...\r\n");
}

void ev_quit(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);

  printf("+++ quit: %s\r\n",buffer);
}

void ev_part(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);
  printf("+++ part: %s\r\n",buffer);
}

void ev_privmsg(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  printf("+++ priv: %s @ %s -> %s\r\n",
         m.nick,m.para,m.text);

  /* private commands */
  if ( !strncmp(m.para,"dansarina",9) ) 
  {
    if (!strncmp(m.text,":hello",6) ) 
    {
      user_append(&m);
    }
    /* do not continue */
    return;
  }

  /* public commands */
  if (!strncmp(m.text,":.history topic",15) ) 
  {
    topic_history(&m);
  }

  return;
}

void ev_error(register char *buffer) 
{
  printf("+++ ERR: %s\r\n",buffer);
  fclose(irc_out); exit(1);
}

void parse_common(struct message *m,register char *b) 
{
  register char *p; register int i;

  p = b; ++p; /* skip colon */

  /* load nickname */ i = 0;
  while( *p && *p != '!' && i < (NICKLEN - 1))
    m->nick[i++] = *p++;
  m->nick[i] = 0; while (*p && *p++ != '!');

  /* load username */ i = 0;
  while( *p && *p != '@' && i < (USERLEN - 1))
    m->user[i++] = *p++;
  m->user[i] = 0; while (*p && *p++ != '@');

  /* load hostname */ i = 0;
  while( *p && *p != ' ' && i < (HOSTLEN - 1))
    m->host[i++] = *p++;
  m->host[i] = 0; while (*p && *p++ != ' ');

  /* forward 'til parameter */
  while (*p && *p++ != ' ');

  if (*p == '#' || *p == '&') ++p;

  /* load parameter */ i = 0;
  while( *p && *p != ' ' && i < (PARALEN - 1))
    m->para[i++] = *p++;
  m->para[i] = 0;  while (*p && *++p != ':');

  /* load text */ i = 0;
  while( *p && i < (TEXTLEN - 1))
    m->text[i++] = *p++;
  m->text[i] = 0;
}

void line_append(char *path, char *line) 
{
  FILE *file;
  file = fopen(path,"a");
  if(!file) 
  {
    perror("fopen");
    fatal1("line_append: fopen\r\n");
  }
  fprintf(file,line); fclose(file);
}

void user_append(struct message *m) 
{
  char user[DB_USER_LEN];

  if ( user_exists(m) ) 
  { /* say a few good words */
    say_file_to(m->nick,"./say/hello.say");
    return;
  }

  snprintf(user, DB_USER_LEN, "%s %s %s %s %s\r\n",
           m->nick, "xxxxxxxx", m->user, m->host, "pal");
  line_append("./db/users.db",user);
  say_file_to(m->nick,"./say/newuser.say");
}

void topic_history(struct message *m)
{
  FILE *file; 
  char line[DB_TOPIC_LEN]; 
  char *copy;
  struct topic_entry entry; 
  list topics; 
  list_e *e;
  int i;

  file = fopen("./db/topics.db","r");
  if (!file)
  {
    if (errno == ENOENT)
    {
      say_channel_to(m,"I know nothing about that.");
      return;
    }
    perror("fopen");
    fatal1("topic_history: fopen\r\n");
  }

  say_channel_to(m,"as far as I remember, they were:");
  list_init(&topics, free);

  i = 0;
  while ( fgets(line,DB_TOPIC_LEN,file) )
  { /* load each line on list */
    copy = strjoin1(line);
    if ( list_i_next(&topics, topics.tail, copy) )
      fatal1("topics_history: loading line\r\n");
  }

  fclose(file);

  e = topics.tail;
  while ( e )
  {
    if (++i > 5) break;
    get_topic_entry(&entry,(char*)e->data);
    fprintf(irc_out,"PRIVMSG #%s :By %s @ %s. %s\r\n",
            m->para, entry.nick, "time", entry.topic);
    fflush(irc_out); e = e->prev;
  }

  list_destroy(&topics);
}

void get_topic_entry(struct topic_entry *e,
                     char *line)
{
  register char *p; register int i; char time[30];
  p = line; i = 0; 

  /* load channel */ i = 0;
  while( *p && *p != ' ' && i < (PARALEN - 1))
    e->channel[i++] = *p++;
  e->channel[i] = 0; ++p; /* skip space */

  /* load nick */ i = 0;
  while( *p && *p != ' ' && i < (NICKLEN - 1))
    e->nick[i++] = *p++;
  e->nick[i] = 0; ++p; /* skip space */

  /* load time in time[] */ i = 0;
  while( *p && *p != ' ' && i < 30)
    time[i++] = *p++;
  time[i] = 0; ++p; /* skip space */

  /* skip colon */ ++p;

  /* load topic */ i = 0;
  while( *p && i < (512 - 1))
    e->topic[i++] = *p++;
  e->topic[i] = 0;
}

void topic_append(struct message *m)
{
  char topic[DB_TOPIC_LEN];
  time_t t;

  t = time(NULL);

  snprintf(topic, DB_TOPIC_LEN, "%s %s %ld %s\r\n",
           m->para, m->nick, t, m->text);
  line_append("./db/topics.db",topic);
  say_file_to(m->nick,"./say/newtopic.say");
}

int user_exists(struct message *m) 
{
  FILE *file; char line[DB_USER_LEN];
  char nickname[NICKLEN]; char *pos;

  file = fopen("./db/users.db","r");
  if (!file) 
  {
    if (errno == ENOENT)
    { /* database empty */
      return 0;
    }
    perror("fopen");
    fatal1("user_exists: fopen\r\n");
  }

  while ( fgets(line,DB_USER_LEN,file) )
  {
    pos = index(line,' ');
    if ( pos - line >= USERLEN) 
    {
      fatal2("user_exists: nickname too large\r\n");
    }

    bzero(nickname,NICKLEN);
    strncpy(nickname, line, pos - line);

    if (strlen(nickname) != strlen(m->nick))
    { /* does not match */
      continue;
    }

    if (!strncmp(nickname,m->nick,strlen(m->nick)))
    { /* found match! */
      return 1;
    }
  }

  return 0;
}

void say_file_to(char *to, char *path) 
{
  FILE *file; char line[LN_SIZE_SAY];
  file = fopen(path,"r");

  if(!file)
  {
    perror("fopen");
    fatal1("say_file_to: fopen\r\n");
  }

  while ( fgets(line, LN_SIZE_SAY, file) )
  {
    fprintf(irc_out,"PRIVMSG %s :%s\r\n",to,line);
    fflush(irc_out);
  }

  fclose(file);
}

void say_channel_to(struct message *m,char *msg)
{
  fprintf(irc_out,"PRIVMSG #%s :%s, %s\r\n",
          m->para,m->nick,msg);
  fflush(irc_out);
}

char * strjoin(const char *s1, const char *s2,
               const char *s3, const char *s4,
               const char *s5, const char *s6) 
{
  unsigned int i; register char *j; register char *s;

  if (s1) i  = strlen(s1);
  if (s2) i += strlen(s2);
  if (s3) i += strlen(s3);
  if (s4) i += strlen(s4);
  if (s5) i += strlen(s5);
  if (s6) i += strlen(s6);

  s = malloc(i + 1);
  if (!s) fatal1("strjoin: no malloc, no fun.\n");

  j = s;

  if (s1) 
    while( (*j++ = *s1++) && *s1);
  if (s2)
    while( (*j++ = *s2++) && *s2);
  if (s3)
    while( (*j++ = *s3++) && *s3);
  if (s4)
    while( (*j++ = *s4++) && *s4);
  if (s5)
    while( (*j++ = *s5++) && *s5);
  if (s6)
    while( (*j++ = *s6++) && *s6);

  *j = 0; /* close it */
  return s;
}

void terminate(int sig) 
{
  quitme();
  fclose(irc_out); exit(0);
}

void quitme()
{
  fprintf(irc_out,
  "PRIVMSG #0xff :I'm dying... this sucks.\r\n");
  fprintf(irc_out,
  "QUIT :``To be a rock and not to roll.''\r\n");
}

void list_init(list *_list, 
               void (*destroy)(void *data)) 
{
  _list->size = 0;
  _list->destroy = destroy;
  _list->head = 0;
  _list->tail = 0;
}

int list_i_next(list *_list, list_e *e, 
                const void *data) 
{
  list_e* new;

  /* null only if empty */
  if(!e && _list->size > 0) return -1;

  new = malloc(sizeof(list_e));
  if(!new) return -2;

  new->data = (void*) data;

  if( !_list->size ) 
  {
    /* when list is empty */
    _list->head = new;
    _list->head->prev = 0;
    _list->head->next = 0;
    _list->tail = new;
  }

  else 
  {
    /* when list is nonempty */
    new->next = e->next;
    new->prev = e;

    if (!e->next) { _list->tail = new; }
    else { e->next->prev = new; }

    e->next = new;
  }

  ++_list->size;

  return 0;
}

int list_delete(list *_list, list_e *e, 
                void **data) 
{

  if ( !e || !_list->size)
    return -1;

  *data = e->data;

  if (e == _list->head) 
  {
    /* remove from the head */
    _list->head = e->next;

    if (!_list->head)
      _list->tail = 0;
    else
      e->next->prev = 0;
  }

  else 
  {
    /* remove from somewhere else */
    e->prev->next = e->next;

    if (!e->next)
      _list->tail = e->prev;
    else
      e->next->prev = e->prev;
  }
  free(e);
  --_list->size;

  return 0;
}

#include <string.h> /* bzero */
void list_destroy(list *_list) 
{
  void *data;
  while (_list->size > 0) 
  {
    if (list_delete(_list, _list->tail, 
                    (void **)&data) == 0 &&  
                     _list->destroy) 
    {
      _list->destroy(data);
    }
  }
  bzero(_list, sizeof(_list));
}



int main() 
{
  struct pollfd files[1];

  unsigned int n;

  if ( signal(SIGINT, terminate) == SIG_IGN)
    signal(SIGINT, SIG_IGN);

  if ( signal(SIGHUP, terminate) == SIG_IGN)
    signal(SIGHUP, SIG_IGN);

  if ( signal(SIGTERM, terminate) == SIG_IGN)
    signal(SIGTERM, SIG_IGN);

  irc_socket = telnet_open("irc.dal.net",7000);
  irc_out = fdopen(irc_socket,"w");

  /* XXX: socket could've been closed. broken pipe. */
  out("USER dansarina 3 * :Dansarina\r\n");
  out("NICK dansarina\r\n");
  out("JOIN #0xff\r\n");

  files[0].fd = irc_socket;
  files[0].events = POLLIN;

  for (;;) 
  {
    n = poll_wait(files, 1);

    for (;;) 
    { /* loop through all */
      if (files[0].fd < 0) continue;
      if (files[0].revents & (POLLIN | POLLERR)) 
      {
        doit(); /* buffering */
      }
      if (--n <= 0)
        break; /* no more descriptors */
    }
  }

  _exit(0);
}

