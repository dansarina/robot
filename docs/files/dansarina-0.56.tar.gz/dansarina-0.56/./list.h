#ifndef LIST_H
#define LIST_H

typedef struct list_e_ {
  void *data;
  struct list_e_ *prev;
  struct list_e_ *next;
} list_e;

typedef struct list_ {
  int size;
  void (*destroy)(void *data);
  list_e *head;
  list_e *tail;
} list;

void list_init();
int list_i_next();
int list_delete();
void list_destroy();

#endif
