#include <unistd.h>
#include "io.h"
#include "say.h"
#include "peer.h"
#include "poll.h"
#include "scan.h"
#include "breakup.h"
#include "str.h"
#include "byte.h"
#include "min.h"
#include "sig.h"
#include "strerr.h"
#include "fmt.h"
#include "user.h"
#include "ver.h"
#include "key.h"
#include "list.h"
#include "b64.h"
#include "bnet.h"

extern void *malloc();

/* see dansarina.c */
extern struct peer user[];
extern struct pollfd conn[];
extern int poll_max;
extern char myname[];
extern list robots;
extern list people;

#define die_nomem() strerr_die(6, ERRLINE " -> no memory\n")
#define die_list() strerr_die(7, ERRLINE " -> list error\n")
#define die_inconsistency() strerr_die(8, ERRLINE " -> list inconsistent\n")

void bnet_status()
{
  list_e *e; robot *r; dude *d;

  io_puts(io1, "Robots follow:\n"); io_flush(io1);
  e = robots.head;
  while (e) {
    r = e->data; io_puts(io1, r->name); io_puts(io1, " <- ");
    io_puts(io1, r->from); io_puts(io1, "\n"); io_flush(io1);
    e = e->next;
  }

  io_puts(io1, "Dudes follow:\n"); io_flush(io1);
  e = people.head;
  while (e) {
    d = e->data; io_puts(io1, d->name); io_puts(io1, " @ ");
    io_puts(io1, d->chan); io_puts(io1, " via "); io_puts(io1, d->botn);
    io_puts(io1, " with socket "); io_puts(io1, d->sock); io_puts(io1, "\n");
    io_flush(io1); e = e->next;
  }

}

list_e *bnet_robot_find(char *bot)
{
  list_e *e; robot *r;
  for (e = robots.head; e; e = e->next) {
    r = e->data; if (byte_cmp(r->name, str0_len(r->name), bot)) continue;
    return e;
  }
  return 0;
}

list_e *bnet_dude_find(char *nic, char *bot, char *soc)
{
  list_e *e; dude *d;
  for (e = people.head; e; e = e->next) {
    d = e->data;
    if (byte_cmp(d->botn, str0_len(d->botn), bot)) continue;
    if (byte_cmp(d->name, str0_len(d->name), nic)) continue;
    if (byte_cmp(d->sock, str0_len(d->sock), soc)) continue;
    return e;
  }
  return 0;
}

dude *bnet_dude_add(char *nic, char *bot, char *chn, char *id)
{
  int r; dude *d; 
  d = malloc(sizeof *d); if (!d) die_nomem(); byte_zero(d, sizeof *d);

  byte_copy(d->name, str0_len(nic), nic);
  byte_copy(d->botn, str0_len(bot), bot);
  byte_copy(d->chan, str0_len(chn), chn);
  byte_copy(d->sock, str0_len(id), id);

  r = list_i_next(&people,people.tail,d); if(r == -1) die_list();
  return d;
}

void bnet_udel_bybot(char *bot, char *msg)
{
  list_e *e; dude *d; int q; 

  e = people.head;
  while (e) {
    d = e->data;
    if (byte_cmp(d->botn, str0_len(d->botn), bot)) {e = e->next; continue;}

    say_peer_str7("--- ", d->name, "@", bot ," has left (", msg ,")\r\n");
    q = list_delete(&people, &e); if (q) die_list();
  }
}

void bnet_robot_del(char *bot, char *msg)
{
  list_e *e; robot *r; int q;

  bnet_udel_bybot(bot, msg);
  say_peer_str5("--- Unlink: ", bot, " (", msg, ")\r\n");

  e = robots.head;
  while (e) {
    r = e->data; 
    if (!byte_cmp(bot, str0_len(bot), r->from)) { 
      bnet_robot_del(r->name, msg); break;
    } e = e->next;
  }

  e = bnet_robot_find(bot); if(!e) die_inconsistency();
  q = list_delete(&robots, &e); if (q) die_list();
}

robot *bnet_robot_add(char *bot, char *from)
{
  int r; robot *b;
  b = malloc(sizeof *b); if(!b) die_nomem(); byte_zero(b, sizeof *b);

  byte_copy(b->name, str0_len(bot), bot);
  byte_copy(b->from, str0_len(from), from);
  b->u = 0; b->b = 0;

  r = list_i_next(&robots, robots.tail, b); if (r == -1) die_list();
  return b;
}

void bnet_get_vers(struct peer *p, char *ln) { ; }

void bnet_get_i_am(struct peer *p, char *ln) 
{ 
  if (!peer_STAGE(p, PEER_LINK_RIG)) { 
    say_2peer_str1(p, "bye (So? Who asked you that?)\r\n");
    return;
  }

  say_2peer_str1(p, "users?\r\n");
}

void bnet_get_welcome(struct peer *p, char *ln) 
{
  if (!peer_STAGE(p, PEER_LINK_RIG)) { 
    say_2peer_str1(p, "bye (I'm the one who says welcome here.)\r\n");
    return;
  }

  say_2peer_str1(p, "who-are-you\r\n");
}

void bnet_get_whoareyou(struct peer *p, char *ln)
{
  if (peer_STAGE(p, PEER_BNET_LK1)) {
    bnet_snd_bye(p, "Illegal: who-are-you. You should know."); 
    return;
  }

  say_2peer_str3(p, "i-am ", myname, "\r\n");
}

void bnet_get_version(struct peer *p, char *ln)
{
  if (peer_STAGE(p, PEER_BNET_LK1)) {
    bnet_snd_bye(p, "Illegal: version. Should've asked before."); 
    return;
  }

  say_2peer_str1(p, "vers " VER "\r\n");
}

void bnet_get_nice(struct peer *p, char *ln)
{
  if (!peer_STAGE(p, PEER_LINK_RIG)) {
    say_2peer_str1(p, "users?\r\n");
  }
}

void bnet_end_xfer(struct peer *p, char *ln)
{
  if (peer_STAGE(p, PEER_LINK_RIG)) {
    say_2peer_str1(p, "nice-to-meet-you\r\n");
    p->stage |= PEER_BNET_LK2; 
    bnet_robot_add(p->name, myname);
    say_peer_str5("+++ New link: ", myname, " -> ", p->name, "\r\n");
    return;
  }

/*
  if (!peer_STAGE(p, PEER_LINK_US1)) {
    bnet_snd_bye(p, "Illegal: unexpected dot command."); 
    return;
  }

  if (peer_STAGE(p, PEER_BNET_LK2)) {
    bnet_snd_bye(p, "Illegal: dot command after linking."); 
    return;
  }
*/

  say_2peer_str1(p, "nice-to-meet-you\r\n");
  p->stage |= PEER_BNET_LK2 | PEER_LINK_US1; /* linking done */
  bnet_robot_add(p->name, myname); bnet_snd_link(p);
  say_peer_str5("+++ New link: ", myname, " <- ", p->name, "\r\n");
}

void bnet_snd_link(struct peer *p)
{
  int j; io *s; struct peer *g;

  sig_pipeignore();
  for (j = 2; j <= poll_max; ++j) {
    g = &user[j]; s = &g->ou;

    if (! peer_STAGE(g, PEER_INFO_BOT)) continue;
    if (! peer_STAGE(g, PEER_BNET_LK2)) continue;

    /* skip current bot p */
    if (!byte_cmp(p->name, str0_len(p->name), g->name)) { continue; }
    
    if (! peer_STAGE(g, PEER_LINK_RIG)) {
      io_puts(s, "link "); io_puts(s, myname); io_puts(s, " "); 
      io_puts(s, p->name); io_puts(s, " "); io_puts(s, "\r\n");
      io_flush(s); 
    } else {
      io_puts(s, "link "); io_puts(s, p->name); io_puts(s, " "); 
      io_puts(s, myname); io_puts(s, " "); io_puts(s, "\r\n");
      io_flush(s); 
    }
  } 

  sig_pipedefault();
}

void bnet_snd_users(struct peer *p)
{
  list_e *e; dude *d; robot *r;

  e = people.head;
  while (e) {
    d = e->data;
    if (!byte_cmp(p->name, str0_len(p->name), d->botn)) {
      e = e->next; continue;
    }
    say_2peer_str9(p, "join ", d->botn, "-", d->sock, " ", 
                   d->botn, " party ", d->name, "\r\n");
    e = e->next;
  }

  e = robots.head;
  while (e) {
    r = e->data;
    if (!byte_cmp(p->name, str0_len(p->name), d->botn)) {e = e->next; continue;}
    say_2peer_str5(p, "link ", r->name, " ", r->from, "\r\n");
    e = e->next;
  }
  say_2peer_str1(p, ".\r\n"); 
  p->stage |= PEER_BNET_LK1 | PEER_LINK_US1;
}

void bnet_get_join(struct peer *p, char *ln)
{
  char *s; unsigned int n; char id[NICKLEN+1+8]; char chn[NICKLEN+1];
  char bot[NICKLEN+1]; char nic[NICKLEN+1]; unsigned int len; dude *d;

  byte_zero(bot, sizeof bot); byte_zero(id, sizeof id);
  byte_zero(nic, sizeof nic); byte_zero(chn, sizeof chn);

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(id, min(len,NICKLEN+1+8-1), s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(chn, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(nic, min(len,NICKLEN), s);

  d = bnet_dude_add(nic, bot, chn, id); bnet_snd_join(d);
  say_peer_str5("+++ ",nic,"@",bot," has joined the partyline.\r\n");
}

void bnet_get_who(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char nic[32]; char bot[32]; uint32_t v;

  byte_zero(nic, sizeof nic); byte_zero(bot, sizeof bot);
  s = ln; len = str0_len(s); ++s; ++s; 
  n = scan_uint32(s, &v); s += n + 1; 
  n = byte_ndx(s, v, '@'); if (n == v) bnet_snd_bye(p, "missing @");
  byte_copy(nic, n, s); s += n; byte_copy(bot, v - n, s);

  return; /* not implemented */
}

void bnet_get_unlink(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char gone[NICKLEN+1]; char why[64];

  byte_zero(gone, sizeof gone); byte_zero(why, sizeof why);

  s = ln; len = str0_len(s); 
  n = scan_word(s, len, s); s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(gone, min(len,NICKLEN), s); s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }
  
  n = scan_line(why, min(len,sizeof(why)-1), s); 
  bnet_robot_del(gone, why);
}

void bnet_get_link(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char new[NICKLEN+1]; char hub[NICKLEN+1]; char why[64];

  byte_zero(new, sizeof new); 
  byte_zero(hub, sizeof hub);
  byte_zero(why, sizeof why);

  s = ln; len = str0_len(s);
  n = scan_word(s, len, s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(new, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(hub, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;

  if (*s) {
    n = scan_line(why, min(len,sizeof(why)-1), s); 
    s += n + 1; len -= n + 1;
  }

  bnet_robot_add(new, hub);
  say_peer_str7("+++ New link: ",new," <- thru -> ",hub," (", why, ")\r\n"); 
}

void bnet_get_part(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len; list_e *e; int q;
  char bot[NICKLEN+1]; char nic[NICKLEN+1]; 
  char id[NICKLEN+1+8]; char chn[NICKLEN+1]; char why[LN_SIZE];

  byte_zero(id, sizeof nic);
  byte_zero(bot, sizeof bot); 
  byte_zero(chn, sizeof chn);
  byte_zero(nic, sizeof nic);
  byte_zero(why, sizeof why);
  
  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); /* skip part */
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(id, min(len,NICKLEN+8), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(chn, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(nic, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;

  if (s) { n = scan_line(why, min(len, sizeof(why) - 1), s); }

  e = bnet_dude_find(nic, bot, id); if (!e) die_inconsistency();
  q = list_delete(&people, &e); if (q) die_list();

  say_peer_str7("--- ", nic, "@", bot, " has left (", why, ")\r\n");  
}

void bnet_get_chat(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len; 
  char nic[NICKLEN + 1]; char msg[LN_SIZE]; 
  char bot[NICKLEN + 1]; char chn[NICKLEN + 1]; 

  byte_zero(bot, sizeof bot);
  byte_zero(chn, sizeof chn);
  byte_zero(nic, sizeof nic);
  byte_zero(msg, sizeof msg); 

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); /* skip chat */
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(chn, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_word(nic, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_snd_bye(p, ln); return; }

  n = scan_line(msg, min(len, sizeof(msg) - 1), s); 
  say_peer_str7("<", nic, "@", bot, "> ", msg, "\r\n");
}

void bnet_get_ping(struct peer *p, char *ln)
{
  say_2peer_str1(p, "pong\r\n");
}

void bnet_snd_bye(struct peer *p, char *ln)
{
  bnet_robot_del(p->name, ln);
  say_2peer_str3(p, "bye (", ln, ")\r\n"); peer_detach(p);
}

void bnet_get_bye(struct peer *p, char *ln)
{
  char *s; s = ln; s += 4; s[ str0_len(s) - 1] = 0;
  bnet_robot_del(p->name, s); peer_detach(p);
}

void bnet_snd_part(struct peer *p, char *why) 
{
  int j; io *s; struct peer *g; char soc[8];

  byte_zero(soc, sizeof soc); sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j]; s = &g->ou;
    if (! peer_STAGE(g, PEER_INFO_BOT)) continue;
    if (! peer_STAGE(g, PEER_BNET_LK2)) continue;

    soc [ fmt_uint32(soc,p->poll->fd) ] = 0;

    io_puts(s, "part "); io_puts(s, myname); io_puts(s,"-");
    io_puts(s, soc); io_puts(s, " "); io_puts(s, myname);
    io_puts(s, " party "); io_puts(s, p->name); io_puts(s, " "); 
    io_puts(s, why); io_puts(s,"\n"); io_flush(s);

    s = io1; /* debug */
    io_puts(s, "part "); io_puts(s, myname); io_puts(s,"-");
    io_puts(s, soc); io_puts(s, " "); io_puts(s, myname);
    io_puts(s, " party "); io_puts(s, p->name); io_puts(s, " "); 
    io_puts(s, why); io_puts(s,"\n"); io_flush(s);
  }
  sig_pipedefault();

}

void bnet_snd_join(dude *d)
{
  int j; io *s; struct peer *g;

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j]; s = &g->ou;
    if (! peer_STAGE(g, PEER_INFO_BOT)) continue;
    if (! peer_STAGE(g, PEER_BNET_LK2)) continue;

    io_puts(s, "join "); io_puts(s, myname); io_puts(s,"-");
    io_puts(s, d->sock); io_puts(s, " "); io_puts(s, myname);
    io_puts(s, " party "); io_puts(s, d->name); io_puts(s,"\r\n"); 
    io_flush(s);

    s = io1; /* debug */
    io_puts(s, "join "); io_puts(s, myname); io_puts(s,"-");
    io_puts(s, d->sock); io_puts(s, " "); io_puts(s, myname);
    io_puts(s, " party "); io_puts(s, d->name); io_puts(s,"\r\n"); 
    io_flush(s);
  }
  sig_pipedefault();
}
