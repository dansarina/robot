#ifndef BNET_H
#define BNET_H

typedef struct {
  char name[NICKLEN+1]; 
  char from[NICKLEN+1]; 
  unsigned int u; 
  unsigned int b;
} robot;

typedef struct {
  char botn[NICKLEN+1];
  char name[NICKLEN+1]; 
  char chan[CHANLEN+1]; 
  char sock[NICKLEN+1+8];
} dude;

extern dude *bnet_dude_add();
extern robot *bnet_robot_add();
extern void bnet_status();

extern void bnet_get_i_am();
extern void bnet_get_whoareyou();
extern void bnet_get_version();
extern void bnet_get_nice();
extern void bnet_get_welcome();

extern void bnet_end_xfer();

extern void bnet_snd_users();
extern void bnet_snd_robots();
extern void bnet_snd_bye();
extern void bnet_snd_join();
extern void bnet_snd_part();
extern void bnet_snd_link();

extern void bnet_get_ping();
extern void bnet_get_bye();
extern void bnet_get_chat();
extern void bnet_get_join();
extern void bnet_get_part();
extern void bnet_get_link();
extern void bnet_get_unlink();
extern void bnet_get_who();
extern void bnet_get_idle();

extern void bnet_auth_usr();
extern void bnet_auth_pwd();

extern void bnet_robot_del();

#endif
