#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <inttypes.h>   /* integers       */
#include <stdlib.h>     /* system, malloc */
#include <errno.h>      /* extern errno   */
#include <netinet/in.h> /* sockaddr_in    */
#include <netdb.h>      /* gethostbyname  */
#include <string.h>     /* strlen         */
#include <poll.h>

#define fatal9(str) fatal( (str), 9)
#define fatal8(str) fatal( (str), 8)
#define fatal6(str) fatal( (str), 6)
#define fatal1(str) fatal( (str), 1)
#define fatal0(str) fatal( (str), 0)
#define usage0() usage( (argv[0]))

#define READBUFFER 2048
#define WRITBUFFER 2048

#define strjoin1(s1) \
        strjoin((s1), 0,0,0,0,0)
#define strjoin2(s1,s2) \
        strjoin((s1),(s2),0,0,0,0)
#define strjoin3(s1,s2,s3) \
        strjoin((s1),(s2),(s3),0,0,0)
#define strjoin4(s1,s2,s3,s4) \
        strjoin((s1),(s2),(s3),(s4),0,0)

void fatal(char *s, int e) {
  printf("fatal: %s\n",s);
  exit(e);
}

int telnet(char *addr, uint16_t p) { 
  unsigned int s; struct sockaddr_in n; 
  struct hostent *h; int i;

  s = socket(AF_INET,SOCK_STREAM,0);
  if (s < 0) fatal1("telnet: cannot create socket.\n");
  bzero(&n, sizeof(struct sockaddr_in));
  n.sin_family = AF_INET;
  n.sin_port = htons(p);
 
  h = gethostbyname(addr);
  if(!h) {
    close(s);
    fatal1("telnet: cannot resolve hostname\n");
  }

  bcopy(h->h_addr, &n.sin_addr.s_addr,h->h_length);

  i = connect(s, (struct sockaddr *) &n, 
                 sizeof(struct sockaddr_in));
  if( i < 0 ) {
    close(s);
    perror("telnet: connect said: ");
    fatal1("telnet: cannot connect to server\n");
  }

  return s;
}

int reading(int f, char *buf, int len) {
  int n;

  again:
  n = read(f, buf, len);
  if (n < 0) {
    if (errno == EINTR)
      goto again;
    return -1;
  }

  if (n == 0)
    return 0;

  return n;
}

int writing(int f, char *s, int len) {
  int i;
  
  again:
  i = write(f, s, len);
  if (i < 0)
    return i;
  if (i < len) {
    s = &s[i];
    len = len - i;
    goto again;
  }

  return 0;
}

unsigned int how_many_lines(char *s) {
  unsigned int c;
  c = 0;

  while( *s ) { 
    if (*s == '\n') ++c;
    ++s;
  }
 
  return c;
}

char * strjoin(const char *s1, const char *s2,
               const char *s3, const char *s4,
               const char *s5, const char *s6) {
  int i; char *j, *s;

  if (s1) i  = strlen(s1);
  if (s2) i += strlen(s2);
  if (s3) i += strlen(s3);
  if (s4) i += strlen(s4);
  if (s5) i += strlen(s5);
  if (s6) i += strlen(s6);

  s = malloc(i);
  if (!s) fatal1("strjoin: no malloc, no fun.\n");

  j = s;

  if (s1) 
    while( (*j++ = *s1++) && *s1);
  if (s2)
    while( (*j++ = *s2++) && *s2);
  if (s3)
    while( (*j++ = *s3++) && *s3);
  if (s4)
    while( (*j++ = *s4++) && *s4);
  if (s5)
    while( (*j++ = *s5++) && *s5);
  if (s6)
    while( (*j++ = *s6++) && *s6);

  *j = 0; /* close it */
  return s;
}

char * handle_last_line(char *b, char *p, 
                        unsigned int len) {
   unsigned int n; char *t;

   n = strlen(p);
  
   /* take a copy, must free */
   t = strjoin1(p);

   memset(b, 0, len);
   strncpy(b, t, n + 1); free(t);

   t = b + n;
   return t;
}

int polling(struct pollfd *f, unsigned int n, int t) {
  int i;

  again:
  i = poll(f, n, t);
  if (i < 0) {
    if (errno == EINTR)
      goto again;
    fatal1("polling: got a fatal error\n");
  }
  
  return i;
}


#define NICKLEN 16 /* RFC says 9 minimum */
#define USERLEN 16
#define HOSTLEN 64
#define COMMLEN 32
#define PARALEN 32
#define TEXTLEN 8192

#define FOREIGN 0
#define DOMESTI 1

struct message { 
  char nick[NICKLEN];
  char user[USERLEN];
  char host[HOSTLEN];
  char comm[COMMLEN];
  char para[PARALEN];
  char text[TEXTLEN];
  unsigned int type; /* foreign/domestic */
};

int parsing(char *b, struct message *m) {
  int i;

  memset(m, 0, sizeof (struct message) );
    
  if( *b == ':') {
    m->type = FOREIGN;
    ++b; /* skip colon */
  } else { 
    m->type = DOMESTI;
    goto command;
  }

  i = 0;
  while( *b && *b != '!' && *b != ' ' 
         && i < (NICKLEN - 1)) 
    m->nick[i++] = *b++;
  m->nick[i] = 0;

  while( *b && *b++ != ' ') ;
    /* skip to command */

  command: i = 0;
  while( *b && *b != ' ' && i < (COMMLEN - 1)) 
    m->comm[i++] = *b++;
  m->comm[i] = 0;

  while( *b && *b++ != ' ') ;
    /* skip to parameter */

  i = 0;
  while( *b && *b != ' ' && i < PARALEN) 
    m->para[i++] = *b++;
  m->para[i] = 0;

  while( *b && *b++ != ' ') ;
    /* skip to text */

  ++b; /* skip space-colon */

  i = 0;
  while( *b && i < (TEXTLEN - 1)) 
    m->text[i++] = *b++;
  m->text[i] = 0;

  return 0;
}


int ping(struct message *m) {
  printf("PONG!\n");
  return 0;
}

int topic(struct message *m) {
  printf("### topic changed by %s\r\n", m->nick);
  printf("### topic changed to ``%s''\r\n", m->text);
  return 0;
}


typedef struct {
  char *name;
  int (*f)(struct message *m);
} com;

com comm[] = {
  { "PING",     ping         },
  { "TOPIC",    topic        },
  { 0,          0            }
};

com *find(char *name) {
  int i;

  for (i=0; comm[i].name; ++i)
    if (! strncmp(name, comm[i].name, 
          sizeof(comm[i].name)) )
      return &comm[i];

  return 0;
}


int main(int argc, char **argv) {

  unsigned int s; struct pollfd files[1];
  char readbuffer[READBUFFER]; int n; int c;
  struct message m; char *p, *pos; 
  unsigned int free_bytes; com *command;

  s = telnet("irc.freenode.net",6667);
  
  /* we are connected */

  writing(s, "USER dansarina 3 * :Dansarina\r\n",
      strlen("USER dansarina 3 * :Dansarina\r\n"));

  writing(s, "NICK dansarina\r\n",
      strlen("NICK dansarina\r\n"));

  writing(s, "JOIN #0xff\r\n",
      strlen("JOIN #0xff\r\n"));

  files[0].fd = s;
  files[0].events = (POLLRDNORM);

  for (;;) {
    poll_again:
    n = polling(files, 1, -1);
    
    /* is there something ``nice'' to read from s? */
    if (files[0].revents & (POLLRDNORM | POLLERR)) {

      if (n > 0 ) {
      free_bytes = (sizeof readbuffer) - 1;
      pos = &readbuffer[0];

      buffering: 
        n = reading(s, pos, free_bytes); 
        pos[n] = 0; 

        if (n < 0) {
          perror("reading: ");
          exit(1);
        }

        free_bytes = free_bytes - n;  

        /* if no whole line was received */
        c = how_many_lines(readbuffer);
        if ( c < 1) {

          /* advance buffer by n bytes, 
             and read some more */
          pos = &readbuffer[0] + n;
          goto buffering;
        }

        p = strtok (readbuffer, "\r\n");

        while (p != NULL) {

          if ( c-- <= 0 ) { 
            pos = handle_last_line(readbuffer, p, 
                                   sizeof readbuffer);
            free_bytes = ( (sizeof readbuffer) - 1) - n;
            goto buffering;
          }

          printf ("### %s\n", p); 
          parsing(p, &m);

          if (m.type == FOREIGN) {
	    printf("nick: %s. comm: %s. "
	            "para: %s. text: %s."
	            "\r\n", m.nick, m.comm, 
	            m.para, m.text);
	  }

	  if (m.type == DOMESTI) {
	    printf("comm: %s. para: %s. "
	           "text: %s.\r\n", 
	           m.comm, m.para, m.text);
	  }

	  /* find command record */
	  command = find(m.comm); 
	  if( !command )
	    printf("find: cannot find this command\n");
	  else /* run the function */ 
	  (*command->f)(&m);


          p = strtok (NULL, "\r\n");
        }
        
      }

      if (n < 0) {
        if (errno == ECONNRESET) {
          close(s);
          fatal1("polling: connection reset by peer\n");
        }
      }

      if (n == 0) {
        close(s);
        fatal1("polling: server gave up on us\n");
      }
    }
  }

 
  exit(0);
}

