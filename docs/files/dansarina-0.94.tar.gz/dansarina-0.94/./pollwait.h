#ifndef POLLWAIT_H
#define POLLWAIT_H

#include <poll.h>

#define POLLFD_MAX 20 /* max number of descriptors */

extern int pollwait(struct pollfd *f, unsigned int n);

#endif
