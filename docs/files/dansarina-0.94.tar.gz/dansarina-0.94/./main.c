#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "pollwait.h"
#include "xxx_io.h"
#include "sig.h"
#include "telnet.h"
#include "dcc.h"
#include "fatal.h"

int irc_socket; FILE* irc_out;
int lis_socket;

struct dcc party[POLLFD_MAX]; /* partyline */
struct pollfd files[POLLFD_MAX]; /* poll array */
unsigned short int poll_max; /* max files[] index */

int main() 
{
  unsigned int n; int i; int r; int j; 
  struct sockaddr caddr; socklen_t slen;

  sig_int(); sig_ter(); dcc_init(); /* also initializes pollfd files[] */

  lis_socket = telnet_listen(3333);

  files[0].fd = lis_socket;
  files[0].events = POLLIN;

  /* XXX: it blocks here. please fix it? please? */
  irc_socket = telnet_open("irc.dal.net",7000); 
  irc_out = fdopen(irc_socket,"w");

  files[1].fd = irc_socket; files[1].events = POLLIN; ++poll_max;

  /* XXX: socket could've been closed. ooooo, broken pipe. */
  out("USER me 1 * :/msg dansarina hello\r\n");
  out("NICK dansarina\r\n");
  out("JOIN #0xff\r\n");

  for (;;) 
  {
    n = pollwait(files, poll_max + 1);
    if (files[0].revents & (POLLIN | POLLERR)) 
    { 
      slen = sizeof caddr; 
      r = telnet_accept(files[0].fd, (struct sockaddr*) &caddr, &slen);

      /* place connection */
      for (j=1; j < POLLFD_MAX; ++j) 
      {
        if (files[j].fd < 0) { dcc_plug(j, r); break; }
      }

      if (--n <= 0) /* last socket, so poll again */
        continue;
    }

    /* check if irc server is talking */
    if (files[1].revents & (POLLIN | POLLERR)) 
    { 
      doit(); /* bufferize and answer*/
      if (--n <= 0) /* only one socket was ready */
        continue;
    }

    /* loop through each ready telnet *or* dcc */
    for (i=2; i <= poll_max; ++i)
    {
      if (files[i].revents & (POLLIN | POLLERR)) 
      {
        /* XXX: easy denial of service */
        dcc_buffer(i);
      }
    }
  }
  
  exit(0); /* never */
}
