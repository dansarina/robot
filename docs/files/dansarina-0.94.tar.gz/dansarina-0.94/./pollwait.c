#include <errno.h>
#include "pollwait.h"
#include "fatal.h"

int pollwait(struct pollfd *f, unsigned int n) 
{
  int i;

  again:
  i = poll(f, n, -1);
  if (i < 0) 
  {
    if (errno == EINTR) goto again;
    fatal1("pollwait: fatal error\n");
  }
  
  return i;
}
