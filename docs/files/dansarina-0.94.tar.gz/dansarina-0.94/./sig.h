#ifndef SIG_H
#define SIG_H

#include <signal.h>

extern void sig_int();
extern void sig_hup();
extern void sig_ter();

#endif
