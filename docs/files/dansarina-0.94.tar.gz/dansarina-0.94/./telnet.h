#ifndef TELNET_H
#define TELNET_H

#include <sys/types.h>  /* socket.h wants it */
#include <sys/socket.h> /* socklen_t */

extern unsigned int telnet_open(char *addr, unsigned int port);
extern unsigned int telnet_listen(unsigned int port);
extern unsigned int telnet_accept(int s, struct sockaddr *a, socklen_t *len);
#endif
