#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include "message.h"
#include "handlers.h"
#include "parse.h"
#include "topic.h"
#include "say.h"
#include "user.h"
#include "dcc.h"
#include "telnet.h"
#include "ipnet2dot.h"
#include "pollwait.h" /* for pollfd */

extern FILE* irc_out;
 
/* see main.c for these externs */
extern struct dcc party[];
extern struct pollfd files[];
extern unsigned short int poll_max;

void priv_help(register char *buffer) 
{
  struct message m;
  parse_common(&m,buffer);
  say_file_to(m.nick,"./help/say.help.user");
}

void priv_hello(register char *buffer) 
{
  struct message m;
  parse_common(&m,buffer);
  user_append(&m);
}

void ctcp_chat(register char *buffer) 
{
  struct message m; unsigned int socket;
  char *p; char ip[32]; char pr[8]; char host[256];
  int i; unsigned long ulong_ip; unsigned long port;

  parse_common(&m,buffer);
  printf("+++ chat: %s\r\n",buffer);
  
  p = &m.text[16]; /* advance up to ``ip port'' */

  /* load ip */ i = 0;
  while( *p && *p != ' ' && i < (32 - 1)) 
    ip[i++] = *p++;
  ip[i] = 0; ++p;

  /* load port */ i = 0;
  while( *p && *p != '\1' && i < (8 - 1)) 
    pr[i++] = *p++;
  pr[i] = 0; ++p;

  ulong_ip = strtoul(&ip[0], (char **)0, 10);
  if (ulong_ip == ULONG_MAX && errno == ERANGE) 
    printf("ctcp_chat: malicious user with ip %s\r\n",&ip[0]);

  port = strtol(&pr[0], (char **)0, 10);
  if ( port == ULONG_MAX && errno == ERANGE)
    printf("ctcp_chat: malicious user with port %s\r\n",&pr[0]);

  printf("+++ issuing connect() on %lu at %lu\r\n",ulong_ip,port);
  
  ipnet2dot(&host[0], 255, ulong_ip);
  socket = telnet_open(&host[0],(int)port);

  /* XXX: socket is connected now... it blocked, though *
   * XXX: please fix it. i'm asking you very nicely...  */

  /* XXX: also, that function will exit() if something  *
   * XXX: goes wrong. is that right? do you think that  *
   * XXX: that is right? of course not. please, fix it. */
  
  i = 0; /* store this DCC connection in dccset */
  for (i=2; i < POLLFD_MAX; ++i)
  { /* we must skip the first two slots... */
    if (party[i].fd == -1) 
    {
      files[i].fd = socket;
      files[i].events = POLLIN;
      party[i].fd = socket;
      party[i].out = fdopen(socket, "w"); /* XXX: what if it failed? */
      party[i].ind = i;
      break;
    }
  }

  /* save the highest index */
  if (i > poll_max) poll_max = i;

}

void ctcp_ping(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  fprintf(irc_out,"NOTICE %s :\1PING %s\1\r\n",m.nick,&m.text[6]);
  fflush(irc_out);
}

void ctcp_source(register char *buffer) 
{
  struct message m; 
  char source[] = "Nice! dbast0s@yahoo.com.br";

  parse_common(&m,buffer);
  fprintf(irc_out,"NOTICE %s :\1SOURCE %s\1\r\n",m.nick,source);
  fflush(irc_out);
}

void ctcp_version(register char *buffer) 
{
  struct message m; 
  char version[] = "Dansarina : 0.91 : UNIX";

  parse_common(&m,buffer);
  fprintf(irc_out,"NOTICE %s :\1VERSION %s\1\r\n",m.nick,version);
  fflush(irc_out);
}

void ctcp_finger(register char *buffer) 
{
  struct message m;
  char finger[] = "I'm a dansarina robot. Say hello to me.";

  parse_common(&m,buffer);
  fprintf(irc_out,"NOTICE %s :\1FINGER %s\1\r\n",m.nick,finger);
  fflush(irc_out);
}

void gen_ping(register char *buffer) 
{
  register char *p; p = buffer;
  while( *p && *p++ != ':');
  printf("+++ PONG :%s\r\n",p);
  fprintf(irc_out,"PONG :%s\r\n",p);
  fflush(irc_out);
}

void gen_topic(register char *buffer) 
{
  struct message m;
  printf("+++ topic: %s\r\n",buffer);
  parse_common(&m,buffer);
  topic_append(&m);
}

void gen_join(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  printf("+++ join: %s\r\n",buffer);
}

void gen_quit(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);
  printf("+++ quit: %s\r\n",buffer);
}

void gen_part(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);
  printf("+++ part: %s\r\n",buffer);
}

void gen_privmsg(register char *buffer) 
{
  struct message m;
  parse_common(&m,buffer);
  printf("+++ priv: %s @ %s -> %s\r\n",m.nick,m.para,m.text);
}

void gen_error(register char *buffer) 
{
  printf("+++ ERR: %s\r\n",buffer);
  fclose(irc_out); exit(1);
}

