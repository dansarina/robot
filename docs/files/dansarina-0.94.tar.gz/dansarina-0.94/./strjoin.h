#ifndef STR_H
#define STR_H

char * strjoin(const char *s1, const char *s2, const char *s3, 
               const char *s4, const char *s5, const char *s6);

#define strjoin1(s1) strjoin((s1),0,0,0,0,0)
#define strjoin2(s1,s2) strjoin((s1),(s2),0,0,0,0)
#define strjoin3(s1,s2,s3) strjoin((s1),(s2),(s3),0,0,0)
#define strjoin4(s1,s2,s3,s4) strjoin((s1),(s2),(s3),(s4),0,0)
#define strjoin5(s1,s2,s3,s4,s5) strjoin((s1),(s2),(s3),(s4),(s5),0)

#endif
