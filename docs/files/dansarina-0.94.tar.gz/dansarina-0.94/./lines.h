#ifndef LINES_H
#define LINES_H

unsigned int how_many_lines(register char *s);
void line_append(char *path, char *line);
void line_extract(char *line, char *buffer);

#endif
