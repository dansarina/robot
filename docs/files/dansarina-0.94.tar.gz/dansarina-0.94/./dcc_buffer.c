#include <stdio.h>
#include <string.h>
#include "read_once.h"
#include "dcc_buffer.h"
#include "xxx_io.h"
#include "fatal.h"
#include "lines.h"

int dcc_buffer(unsigned int socket)
{
  char readbuffer[RD_SIZE]; 

  size_t free_bytes; ssize_t read_bytes; 
  char *position; unsigned int n_lines;
  
  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  free_bytes = RD_SIZE - 1; 
  position = &readbuffer[0];

  buffer_again: 
  read_bytes = read_once(socket, position, free_bytes); 

  if (read_bytes < 0) 
  {
    perror("read_once");
    fatal1("dcc_buffer: unrecoverable\r\n");
  }

  if (read_bytes == 0) 
  { /* telnet or dcc has been closed */
    close(socket); return 0;
  }

  free_bytes = free_bytes - read_bytes;  

  /* if no whole line was received */
  n_lines = how_many_lines(readbuffer);
  if (n_lines < 1) 
  { 
    position = &readbuffer[0] + read_bytes;

    if( free_bytes <= 0) free_bytes = RD_SIZE - 1;
    goto buffer_again;
  }

  piece = strtok (readbuffer, "\r\n");

  while (piece) 
  {
    if ( n_lines-- <= 0 ) 
    { 
      position = handle_last_line(readbuffer,piece,&last_len);
      free_bytes = RD_SIZE - 1 - last_len;
      goto buffer_again;
    }
    printf ("### %s\n", piece);
    /* dcc_dispatch_event(piece); */
    piece = strtok (NULL, "\r\n");
  }

  return read_bytes;
}
