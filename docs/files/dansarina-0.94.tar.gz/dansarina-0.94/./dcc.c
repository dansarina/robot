#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include "read_once.h"
#include "fatal.h"
#include "lines.h"
#include "dcc.h"
#include "fatal.h"
#include "pollwait.h" /* for POLLFD_MAX */
#include "xxx_io.h" /* for RD_SIZE */

extern struct dcc party[];
extern struct pollfd files[];
extern unsigned short int poll_max;

#if 0
void dcc_fill_buffer(int i)
{
  ssize_t read_bytes;

  read_bytes = read_once(files[i].fd, party[i].pos, party[i].free); 

  if (read_bytes < 0) { perror("read_once"); fatal(0,1); }
  if (read_bytes == 0) { dcc_unplug(i); return; }

  party[i].free -= read_bytes;
  party[i].pos  += read_bytes;
}

void dcc_process_buffer(int i)
{
  size_t free_bytes; ssize_t read_bytes; 
  char *position; unsigned int n_lines; int k;
  
  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  /* if no whole line was received */
  n_lines = how_many_lines(party[i].buffer);

  if (n_lines < 1) 
  { 
    position = position + read_bytes;

    if( free_bytes <= 0) 
    {
      free_bytes = RD_SIZE - 1;
      memset(&readbuffer[0], 0, RD_SIZE);
    }
    return;
  }

  for (k=0; k < RD_SIZE; ++k)
  {
    if ( !readbuffer[k] ) break;
    if ( readbuffer[k] == '\r' || readbuffer[k] == '\n') continue;
    if ( !isprint(readbuffer[k]) ) readbuffer[k] = '_';
  }

  piece = strtok (party[i].buffer, "\r\n");

  while (piece) 
  {
    if ( n_lines-- <= 0 ) 
    { 
      party[i].pos = handle_last_line(party[i].buffer,piece,&last_len);
      party[i].free = RD_SIZE - 1 - last_len;
      memset(party[i].pos,0,party[i].free);
      return;
    }
    printf ("### %s\n", piece);
    dcc_distribute("@@@ (partyline) @@@ %s\r\n",piece);
    piece = strtok (NULL, "\r\n");
  }

  /* are we at the end ? */
}
#endif

void dcc_plug(int j, int socket)
{
  files[j].fd = socket;
  files[j].events = POLLIN;

  party[j].fd = socket;
  party[j].out = fdopen(socket, "w"); /* XXX: what if NULL? */
  party[j].ind = j;

  /* XXX: what if there's no more slots? */
  if (j == POLLFD_MAX) { fatal1("main: no more slots\r\n"); }
  
  if (j > poll_max) poll_max = j; /* go up the index */
}

void dcc_unplug(int i)
{
  close(files[i].fd);

  files[i].fd = -1; 
  party[i].fd = -1; 
  
  fclose(party[i].out); 
  
  party[i].ind = -1; 
  party[i].pos = 0;
  party[i].free = 8192;
  
  memset(party[i].buffer, 0, 8192);
  
  printf("@@@ DCC quit (someone)\r\n");
  dcc_distribute("@@@ (partyline) @@@ DCC quit (someone)\r\n");
}

void dcc_init()
{
  int i;

  for (i=0; i < POLLFD_MAX; ++i) 
  {
    files[i].fd = -1; 
    files[i].events = 0; 

    party[i].fd = -1; 
  
    party[i].ind = -1; 
    party[i].pos = 0;
    party[i].free = 8192;
    
    memset(party[i].buffer, 0, 8192);
  }
}

void dcc_distribute(const char *fmt, ...)
{
  char *p; va_list ap; int i;

  p = malloc(512); if(!p) fatal1("dcc_distribute: no malloc, no fun\r\n");

  va_start(ap, fmt); vsnprintf(p, 512, fmt, ap); va_end(ap);

  for (i=0; i < POLLFD_MAX; ++i)
  {
    if (party[i].fd != -1) 
    { 
      fprintf(party[i].out,p); fflush(party[i].out); 
    }
    /* XXX: what if someone suddenly closed? pipe okay? */
  }

  free(p);
}

int dcc_buffer(int i) /* i = index in files[] and party[] */
{
  char readbuffer[RD_SIZE]; 

  size_t free_bytes; ssize_t read_bytes; 
  char *position; unsigned int n_lines; int k;
  
  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  free_bytes = RD_SIZE - 1; 
  position = &readbuffer[0];

  buffer_again: 
  read_bytes = read_once(files[i].fd, position, free_bytes); 

  if (read_bytes < 0) 
  {
    perror("read_once");
    fatal1("dcc_buffer: unrecoverable\r\n");
  }

  if (read_bytes == 0) 
  { /* telnet or dcc has been closed */
    printf("!!! DCC says goodbye...\r\n");
    close(files[i].fd); /* close too */
    files[i].fd = -1; party[i].fd = -1; fclose(party[i].out); 
    party[i].ind = -1; return 0;
  }

  free_bytes = free_bytes - read_bytes;  

  /* if no whole line was received */
  n_lines = how_many_lines(readbuffer);
  if (n_lines < 1) 
  { 
    position = position + read_bytes;

    if( free_bytes <= 0) 
    {
      free_bytes = RD_SIZE - 1;
      memset(&readbuffer[0], 0, RD_SIZE);
    }
    goto buffer_again;
  }

  /* trying to avoid problems with the telnet protocol */
  /* i replace every non printable char with _ */
  for (k=0; k < RD_SIZE; ++k)
  {
    if ( !readbuffer[k] ) break;
    if ( readbuffer[k] == '\r' || readbuffer[k] == '\n') continue;
    if ( !isprint(readbuffer[k]) ) readbuffer[k] = '_';
  }

  piece = strtok (readbuffer, "\r\n");

  while (piece) 
  {
    if ( n_lines-- <= 0 ) 
    { 
      position = handle_last_line(readbuffer,piece,&last_len);
      free_bytes = RD_SIZE - 1 - last_len;
      goto buffer_again;
    }
    printf ("### %s\n", piece);
    dcc_distribute("@@@ (partyline) @@@ %s\r\n",piece);
    piece = strtok (NULL, "\r\n");
  }

  return read_bytes;
}
