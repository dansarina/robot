#ifndef DCC_H
#define DCC_H

/* XXX: this function is bad and will die */
int dcc_buffer(int pollindex);

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

/* we will use an array of this thing   *
 * to manage all dcc connections we got */

struct dcc
{
  int fd; 
  FILE* out; /* output buffer */
  int ind; /* index in pollfd files[] */
  char buffer[8192]; /* input buffer */
  size_t free; /* free bytes in buffer[] */
  int pos; /* position of first byte free in buffer[] */
};

void dcc_distribute(const char *fmt, ...);

void dcc_plug(int j, int socket);
void dcc_unplug(int i);
void dcc_init();

void dcc_process_line(int i);

#endif
