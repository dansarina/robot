#include <stdio.h>
#include "lines.h"
#include "fatal.h"

unsigned int how_many_lines(register char *s) 
{
  register unsigned int c; c = 0;
  while (*s) { if (*s == '\n' || *s == '\r') ++c; ++s; }
  return c;
}

void line_append(char *path, char *line) 
{
  FILE *file;
  file = fopen(path,"a");
  if(!file) 
  {
    perror("fopen");
    fatal1("line_append: fopen\r\n");
  }
  fprintf(file,line); fclose(file);
}

#if 0
void line_extract(char *line, char *buffer)
{
}
#endif
