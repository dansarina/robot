#include <stddef.h> /* ssize_t */
#include <unistd.h> /* read */
#include <errno.h>
#include "read_once.h"

ssize_t read_once(int f, char *buf, size_t len) 
{
  ssize_t n;

  read_again:
  n = read(f, buf, len);

  if (n < 0) 
  {
    if (errno == EINTR)
      goto read_again;
    return n;
  }

 if (n == 0)
   return 0;

 buf[n] = 0; /* close for us */
 return n;
}
