#ifndef VER_H
#define VER_H

#define VER "0.57"

#endif
