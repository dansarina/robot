#include "io.h"
#include "fmt.h"
#include "strerr.h"
#include "peer.h"

extern int poll_max;
extern struct peer user[];

void peer_status()
{
  int i; io *s; char bf[32];
  int y, n; int r;
  n = y = 0;

  for (i=0; i < PEERMAX; ++i) { 
    s = &user[i].in; if (s->f == -1) ++n; else ++y; 
  }

  r = fmt_ulong(bf, (unsigned long) y); bf[r]=0;
  io_puts(io1,"*** Connected peers: "); io_puts(io1,bf);
  r = fmt_ulong(bf, (unsigned long) n); bf[r]=0;
  io_puts(io1,". Free slots: "); io_puts(io1,bf); 
  io_puts(io1,"\n"); io_flush(io1);
}
