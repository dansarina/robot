#ifndef BNET_H
#define BNET_H

extern void bnet_get_ping();
extern void bnet_get_bye();
extern void bnet_get_chatter();
extern void bnet_get_join();
extern void bnet_get_part();
extern void bnet_get_link();
extern void bnet_get_unlink();
extern void bnet_get_who();

extern void bnet_send_bye();
extern void bnet_send_el();
extern void bnet_send_join();
extern void bnet_send_priv();

#endif
