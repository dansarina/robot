#include <poll.h>
#include <unistd.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "strerr.h"
#include "breakup.h"
#include "scan.h"
#include "fmt.h"
#include "bnet.h"
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];
extern char myname[];

void peer_auth(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u; struct message m; char *s; unsigned int n; 
  char bf[32]; char fmt[32]; uint32_t v; uint32_t nlength;

  if ( peer_STAGE(p, PEER_CONN_NOT) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if ( peer_STAGE(p, PEER_CONN_PRG) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  ln[--len] = 0; if (!len) return;

  if ( peer_STAGE(p, PEER_LOUT_ELK)) {
    if ( byte_cmp("el", min(2,len), ln) ) return;
    say_2peer_str1(p, "el\r\n"); p->stage &= ~PEER_LOUT_ELK; 
    p->stage |= PEER_INFO_LNK; p->stage |= PEER_AUTH_PWD;
    say_peer_str5("+++ New link: ", myname, " -> ", p->name, "\r\n");
    return;
  }

  if ( peer_STAGE(p, PEER_LOUT_THB)) {
    if ( byte_cmp("tb", min(2,len), ln) ) {
      say_2peer_str1(p, "bye (expected tb command)\r\n");
      peer_detach(p); return;
    }

    s = ln; n = scan_word(s, min(3,len), s); s += n + 1; len -= n + 1;
    if (!len) {
      say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");
      peer_detach(p); return;
    }

    n = scan_word(bf, min(32,len), s); s += n; len -= n; bf[n] = 0;
    
    if ( byte_cmp(bf, n, p->name) ) {
      say_2peer_str1(p, "bye imposter\r\n");
      peer_detach(p); return;
    }

    /* read n, j, i commands; could send some */
    p->stage &= ~PEER_LOUT_THB; p->stage |= PEER_LOUT_ELK; return;
  }

  if ( peer_STAGE(p, PEER_LOUT_VER)) {
    if (! byte_cmp("version", min(7,len), ln) ) {

      s = ln; n = scan_word(s, len, s); s += n + 1; len -= n + 1;
      if (!len) { 
        say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");  
        peer_detach(p); return;
      }

      n = scan_uint32(s, &v); s += n + 1;
    
      if (!n || v != 1061700) {
        say_2peer_str1(p, "bye (unsupported version)\r\n");
        peer_detach(p); return;
      }
    
      p->version = v;
    
      n = scan_uint32(s, &nlength); s += n + 1;

      if (!n || nlength > NICKLEN) {
        say_2peer_str1(p, "bye (unsupported nick length)\r\n");
        peer_detach(p); return;
      }
    
      p->nlength = nlength;

      bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;
      say_2peer_str5(p,"version ", bf," ",fmt," dansarina 0.50 <EFnet>\r\n"); 

      p->stage |= PEER_LOUT_THB; p->stage &= ~PEER_LOUT_VER; return;
    }

    return;
  }
  
  if ( peer_STAGE(p, PEER_LOUT_HEL) ) {
    if (! byte_cmp("passreq", min(7,len), ln) ) {
      if (! user_get(&u, p->name) ) {
        peer_detach(p);
        say_2peer_str1(p, "*** Milkshake on " ERRLINE ". Sorry.\r\n");
        return;
      }

      say_2peer_str2(p, u.pass, "\r\n*hello\r\n");
      p->stage &= ~PEER_LOUT_HEL; p->stage |= PEER_LOUT_VER; return;
    }
    
    return;
  }

  if ( peer_STAGE(p, PEER_LOUT_PWD) ) {
    if (! user_get(&u, p->name) ) {
      peer_detach(p);
      say_2peer_str1(p, "*** Milkshake on " ERRLINE ". Sorry.\r\n");
      return;
    }

    say_2peer_str2(p, u.pass, "\r\n"); 
    p->stage |= PEER_LOUT_HEL;
    return;
  }

  byte_zero(&m, sizeof m); byte_zero(&u, sizeof u);

  if (! peer_STAGE(p, PEER_AUTH_USR) ) {
    byte_copy(m.nick, min(NICKLEN - 1, len), ln);
    byte_copy(p->name, min(NICKLEN - 1, len), ln);
    p->stage |= PEER_AUTH_USR; 

    if (!user_get(&u,m.nick)) {
      say_2peer_str1(p, "I don't know you.\r\n"); peer_detach(p);
      return;
    }

    if ( ! user_has_flag(&u,'b')) return;

    p->stage |= PEER_INFO_BOT;

    /* if (u.pn == 0) { */
      say_2peer_str1(p, "*hello!\r\n");
      p->stage |= PEER_LKIN_HEL | PEER_AUTH_PWD; return;
    /* } */

    return; /* never */
  }

  if (! peer_STAGE(p, PEER_AUTH_PWD) ) {
    byte_copy(m.nick, str0_len(p->name), p->name);
    
    if (!user_get(&u,m.nick)) {
      say_2peer_str1(p, "I don't know you, dude.\r\n"); peer_detach(p);
      return;
    }

    if ( byte_cmp(u.pass, min(u.pn, len - 1), ln) ) { 
      say_2peer_str1(p, "Wrong password. Goodbye.\r\n"); peer_detach(p);
      return;
    }

    p->stage |= PEER_AUTH_PWD; bnet_send_join(p);
    say_peer_str3("+++ New peer. Welcome, ", p->name, ".\r\n");
    return;
  }

  /* bot related only */

  if (! peer_STAGE(p, PEER_LKIN_VER) ) {
    if ( !peer_STAGE(p, PEER_LKIN_HEL) ) 
      strerr_die(1, "Needs VER, but has no HEL" ERRLINE);

    if ( byte_cmp("version", min(7,len), ln) ) {
      say_2peer_str1(p, "bye (expected version command)\r\n"); 
      peer_detach(p); return;
    }
    
    s = ln; n = scan_word(s, len, s); s += n + 1; len -= n + 1;
    if (!len) { 
      say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");  
      peer_detach(p); return;
    }
    n = scan_uint32(s, &v); s += n; ++s;
    
    if (!n || v < 1061700) {
      say_2peer_str1(p, "bye (unsupported version)\r\n");
      peer_detach(p); return;
    }
    
    p->version = v;
    
    n = scan_uint32(s, &nlength); s += n; ++s;

    if (!n || nlength > NICKLEN) {
      say_2peer_str1(p, "bye (unsupported nick length)\r\n");
      peer_detach(p); return;
    }
    
    p->nlength = nlength;

    bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;
    say_2peer_str5(p,"version ", bf," ",fmt," dansarina 0.49 <DAL.net>\r\n");

    p->stage |= PEER_LKIN_VER; 
    return;
  }

  if (! peer_STAGE(p, PEER_LKIN_ELK) ) {
    /* ignore everything, but el */
    if ( byte_cmp("el", min(2,len), ln) ) return;

    p->stage |= PEER_LKIN_ELK | PEER_INFO_LNK; bnet_send_el(p);
    return;
  }

  strerr_die(1, "Wrong algorithm -> " ERRLINE);
}
