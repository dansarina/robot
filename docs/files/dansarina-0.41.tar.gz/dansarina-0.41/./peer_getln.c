#include <errno.h>
#include "peer.h"
#include "io.h"
#include "rw.h"
#include "byte.h"

int peer_getln(struct peer *p, char *ln, int sep)
{
  io *s; int r; int q; int n; char *x;
  s = &p->in; 

  r = peer_feed(p);
  if (r <= 0) return r; /* eof (0) or error (-1) */

  n = byte_ndx(io_peek(s), s->p, sep);

  if (n < r) /* sep found */
  { 
    q = n; if (n > LN_SIZE) q = LN_SIZE; 
    x = io_peek(s); byte_copy(ln, q, x);

    if (q < LN_SIZE) ln[q] = '\n'; 
    io_seek(s, q + 2); /* seek \r\n or \r\0 */
    return q + 1;
  }

  return -2;
}

int peer_feed(struct peer *p) 
{
  int r; io *s; char ln[LN_SIZE]; char *x; char tmp[IO_INSIZE]; 
  s = &p->in;
  
  if (!s->p) return io_feed(s);

  again:
  r = read(s->f, &ln[0], LN_SIZE - s->p);

  if (r < 0) {
    if (errno == EINTR) goto again;
    if (errno == EWOULDBLOCK) ; /* mmm */
    return s->p;
  }

  x = io_peek(s);
  
  /* copy s->p bytes to tmp */
  byte_copy(&tmp[0], s->p, x);
  
  /* copy s->p bytes, r bytes at left */
  byte_copy(x - r, s->p, &tmp[0]);

  /* put r bytes */
  byte_copy(x - r + s->p, r, &ln[0]);

  s->p += r;
  s->n -= r;

  return s->p;
}
