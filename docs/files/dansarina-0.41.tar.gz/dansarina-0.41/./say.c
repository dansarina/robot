#include "peer.h"
#include "strerr.h"
#include "say.h"

extern peer psv;

void say_file_to(char *to, char *path) 
{
  FILE *file; char line[LN_SIZE_SAY];
  file = fopen(path,"r");

  if(!file)
  {
    perror("fopen");
    fatal1("say_file_to: fopen\r\n");
  }

  while ( fgets(line, LN_SIZE_SAY, file) )
  {
    fprintf(irc_out,"PRIVMSG %s :%s\r\n",to,line);
    fflush(irc_out);
  }

  fclose(file);
}

void say_channel_to(struct message *m,char *msg)
{
  fprintf(irc_out,"PRIVMSG #%s :%s, %s\r\n",m->para,m->nick,msg);
  fflush(irc_out);
}
