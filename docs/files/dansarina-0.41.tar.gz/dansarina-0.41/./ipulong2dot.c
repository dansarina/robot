#include "io.h"
#include "ip4.h"

int main() 
{
  unsigned long ul;
  char ipstr[IP4_FMT];

  ul = 1080923768UL;
  ipstr[ip4_fmt(&ipstr[0], (char *) &ul)] = 0;
  io_puts(io1, ipstr); io_puts(io1,"\n"); io_flush(io1);
}
