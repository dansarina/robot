#ifndef STR_H
#define STR_H

extern unsigned int str_len();

#endif
