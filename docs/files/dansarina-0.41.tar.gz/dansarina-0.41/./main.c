#include "io.h"
#include "strerr.h"
#include "socket.h"
#include "pollwait.h"
#include "exit.h"
#include "peer.h"
#include "byte.h"
#include "ndelay.h"
#include "events.h"

int poll_max; 
struct pollfd conn[PEERMAX+1];
struct peer user[PEERMAX];
struct peer psv;

int main()
{
  int sv; int nsocks; int r; int j; int i; int ir; char ln[LN_SIZE]; int len;

  sv = socket_bind_reuse_listen(3333);
  if (sv == -1) strerr_sys(1);

  conn[0].fd = sv; conn[0].events = POLLIN; poll_max = 0;
 
  ir = socket_tcp(); if (ir == -1) strerr_sys(1);

  /* reset all telnet and dcc conections */
  for (j = 2; j < PEERMAX; ++j) conn[j].fd = -1;

  r = socket_connect_host(ir, "irc.dal.net", 6667);
  if (r == -1) strerr_sys(1);

  conn[1].fd = ir; conn[1].events = POLLIN; poll_max = 1;
  peer_attach(&psv, ir);

  /* XXX: temporarily here */
  io_puts(&psv.ou, "USER me 1 * :/msg dansarina hello\r\n");
  io_puts(&psv.ou, "NICK dansarina\r\n");
  io_puts(&psv.ou, "JOIN #0xff\r\n"); io_flush(&psv.ou);

  for (;;)
  {
    nsocks = pollwait(conn, poll_max + 1);

    if (conn[0].revents & (POLLIN | POLLERR)) {
      r = socket_accept(sv); if (r < 0) strerr_sys(2);
      
      /* place connection */
      for (j=2; j < PEERMAX; ++j) 
        if (conn[j].fd < 0) {
          conn[j].fd = r; 
          conn[j].events = POLLIN;

          peer_attach(&user[j], r);
          break;
        }
      
      if (j > poll_max) poll_max = j;
      if (--nsocks <= 0) continue;
    }

    /* irc server only */
    if (conn[1].revents & (POLLIN | POLLERR)) {
      do {
        len = peer_getln(&psv,&ln[0],'\r');
      
        if (len == -2) if (--nsocks <= 0) continue;
        if (len == -1) strerr_sys(3);
        if (len ==  0) strerr_die(2,"server closed\n");
      
        if (!hub_dispatch(ln, len) ) { io_put(io1, ln, len); io_flush(io1); }
      } while (psv.in.p); /* buffer =/= empty */
    }

    /* dcc chats and telnets */
    for (i=2; i <= poll_max; ++i)
      if (conn[i].revents & (POLLIN | POLLERR)) {
        do {
          len = peer_getln(&user[i],&ln[0],'\r');
      
          if (len == -2) { break; }
          if (len == -1) { peer_detach(&user[i]); conn[i].fd = -1; break; }
          if (len ==  0) { peer_detach(&user[i]); conn[i].fd = -1; break; }
      
          io_put(io1, ln, len); io_flush(io1);
        } while (user[i].in.p); /* buffer =/= empty */
      }
    if (--nsocks <= 0) continue;
  }
  
}
