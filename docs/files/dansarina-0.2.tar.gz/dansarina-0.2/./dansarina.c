/* WARNING: ****************************************** 
 *   This file has been automatically generated. Do  *
 *   not edit this file. Edit dansarina.src instead. *
 *****************************************************/
#include <sys/types.h>  
#include <sys/socket.h>
#include <inttypes.h>   /* integers */
#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>      /* gethostbyname */
#include <stdio.h>      /* perror */
#include <unistd.h>     /* close */

#include <stddef.h> /* ssize_t, size_t, et cetera */

#include <poll.h>  /* poll */
#include <errno.h> /* EINTR */

#include <stddef.h> /* ssize_t, size_t, et cetera */

#include <stdio.h>   /* printf, NULL, et cetera */
#include <string.h>  /* strtok */

#include <stdlib.h> /* malloc */

#include <signal.h>

#define fatal9(str) fatal( (str), 9)
#define fatal8(str) fatal( (str), 8)
#define fatal6(str) fatal( (str), 6)
#define fatal1(str) fatal( (str), 1)
#define fatal0(str) fatal( (str), 0)

#define outs(file,str) writing((file),(str),strlen(str))

#define MAX_SOCKETS 255

#define RD_SIZE 512

#define strjoin1(s1) strjoin((s1),0,0,0,0,0)
#define strjoin2(s1,s2) strjoin((s1),(s2),0,0,0,0)
#define strjoin3(s1,s2,s3) strjoin((s1),(s2),(s3),0,0,0)
#define strjoin4(s1,s2,s3,s4) strjoin((s1),(s2),(s3),(s4),0,0)

#define NICKLEN 16 /* RFC says 9 minimum */
#define USERLEN 16 /* RFC says what? */
#define HOSTLEN 64 /* RFC says what? */
#define COMMLEN 32 /* RFC says what? */
#define PARALEN 32 /* RFC says what? */
#define TEXTLEN 512 

#define FOREIGN 0
#define DOMESTIC 1

uint16_t irc_socket; /* socket */

struct message {
  char nick[NICKLEN];
  char user[USERLEN];
  char host[HOSTLEN];
  char para[PARALEN];
  char text[TEXTLEN];
};

/* stores event names and event handlers */
typedef struct {
  char *name;
  void  (*f)(register char *buffer);
} com;

int telnet(char *addr, uint16_t port);

void fatal(char *s, int e);

ssize_t writing(int f, const char *s, size_t len);

int polling(struct pollfd *f, unsigned int n, int t);

int reading(int f, char *buf, size_t len);

uint32_t how_many_lines(register char *s);

char * handle_last_line(register char *buffer, 
                        register char *piece, 
                        unsigned int *len);

void hub_dispatch_event(register char *b);

com *find(register char *event);

void ev_ping(register char *buffer);
void ev_topic(register char *buffer);
void ev_join(register char *buffer);
void ev_quit(register char *buffer);
void ev_part(register char *buffer);
void ev_privmsg(register char *buffer);
void ev_error(register char *buffer);

void say(char *to, char *msg);

void parse_priv_msg(struct message *m,register char *b);

char * strjoin(const char *s1, const char *s2,
               const char *s3, const char *s4,
               const char *s5, const char *s6);

void terminate(int sig);

int telnet(char *addr, uint16_t port) { 
  unsigned int s; struct sockaddr_in n; 
  struct hostent *h; int i;

  s = socket(AF_INET,SOCK_STREAM,0);
  if (s < 0) fatal1("telnet: cannot create socket.\n");
  bzero(&n, sizeof(struct sockaddr_in));
  n.sin_family = AF_INET;
  n.sin_port = htons(port);
 
  h = gethostbyname(addr);
  if(!h) {
    close(s);
    fatal1("telnet: cannot resolve hostname\n");
  }

  bcopy(h->h_addr, &n.sin_addr.s_addr,h->h_length);

  i = connect(s, (struct sockaddr *) &n, 
                 sizeof(struct sockaddr_in));
  if( i < 0 ) {
    close(s);
    perror("telnet: connect said: ");
    fatal1("telnet: cannot connect to server\n");
  }

  return s;
}

void fatal(char *s, int e) {
  printf("fatal: %s\n",s);
  exit(e);
}

ssize_t writing(int f, const char *s, size_t len) {
  ssize_t i;
  
  again:
  i = write(f, s, len);
  if (i < 0)
    return i;
  if (i < len) {
    s = &s[i];
    len = len - i;
    goto again;
  }

  return 0;
}

int polling(struct pollfd *f, unsigned int n, int t) {
  int i;

  again:
  i = poll(f, n, t);
  if (i < 0) {
    if (errno == EINTR)
      goto again;
    fatal1("polling: got a fatal error\n");
  }
  
  return i;
}

int reading(int f, char *buf, size_t len) {
  ssize_t n;

  again:
  n = read(f, buf, len);
  if (n < 0) {
    if (errno == EINTR)
      goto again;
    return -1;
  }

  if (n == 0)
    return 0;

  buf[n] = 0; /* close for us */
  return n;
}

unsigned int how_many_lines(register char *s) {
  register uint32_t c; c = 0;

  while (*s) { if (*s == '\n') ++c; ++s; }
 
  return c;
}

char * handle_last_line(register char *buffer, 
                        register char *piece, 
                        unsigned int *len) {
   unsigned int slen; register char *new;
   slen = strlen(piece);
  
   /* take a copy, must free */
   new = strjoin1(piece);

   memset(buffer, 0, slen);
   strncpy(buffer, new, slen + 1); free(new);

   *len = slen;
   return buffer + slen;
}

void hub_dispatch_event(register char *b) {
  register int i; register char *t;
  char command[COMMLEN]; com *handler;

  t = b; i = 0;

  if( *t == ':') { /* foreign */
      while (*t && *++t != ' ');
      ++t;      
  }

  while( *t && *t != ' ' && i < (COMMLEN - 1)) 
    command[i++] = *t++;
  command[i] = 0;

  /* find handler */
  handler = find(command);

  if( !handler ) {
    printf("--- %s\r\n",b);
    return;
  }

  /* dispatch event */
  (*handler->f)(b);
}

/* an array of events and event handlers */
com events[] = {
  { "PING",     ev_ping         },
  { "TOPIC",    ev_topic        },
  { "JOIN",     ev_join         },
  { "QUIT",     ev_quit         },
  { "PART",     ev_part         },
  { "PRIVMSG",  ev_privmsg      },
  { "ERROR",    ev_error        },
  { 0,          0               }
};

com *find(register char *event) {
  int i;

  for (i=0; events[i].name; ++i)
    if (! strncmp(event, events[i].name, sizeof(events[i].name)) )
      return &events[i];

  return 0;
}

void ev_ping(register char *buffer) {
  register char *p; p = buffer;
  while( *p && *p++ != ':');
  printf("+++ PONG :%s\r\n",p);
  outs(irc_socket,"PONG :irc.freenode.net\r\n");
}

void ev_topic(register char *buffer) {
  printf("+++ topic: %s\r\n",buffer);
  /* outs(irc_socket,"PRIVMSG #0xff :Topic has been logged.\r\n"); */
}

void ev_join(register char *buffer) {
  struct message m; 
  register char *p;
  register int i;

  p = buffer; ++p; 

  /* load nickname */ i = 0;
  while( *p && *p != '!' && i < (NICKLEN - 1))
    m.nick[i++] = *p++;
  m.nick[i] = 0; /* skip delimiter */ ++p; 

  /* load username */ i = 0;
  while( *p && *p != '@' && i < (USERLEN - 1))
    m.user[i++] = *p++;
  m.user[i] = 0; /* skip delimiter */ ++p;

  /* load hostname */ i = 0;
  while( *p && *p != ' ' && i < (HOSTLEN - 1))
    m.host[i++] = *p++;
  m.host[i] = 0; /* skip delimiter */ ++p;

  /* forward 'til message */
  while (*p && *++p != ':'); ++p;

  /* load text */ i = 0;
  while( *p && *p != ' ' && i < (TEXTLEN - 1))
    m.text[i++] = *p++;
  m.text[i] = 0; /* skip delimiter */ ++p;

  printf("+++ join: %s\r\n",buffer);
  if ( strncmp(m.host, "64-109-150-120", 14) )
    outs(irc_socket,"PRIVMSG #0xff :Oh no, not you again...\r\n");
}

void ev_quit(register char *buffer) {
  struct message m; 
  register char *p;
  register int i;

  p = buffer; ++p; 

  /* load nickname */ i = 0;
  while( *p && *p != '!' && i < (NICKLEN - 1))
    m.nick[i++] = *p++;
  m.nick[i] = 0; /* skip delimiter */ ++p; 

  /* load username */ i = 0;
  while( *p && *p != '@' && i < (USERLEN - 1))
    m.user[i++] = *p++;
  m.user[i] = 0; /* skip delimiter */ ++p;

  /* load hostname */ i = 0;
  while( *p && *p != ' ' && i < (HOSTLEN - 1))
    m.host[i++] = *p++;
  m.host[i] = 0; /* skip delimiter */ ++p;

  /* forward 'til message */
  while (*p && *++p != ':'); ++p;

  /* load text */ i = 0;
  while( *p && *p != ' ' && i < (TEXTLEN - 1))
    m.text[i++] = *p++;
  m.text[i] = 0; /* skip delimiter */ ++p;

  printf("+++ quit: %s\r\n",buffer);
  if ( strncmp(m.host, "64-109-150-120", 14) )
    outs(irc_socket,"PRIVMSG #0xff :Thank God!\r\n");
}

void ev_part(register char *buffer) {
  struct message m; 
  register char *p;
  register int i;

  p = buffer; ++p; 

  /* load nickname */ i = 0;
  while( *p && *p != '!' && i < (NICKLEN - 1))
    m.nick[i++] = *p++;
  m.nick[i] = 0; /* skip delimiter */ ++p; 

  /* load username */ i = 0;
  while( *p && *p != '@' && i < (USERLEN - 1))
    m.user[i++] = *p++;
  m.user[i] = 0; /* skip delimiter */ ++p;

  /* load hostname */ i = 0;
  while( *p && *p != ' ' && i < (HOSTLEN - 1))
    m.host[i++] = *p++;
  m.host[i] = 0; /* skip delimiter */ ++p;

  /* forward 'til message */
  while (*p && *++p != ':'); ++p;

  /* load text */ i = 0;
  while( *p && *p != ' ' && i < (TEXTLEN - 1))
    m.text[i++] = *p++;
  m.text[i] = 0; /* skip delimiter */ ++p;

  printf("+++ part: %s\r\n",buffer);
  if ( strncmp(m.host, "64-109-150-120", 14) )
    outs(irc_socket,"PRIVMSG #0xff :Okay, restart the party!\r\n");
}

void ev_privmsg(register char *buffer) {
  struct message m; 
  register char *p;
  register int i;

  parse_priv_msg(&m,buffer);
  printf("+++ priv: %s @ %s -> %s\r\n",
         m.nick,m.para,m.text);

  if ( !strncmp(m.para,"dansarina",9) ) {
    if( !strncmp(m.text,":hello",6) ) {
      say(m.nick, "Hello!\r\n");
    }
  }

  if ( !strncmp(m.text,":dansarina",9) ) {
    if( !strncmp(m.text,":hello",6) ) {
      say(m.nick, "Hello!\r\n");
    }
  }
}

void say(char *to, char *msg) {
   outs(irc_socket, "PRIVMSG ");
   outs(irc_socket, to);
   outs(irc_socket, " :");
   outs(irc_socket, "Hello, ");
   outs(irc_socket, to);
   outs(irc_socket, ".\r\n");
}

void ev_error(register char *buffer) {
  printf("+++ erro: %s\r\n",buffer);
  close(irc_socket); exit(1);
}

void parse_priv_msg(struct message *m,register char *b) {
  register char *p; register int i;

  p = b; ++p; /* skip colon */

  /* load nickname */ i = 0;
  while( *p && *p != '!' && i < (NICKLEN - 1))
    m->nick[i++] = *p++;
  m->nick[i] = 0; while (*p && *p++ != '!');

  /* load username */ i = 0;
  while( *p && *p != '@' && i < (USERLEN - 1))
    m->user[i++] = *p++;
  m->user[i] = 0; while (*p && *p++ != '@');

  /* load hostname */ i = 0;
  while( *p && *p != ' ' && i < (HOSTLEN - 1))
    m->host[i++] = *p++;
  m->host[i] = 0; while (*p && *p++ != ' ');

  /* forward 'til parameter */
  while (*p && *p++ != ' ');

  if (*p == '#' || *p == '&') ++p;

  /* load parameter */ i = 0;
  while( *p && *p != ' ' && i < (PARALEN - 1))
    m->para[i++] = *p++;
  m->para[i] = 0;  while (*p && *++p != ':');

  /* load text */ i = 0;
  while( *p && i < (TEXTLEN - 1))
    m->text[i++] = *p++;
  m->text[i] = 0;

}

char * strjoin(const char *s1, const char *s2,
               const char *s3, const char *s4,
               const char *s5, const char *s6) {
  uint32_t i; register char *j; register char *s;

  if (s1) i  = strlen(s1);
  if (s2) i += strlen(s2);
  if (s3) i += strlen(s3);
  if (s4) i += strlen(s4);
  if (s5) i += strlen(s5);
  if (s6) i += strlen(s6);

  s = malloc(i + 1);
  if (!s) fatal1("strjoin: no malloc, no fun.\n");

  j = s;

  if (s1) 
    while( (*j++ = *s1++) && *s1);
  if (s2)
    while( (*j++ = *s2++) && *s2);
  if (s3)
    while( (*j++ = *s3++) && *s3);
  if (s4)
    while( (*j++ = *s4++) && *s4);
  if (s5)
    while( (*j++ = *s5++) && *s5);
  if (s6)
    while( (*j++ = *s6++) && *s6);

  *j = 0; /* close it */
  return s;
}

void terminate(int sig) {
  outs(irc_socket,"PRIVMSG aFlag :This channel sucks. I'm outa here!\r\n");
  outs(irc_socket,"QUIT :To be a rock and not to roll!\r\n");
  sleep(2); close(irc_socket); sleep(2); _exit(0);
}


int main(int argc, char **argv) {
  struct pollfd files[1];

  uint8_t n; uint8_t i; /* i for loop */

  char readbuffer[RD_SIZE]; 

  size_t free_bytes; ssize_t read_bytes; 
  char *position; uint32_t n_lines;

  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  if ( signal(SIGINT, terminate) == SIG_IGN)
    signal(SIGINT, SIG_IGN);

  if ( signal(SIGHUP, terminate) == SIG_IGN)
    signal(SIGHUP, SIG_IGN);

  if ( signal(SIGTERM, terminate) == SIG_IGN)
    signal(SIGTERM, SIG_IGN);

  irc_socket = telnet("irc.dal.net",7000);

  /* XXX: socket could've been closed. broken pipe. */
  outs(irc_socket, "USER dansarina 3 * :Dansarina\r\n");
  outs(irc_socket, "NICK dansarina\r\n");
  outs(irc_socket, "JOIN #0xff\r\n");

  files[0].fd = irc_socket;
  files[0].events = (POLLIN);

  for (;;) {
    /* polling handles errors */
    n = polling(files, 1, -1);

    for (i=0; i < MAX_SOCKETS; ++i) {
      if (files[i].fd < 0) continue;
    
      /* is there something to read from s? */
      if (files[i].revents & (POLLIN | POLLERR)) {
        free_bytes = RD_SIZE - 1; 
	position = &readbuffer[0];

	buffering: 
	read_bytes = reading(irc_socket, position, free_bytes); 

	if (read_bytes < 0) {
	  perror("reading");
	  exit(1);
	}

	free_bytes = free_bytes - read_bytes;  

	/* if no whole line was received */
	n_lines = how_many_lines(readbuffer);
	if ( n_lines < 1) { 
	  position = &readbuffer[0] + read_bytes;

	  if( free_bytes <= 0) free_bytes = RD_SIZE - 1;
	  goto buffering;
	}

	  piece = strtok (readbuffer, "\r\n");

	  while (piece) {

	    if ( n_lines-- <= 0 ) { 
	      position = handle_last_line(readbuffer, piece, &last_len);
	      free_bytes = RD_SIZE - 1 - last_len;
	      goto buffering;
	    }

	    printf ("### %s\n", piece); 
	    hub_dispatch_event(piece);
	    piece = strtok (NULL, "\r\n");
	  }
	  
      }

      next_socket:
      if (--n <= 0)
        break; /* no more descriptors */
    }
  }


  /* never reached */
  _exit(0);
}

