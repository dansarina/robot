#ifndef RW_H
#define RW_H

#include <unistd.h> /* ssize_t */

extern ssize_t read();
extern ssize_t write();
#endif
