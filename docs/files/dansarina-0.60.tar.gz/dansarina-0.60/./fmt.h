#ifndef FMT_H
#define FMT_H

extern unsigned int fmt_uint64();
extern unsigned int fmt_uint32();
extern unsigned int fmt_int64();
extern unsigned int fmt_int32();
extern unsigned int fmt_ulong();
extern unsigned int fmt_long();

#endif

