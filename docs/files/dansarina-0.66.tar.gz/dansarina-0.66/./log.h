#ifndef LOG_H
#define LOG_H

void logthis(char *s);

#endif
