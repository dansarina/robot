#ifndef GETLN_H
#define GETLN_H

extern int getln();

#endif
