#include <errno.h>
#include "log.h"
#include "strerr.h"
#include "io.h"

#define NULL (void*)0

void logthis(char *s)
{
  io_puts(io1, s); io_flush(io1);
}

void log_strerr_die(int c, char *s)
{
  logthis(s); strerr_die(c, s);
}

void log_strerr_sys(int c, char *s)
{
  io_puts(io1, s); 
  logthis(strerror(errno)); 
  logthis("\n"); 
  strerr_die(c, NULL);
}
