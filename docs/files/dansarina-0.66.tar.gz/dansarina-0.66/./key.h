#ifndef KEY_H
#define KEY_H

void key();

#endif
