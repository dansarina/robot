#ifndef SIG_H
#define SIG_H

extern void sig_catch();
extern void sig_pipeignore();
extern void sig_pipedefault();

#endif
