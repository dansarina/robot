#ifndef PLUGIN_H
#define PLUGIN_H

extern void plugin();
extern unsigned int plugin_exist();
extern int plugin_argv();
extern int plugin_path();
extern void plugin_argv_init();
extern void plugin_argv_done();

#endif
