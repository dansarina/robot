#ifndef LIM_H
#define LIM_H

#define NICKLEN 32
#define CHANLEN 32
#define SERVLEN 64

#define USERLEN 32
#define HOSTLEN 64
#define COMMLEN 32
#define PARALEN 32
#define TEXTLEN 512

#endif
