#ifndef LOG_H
#define LOG_H

void log(char *s);

#endif
