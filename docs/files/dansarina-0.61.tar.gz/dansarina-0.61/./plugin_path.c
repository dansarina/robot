#include <stdio.h>
#include <unistd.h>
#include "str.h"
#include "min.h"
#include "plugin.h"

int plugin_path(char *s, char *path, unsigned int size)
{
  unsigned int n; char file[16]; static str p;

  p.bf = path; p.n = size;
  n = scan_word(file, min(16,str0_len(s)), s); file[n] = 0;

  getcwd(path, size);
  if (str0_len(path) + str0_len("/run/") >= size - n) return -1;

  p.p = str0_len(path); p.n -= p.p;
  
  if (!str_PUTS(&p, "/run/")) return -1;
  if (!str_PUTS(&p, file)) return -1; str_0(&p);

  return 0;
}
