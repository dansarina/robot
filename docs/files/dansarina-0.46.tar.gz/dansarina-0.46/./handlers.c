#include <errno.h>
#include "io.h"
#include "peer.h"
#include "exit.h"
#include "scan.h"
#include "str.h"
#include "socket.h"
#include "pollwait.h"
#include "strerr.h"
#include "breakup.h"
#include "ip4.h"
#include "say.h"
#include "handlers.h"

/* see main.c */
extern struct peer user[];
extern struct pollfd conn[];
extern int poll_max;
extern struct peer rs;

void priv_help(register char *buffer) 
{
  struct message m; breakup(&m, buffer); 
  io_puts(io1, "+++ HELP\n"); io_flush(io1);
  say_file_to(&m, "./help/say.help.user");
}

void priv_hello(register char *buffer) 
{
  struct message m; breakup(&m,buffer);
  io_puts(io1, "+++ HELLO\n"); io_flush(io1);
  say_file_to(&m, "./help/say.hello");
}

void ctcp_chat(register char *buffer) 
{
  struct message m; char *p; int s; int r;
  unsigned long ip; unsigned long pt; int i;
  char ipstr[IP4_FMT];

  breakup(&m,buffer);
  io_puts(io1, "+++ "); io_puts(io1, &m.text[1]); io_flush(io1);

  if (str_len(m.text) < 16) return; p = &m.text[16];
  if ( (i = scan_ulong(p,&ip)) <= 0) return; p += i + 1;
  if ( (i = scan_ulong(p,&pt)) <= 0) return;

  ipstr[ip4_fmt(&ipstr[0], (unsigned char *) &ip)] = 0;

  s = socket_tcp(); if (s == -1) strerr_sys(1);

  r = socket_connect_timeout(s,ipstr,pt,3); 
  if (r == -1) { strerr_sys(1); }
  if (r == -2) { io_puts(io1,"*** Peer timed out\n"); io_flush(io1); return; }

  if (peer_attach(s) == -1) return;
  say_peer_str1("+++ New peer connected (dcc). Welcome, peer.\n"); 
}

void ctcp_ping(register char *buffer) 
{
  struct message m; breakup(&m,buffer);
  io_puts(&rs.ou, "NOTICE ");
  io_puts(&rs.ou, m.nick);
  io_puts(&rs.ou, " :\1PING");
  io_puts(&rs.ou, &m.text[6] );
  io_flush(&rs.ou);

  say_peer_str3("*** Answered PING to ",m.nick,"\n");
}

void ctcp_source(register char *buffer) 
{
  struct message m;
  char src[] = "Nice! Talk to dbast0s@yahoo.com.br";
  breakup(&m,buffer);
  io_puts(&rs.ou, "NOTICE "); io_puts(&rs.ou, m.nick);
  io_puts(&rs.ou, " :\1SOURCE "); io_puts(&rs.ou, src);
  io_puts(&rs.ou, "\1\r\n");
  io_flush(&rs.ou);

  say_peer_str3("*** Answered SOURCE to ",m.nick,"\n");
}

void ctcp_version(register char *buffer) 
{
  struct message m; 
  char ver[] = "dansarina : 0.44 : UNIX";
  breakup(&m,buffer);
  io_puts(&rs.ou, "NOTICE "); io_puts(&rs.ou, m.nick);
  io_puts(&rs.ou, " :\1VERSION "); io_puts(&rs.ou, ver);
  io_puts(&rs.ou, "\1\r\n");
  io_flush(&rs.ou);

  say_peer_str3("*** Answered VERSION to ",m.nick,"\n");
}

void gen_ping(register char *buffer) 
{
  register char *p; p = buffer;
  while( *p && *p++ != ':'); --p;
  io_puts(&rs.ou, "PONG ");
  io_puts(&rs.ou, p);
  io_flush(&rs.ou);

  io_puts(io1, "PING? PONG! ");
  io_puts(io1, p); io_flush(io1);
}

void gen_join(register char *buffer) 
{
  struct message m; breakup(&m,buffer);
  io_puts(io1, "+++ JOIN: "); 
  io_puts(io1, m.nick); io_puts(io1,"@"); io_puts(io1, m.host);
  io_puts(io1, " "); io_puts(io1, m.para); io_flush(io1);
}

void gen_quit(register char *buffer) 
{
  struct message m; breakup(&m, buffer);
  io_puts(io1, "+++ QUIT ");
  io_puts(io1, m.nick); io_puts(io1,"@"); io_puts(io1, m.host);
  io_puts(io1, " "); io_puts(io1, m.text); io_puts(io1, "\n"); 
  io_flush(io1);
}

void gen_part(register char *buffer) 
{
  struct message m; breakup(&m, buffer);
  io_puts(io1, "+++ PART: ");
  io_puts(io1, m.nick); io_puts(io1,"@"); io_puts(io1, m.host);
  io_puts(io1, " :#"); io_puts(io1, m.para); io_puts(io1, "\n"); 
  io_flush(io1);
}

void gen_error(register char *buffer) 
{
  io_puts(io1,"+++ ERR\n"); io_flush(io1);
  _exit(0); /* kernel close them all? */
}
