#ifndef POLLTIMEOUT_H
#define POLLTIMEOUT_H

#include <poll.h>

extern int polltimeout(struct pollfd *f, unsigned int n, unsigned int tm);

#endif
