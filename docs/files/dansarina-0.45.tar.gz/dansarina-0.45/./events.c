#include "io.h"
#include "byte.h"
#include "str.h"
#include "peer.h"
#include "handlers.h"
#include "breakup.h"
#include "events.h"

struct event general[] =
{
  { "PING", gen_ping },
  { "JOIN", gen_join },
  { "QUIT", gen_quit },
  { "PART", gen_part },
  { "ERROR", gen_error },
  { 0, 0 }
};

struct event priv[] = 
{
  { "HELP", priv_help },
  { "HELLO", priv_hello },
  { 0, 0 }
};

struct event ctcp[] = 
{
  { "SOURCE", ctcp_source },
  { "VERSION", ctcp_version },
  { "PING", ctcp_ping }, 
  { "DCCCHAT", ctcp_chat },
 { 0, 0}
};

struct event *find(struct event table[], register char *item)
{
  int i;
  for (i=0; table[i].name; ++i)
    if (!byte_cmp(item, str_len(table[i].name), table[i].name))
      return &table[i]; /* match */
  return 0;
}

/* XXX: this function is wrong and it sucks */
int hub_dispatch(char *buffer, unsigned int len)
{
  int i; char *t; struct event *handler; struct event *table; 
  struct message m; char cmd[COMMLEN]; char ln[LN_SIZE+1];
 
  byte_zero(ln,LN_SIZE+1); 
  byte_copy(ln,len,buffer); 

  t = ln; i = 0;

  if( *t == ':') { /* foreign */
    while (*t && *++t != ' ');
    ++t;
  }

  /* load command */
  while( *t != ' ' && i < (COMMLEN - 1))
    cmd[i++] = *t++;
  cmd[i] = 0;

  /* default table is general */
  table = general;

  if (!byte_cmp(cmd,7,"PRIVMSG")) {
    breakup(&m,ln); t = &m.text[1];
    
    /* XXX: not really the proper way to handle CTCP messages */
    /* XXX: CTCP messages may come ANYWHERE in an IRC message */
    /* XXX: here, we expect it contained in its single line   */

    if (*t == 1) { /* ctcp message */
      i = 0; ++t; table = ctcp;
      while (*t && *t != ' ' && i < (COMMLEN-1))
        cmd[i++] = *t++;
      cmd[i] = 0;

      if (!byte_cmp(cmd,3,"DCC")) { /* append next word */ ++t;
        while (*t && *t != ' ' && i < (COMMLEN - 1 - str_len(cmd)))
          cmd[i++] = *t++;
        cmd[i] = 0;
      }
    }

    else { /* private message */ 
      table = priv; i = 0;
      while( *t && *t != ' ' && i < (COMMLEN - 1))
        cmd[i++] = *t++;
      cmd[i] = 0;

      io_puts(io1, m.nick); io_puts(io1, "@"); io_puts(io1,m.para); 
      io_puts(io1, " -> "); io_puts(io1, m.text); io_flush(io1);
    }
  }

  handler = find(table, cmd); 
  if (!handler) return 0;
  (*handler->f)(ln); return 1;
}
