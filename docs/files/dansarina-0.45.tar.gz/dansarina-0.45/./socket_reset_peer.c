#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include "ip4.h"
#include "byte.h"
#include "strerr.h"
#include "ndelay.h"
#include "socket.h"

void socket_reset_peer(int s, char *host, unsigned int port)
{
  struct sockaddr_in sa; int r;
  struct hostent *h;

  byte_zero(&sa, sizeof sa);
  sa.sin_family = AF_INET;
  sa.sin_port = htons(port);

  if ( (h=gethostbyname(host)) == 0) strerr_sys(1);
  byte_copy(&sa.sin_addr.s_addr,h->h_length,h->h_addr);

  if (ndelay_on(s) == -1) strerr_sys(1);

  r = connect(s, (struct sockaddr *) &sa, sizeof sa);
  if (r == 0) { strerr_die(0,"Too late; localhost?"); }

  if ((errno != EINPROGRESS) && (errno != EWOULDBLOCK)) strerr_sys(1);

  _exit(0);  /* useless, we must use the SO_LINGER option, I guess */ 
}
