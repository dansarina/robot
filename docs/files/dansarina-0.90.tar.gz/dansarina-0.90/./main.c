#include <stdio.h>
#include "pollwait.h"
#include "xxx_io.h"
#include "sig.h"
#include "telnet.h"

int irc_socket; FILE* irc_out;

int main() 
{
  struct pollfd files[1];  unsigned int n;

  sig_int(); sig_ter();

  irc_socket = telnet_open("irc.freenode.net",7000);
  irc_out = fdopen(irc_socket,"w");

  /* XXX: socket could've been closed. broken pipe. */
  out("USER dansarina 3 * :Dansarina\r\n");
  out("NICK dansarina\r\n");
  out("JOIN #0xff\r\n");

  files[0].fd = irc_socket;
  files[0].events = POLLIN;

  for (;;) 
  {
    n = pollwait(files, 1);

    for (;;) 
    { /* loop through all */
      if (files[0].fd < 0) continue;
      if (files[0].revents & (POLLIN | POLLERR)) 
      {
        doit(); /* buffering and events */
      }
      if (--n <= 0)
        break; /* no more descriptors */
    }
  }

  exit(0); /* never */
}

