#include <stdio.h>
#include <stdlib.h>
#include "terminate.h"

extern FILE* irc_out;

void terminate(int sig) 
{
  quitme(); fclose(irc_out); exit(0);
}

void quitme()
{
  fprintf(irc_out,"PRIVMSG #0xff :I'm dying... this sucks.\r\n");
  fprintf(irc_out,"QUIT :``To be a rock and not to roll.''\r\n");
}
