#ifndef TELNET_H
#define TELNET_H

extern int telnet_open(char *addr, unsigned int port);

#endif
