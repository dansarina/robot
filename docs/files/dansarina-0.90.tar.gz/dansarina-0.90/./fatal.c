#include <stdio.h>
#include "fatal.h"

void fatal(char *s, int e) 
{
  fprintf(stderr,"fatal: %s",s); exit(e);
}

