#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>      /* gethostbyname */
#include <unistd.h>     /* close */
#include <string.h>
#include <stdio.h>
#include "fatal.h"
#include "telnet.h"

int telnet_open(char *addr, unsigned int port)
{ 
  unsigned int s; struct sockaddr_in n; 
  struct hostent *h; int i;

  s = socket(AF_INET,SOCK_STREAM,0);
  if (s < 0) fatal1("telnet_open: cannot create socket.\r\n");
  memset(&n, 0, sizeof(struct sockaddr_in));
  n.sin_family = AF_INET;
  n.sin_port = htons(port);
 
  h = gethostbyname(addr);
  if(!h) 
  {
    close(s);
    fatal1("telnet_open: cannot resolve hostname\r\n");
  }

  memcpy(&n.sin_addr.s_addr,h->h_addr,h->h_length);

  i = connect(s, (struct sockaddr *) &n, 
                 sizeof(struct sockaddr_in));
  if( i < 0 ) 
  {
    close(s);
    perror("telnet_open: connect said: ");
    fatal1("telnet_open: cannot connect to server\r\n");
  }

  return s;
}
