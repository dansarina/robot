#ifndef SAY_H
#define SAY_H

#include "message.h"

#define LN_SIZE_SAY 72

extern void say_file_to(char *to, char *path);
extern void say_channel_to(struct message *m,char *msg);

#endif
