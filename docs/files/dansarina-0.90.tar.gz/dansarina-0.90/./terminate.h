#ifndef TERMINATE_H
#define TERMINATE_H

extern void terminate(int sig);
extern void quitme();

#endif
