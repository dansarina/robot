#ifndef EVENTS_H
#define EVENTS_H

#include "message.h"

/* stores event names and event handlers */
typedef struct 
{
  char *name;
  void  (*f)(register char *buffer);
} com;

extern com *find(register char *event);
extern void hub_dispatch_event(register char *b);

#endif
