#include "sig.h"
#include "terminate.h"

void sig_int()
{
  if ( signal(SIGINT, terminate) == SIG_IGN)
    signal(SIGINT, SIG_IGN);
}

void sig_hup() 
{
  if ( signal(SIGHUP, terminate) == SIG_IGN)
    signal(SIGHUP, SIG_IGN);
}

void sig_ter()
{
  if ( signal(SIGTERM, terminate) == SIG_IGN)
    signal(SIGTERM, SIG_IGN);
}
