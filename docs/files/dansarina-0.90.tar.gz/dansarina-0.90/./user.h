#ifndef USER_H
#define USER_H

#include "message.h"
#include "lines.h"

#define PASSLEN 8
#define PROFLEN 10
/* 4 spaces + \r\n + end of string = 7 */
#define DB_USER_LEN NICKLEN + USERLEN + HOSTLEN + PASSLEN + PROFLEN + 7

extern void user_append(struct message *m);
extern int user_exists(struct message *m);

#endif
