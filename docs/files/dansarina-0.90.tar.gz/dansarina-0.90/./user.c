#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "lines.h"
#include "user.h"
#include "say.h"
#include "fatal.h"

void user_append(struct message *m) 
{
  char user[DB_USER_LEN];

  if ( user_exists(m) ) 
  { /* say a few good words */
    say_file_to(m->nick,"./say/hello.say");
    return;
  }

  snprintf(user, DB_USER_LEN, "%s %s %s %s %s\r\n",
           m->nick, "xxxxxxxx", m->user, m->host, "pal");
  line_append("./db/users.db",user);
  say_file_to(m->nick,"./say/newuser.say");
}

int user_exists(struct message *m) 
{
  FILE *file; char line[DB_USER_LEN];
  char nickname[NICKLEN]; char *pos;

  file = fopen("./db/users.db","r");
  if (!file) 
  {
    if (errno == ENOENT)
    { /* database empty */
      return 0;
    }
    perror("fopen");
    fatal1("user_exists: fopen\r\n");
  }

  while ( fgets(line,DB_USER_LEN,file) )
  {
    pos = index(line,' ');
    if ( pos - line >= USERLEN) 
    {
      fatal2("user_exists: nickname too large\r\n");
    }

    memset(nickname,0,NICKLEN);
    strncpy(nickname, line, pos - line);

    if (strlen(nickname) != strlen(m->nick))
    { /* does not match */
      continue;
    }

    if (!strncmp(nickname,m->nick,strlen(m->nick)))
    { /* found match! */
      return 1;
    }
  }

  return 0;
}
