#include <unistd.h>
#include "io.h"
#include "say.h"
#include "peer.h"
#include "poll.h"
#include "scan.h"
#include "breakup.h"
#include "str.h"
#include "byte.h"
#include "min.h"
#include "sig.h"
#include "strerr.h"
#include "fmt.h"
#include "user.h"
#include "ver.h"
#include "key.h"
#include "list.h"
#include "bnet.h"

extern void *malloc();

/* see dansarina.c */
extern struct peer user[];
extern struct pollfd conn[];
extern int poll_max;
extern char myname[];
extern list robots;
extern list people;

#define die_nomem() strerr_die(6, ERRLINE " -> no memory\n")
#define die_list() strerr_die(7, ERRLINE " -> list error\n")
#define die_inconsistency() strerr_die(8, ERRLINE " -> list inconsistent\n")

list_e *bnet_robot_find(char *bot)
{
  list_e *e; robot *r;
  for (e = robots.head; e; e = e->next) {
    r = e->data; if (byte_cmp(r->name, str0_len(r->name), bot)) continue;
    return e;
  }
  return 0;
}

list_e *bnet_dude_find(char *nic, char *bot, char *soc)
{
  list_e *e; dude *d;
  for (e = people.head; e; e = e->next) {
    d = e->data;
    if (byte_cmp(d->botn, str0_len(d->botn), bot)) continue;
    if (byte_cmp(d->name, str0_len(d->name), nic)) continue;
    if (byte_cmp(d->sock, str0_len(d->sock), soc)) continue;
    return e;
  }
  return 0;
}

void bnet_dude_add(char *nic, char *bot, char *chn, char *flag)
{
  int r; dude *d; 
  d = malloc(sizeof *d); if (!d) die_nomem(); byte_zero(d, sizeof *d);

  byte_copy(d->name, str0_len(nic), nic);
  byte_copy(d->botn, str0_len(bot), bot);
  byte_copy(d->chan, str0_len(chn), chn); /* XXX: missing sock */
  d->flag = *flag;

  r = list_i_next(&people,people.tail,d); 
  if(r == -1) die_list();
}

void bnet_robot_del(char *bot, char *msg)
{
  list_e *e; list_e *n; dude *d; robot *r; int q;

  e = people.head;

  while (e) {
    d = e->data;
    if (byte_cmp(d->botn, str0_len(d->botn), bot)) { 
      e = e->next; continue;
    }

    say_peer_str7("--- ", d->name, "@", bot ," has left (", msg ,")\r\n");
    q = list_delete(&people, e, &n); if (q) die_list(); e = n; /* next */
  }

  e = robots.head;
  while (e) {
    r = e->data;
    if (!byte_cmp(bot, str0_len(bot), r->from)) { 
      bnet_robot_del(r->name, msg); break;
    }
    e = e->next;
  }

  e = bnet_robot_find(bot); if(!e) die_inconsistency();
  q = list_delete(&robots, e, &n); if (q) die_list();
  say_peer_str5("--- Unlink: ", bot, " (", msg, ")\r\n");
}

void bnet_robot_add(char *bot, char *from)
{
  int r; robot *b;
  b = malloc(sizeof *b); if(!b) die_nomem(); byte_zero(b, sizeof *b);

  byte_copy(b->name, str0_len(bot), bot);
  byte_copy(b->from, str0_len(from), from);
  b->u = 0; b->b = 0;

  r = list_i_next(&robots, robots.tail, b);
  if (r == -1) die_list();
}

void bnet_lkin_elk(struct peer *p, char *ln, unsigned int len)
{
  ln[--len] = 0; if (!len) return;
  
  if (!byte_cmp("j ", min(2, len), ln)) { bnet_get_join(p, ln); return; }
  if (!byte_cmp("n ", min(2, len), ln)) { bnet_get_link(p, ln); return; }

  if ( byte_cmp("el ", min(3,len), ln)) return;

  p->stage |= PEER_LKIN_ELK | PEER_INFO_LNK; bnet_send_el(p);
  say_peer_str5("+++ New link: ", myname, " <- ", p->name, "\r\n");
  user_save_pass(p->name, str0_len(p->pass), p->pass);
}

void bnet_lkin_ver(struct peer *p, char *ln, unsigned int len)
{
  char bf[32]; uint32_t v; uint32_t nlength; 
  unsigned int n; char *s;  char fmt[32]; char pass[12];

  if ( !peer_STAGE(p, PEER_LKIN_HEL) ) 
    strerr_die(1, "Needs VER, but has no HEL " ERRLINE);

  ln[--len] = 0; if (!len) return;
  if ( byte_cmp("version", min(7,len), ln) ) {
    say_2peer_str1(p, "bye (expected version command)\r\n"); 
    peer_detach(p); return;
  }
    
  s = ln; n = scan_word(s, len, s); s += n + 1; len -= n + 1;
  if (!len) { 
    say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");  
    peer_detach(p); return;
  }
  
  n = scan_uint32(s, &v); s += n; ++s;
  if (!n || v < 1061700) {
    say_2peer_str1(p, "bye (unsupported version)\r\n");
    peer_detach(p); return;
  }
    
  p->version = v;
  n = scan_uint32(s, &nlength); s += n; ++s;
  if (!n || nlength > NICKLEN) {
    say_2peer_str1(p, "bye (unsupported nick length)\r\n");
    peer_detach(p); return;
  }
    
  p->nlength = nlength;
  bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;
  say_2peer_str5(p,"version ", bf," ",fmt," dansarina <DAL.net>\r\n");

  key(&pass, 11); say_2peer_str3(p,"handshake ", pass, "\r\n");
  /* password will be saved only if ``el'' is sent */
  byte_copy(p->pass, 11, pass); p->stage |= PEER_LKIN_VER; 

  bnet_robot_add(p->name, myname);
}

void bnet_lout_elk(struct peer *p, char *ln, unsigned int len)
{
  ln[--len] = 0; if (!len) return;
  if ( byte_cmp("el", min(2,len), ln) ) return;
  say_2peer_str1(p, "el\r\n"); p->stage &= ~PEER_LOUT_ELK; 
  p->stage |= PEER_INFO_LNK | PEER_AUTH_PWD;
  say_peer_str5("+++ New link: ", myname, " -> ", p->name, "\r\n");
}

void bnet_lout_thb(struct peer *p, char *ln, unsigned int len)
{
  char bf[32]; unsigned int n; char *s;

  ln[--len] = 0; if (!len) return; s = ln;

  if (!byte_cmp("handshake ", min(10,len), ln)) {
    s += 10; len -= 10;
    if (!s) {
      say_2peer_str1(p, "bye (handshake syntax error)\r\n");  
      peer_detach(p); return;
    }
    n = scan_word(bf, min(32,len), s); s += n; len -= n; bf[n] = 0;
    user_save_pass(p->name, n, bf); return;
  }

  if ( byte_cmp("tb", min(2,len), ln) ) {
    say_2peer_str1(p, "bye (expected tb command)\r\n");
    peer_detach(p); return;
  }
  
  n = scan_word(s, min(3,len), s); s += n + 1; len -= n + 1;
  if (!len) {
    say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");
    peer_detach(p); return;
  }
  
  n = scan_word(bf, min(32,len), s); s += n; len -= n; bf[n] = 0;
  
  if ( byte_cmp(bf, n, p->name) ) {
    say_2peer_str1(p, "bye imposter\r\n");
    peer_detach(p); return;
  }

  /* read n, j, i commands; could send some */
  p->stage &= ~PEER_LOUT_THB; p->stage |= PEER_LOUT_ELK; 
}

void bnet_lout_ver(struct peer *p, char *ln, unsigned int len)
{
  char bf[32]; uint32_t v; uint32_t nlength; 
  unsigned int n; char *s;  char fmt[32]; 

  ln[--len] = 0; if (!len) return;
  
  if (byte_cmp("version", min(7,len), ln)) return;

  s = ln; n = scan_word(s, len, s); s += n + 1; len -= n + 1;
  if (!len) { 
    say_2peer_str3(p, "bye (syntax error: ", ln, ")\r\n");  
    peer_detach(p); return;
  }

  n = scan_uint32(s, &v); s += n + 1;
    
  if (!n || v != 1061700) {
    say_2peer_str1(p, "bye (unsupported version)\r\n");
    peer_detach(p); return;
  }
    
  p->version = v;
    
  n = scan_uint32(s, &nlength); s += n + 1;
    
  if (!n || nlength > NICKLEN) {
    say_2peer_str1(p, "bye (unsupported nick length)\r\n");
    peer_detach(p); return;
  }
    
  p->nlength = nlength;
    
  bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;
  say_2peer_str5(p,"version ", bf," ",fmt," dansarina " VER " <EFnet>\r\n"); 
    
  p->stage |= PEER_LOUT_THB; p->stage &= ~PEER_LOUT_VER;
}

void bnet_lout_hel(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u;
  ln[--len] = 0; if (!len) return;

  if (! user_get(&u, p->name) ) {
    say_2peer_str1(p, "*** Milkshake on " ERRLINE ". Sorry.\r\n");
    peer_detach(p); return;
  }

  if (!byte_cmp("passreq", min(7,len), ln)) { /* horrible protocol */
    say_2peer_str2(p, u.pwd_1, "\r\n"); 
    p->stage &= ~PEER_LOUT_HEL; p->stage |= PEER_LOUT_VER; return;
  }

  if (!byte_cmp("*hello!", min(7,len), ln)) {
    say_2peer_str1(p, "*hello\r\n");
    p->stage &= ~PEER_LOUT_HEL; p->stage |= PEER_LOUT_VER; return;
  }
}

void bnet_lout_pwd(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u;

  if (! user_get(&u, p->name) ) {
    say_2peer_str1(p, "*** Milkshake on " ERRLINE ". Sorry.\r\n");
    peer_detach(p); return;
  }

  say_2peer_str2(p, u.pwd_1, "\r\n"); p->stage |= PEER_LOUT_HEL;
}

void bnet_get_who(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char nic[32]; char bot[32]; uint32_t v;

  byte_zero(nic, sizeof nic); byte_zero(bot, sizeof bot);
  s = ln; len = str0_len(s); ++s; ++s; 
  n = scan_uint32(s, &v); s += n + 1; 
  n = byte_ndx(s, v, '@'); if (n == v) bnet_send_bye(p, "missing @");
  byte_copy(nic, n, s); s += n; byte_copy(bot, v - n, s);

  return; /* not implemented */
}

void bnet_get_unlink(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char gone[NICKLEN+1]; char why[64];

  byte_zero(gone, sizeof gone); byte_zero(why, sizeof why);

  s = ln; len = str0_len(s); 
  n = scan_word(s, len, s); s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(gone, min(len,NICKLEN), s); s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }
  
  n = scan_line(why, min(len,sizeof(why)-1), s); 
  bnet_robot_del(gone, why);
}

void bnet_get_link(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char new[NICKLEN+1]; char hub[NICKLEN+1]; char why[64];

  byte_zero(new, sizeof new); 
  byte_zero(hub, sizeof hub);
  byte_zero(why, sizeof why);

  s = ln; len = str0_len(s);
  n = scan_word(s, len, s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(new, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(hub, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;

  if (*s) {
    n = scan_line(why, min(len,sizeof(why)-1), s); 
    s += n + 1; len -= n + 1;
  }

  bnet_robot_add(new, hub);
  say_peer_str7("+++ New link: ",new," <- thru -> ",hub," (", why, ")\r\n"); 
}

void bnet_get_part(struct peer *p, char *ln)
{
  char *s; unsigned int n; char sock[8]; char why[LN_SIZE+1];
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len;
  list_e *e; list_e *f; int q;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(why, sizeof why);
  
  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(sock, min(len,8-1), s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_line(why, min(len, LN_SIZE), s);

  e = bnet_dude_find(nick, bot, sock); if (!e) die_inconsistency();
  q = list_delete(&people, e, &f); if (q) die_list();

  say_peer_str7("--- ", nick,"@",bot," has left (", why, ")\r\n");
  
}

void bnet_get_join(struct peer *p, char *ln)
{
  char *s; unsigned int n; char flag; char sock[8]; char chan[8]; 
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len; char *b;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(chan, sizeof chan);

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,8-1), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(chan, min(len,8-1), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(&flag, 1, s); ++s;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(sock, min(len,8-1), s);

  b = bot; if (bot[0] == '!') ++b; /* sigh */
  bnet_dude_add(nick, b, chan, &flag);
  say_peer_str5("+++ ",nick,"@",b," has joined the partyline.\r\n");
}

void bnet_get_chatter(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char nick[2*NICKLEN + 1]; /* u@bot */ char mesg[LN_SIZE];

  byte_zero(mesg, sizeof mesg); 
  byte_zero(nick, sizeof nick);

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,2*NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(s, len, s); 
  s+= n + 1; len -= n +1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_line(mesg, min(len, sizeof(mesg) - 1), s); 
  say_peer_str5("<", nick, "> ", mesg, "\r\n");
}

void bnet_get_ping(struct peer *p, char *ln)
{
  say_2peer_str1(p, "po\r\n");
}

void bnet_send_bye(struct peer *p, char *ln)
{
  say_2peer_str3(p, "bye (", ln, ")\r\n"); peer_detach(p);
}

void bnet_get_bye(struct peer *p, char *ln)
{
  char *s; s = ln; s += 4; s[ str0_len(s) - 1] = 0;
  bnet_robot_del(p->name, s); peer_detach(p);
}

void bnet_send_el(struct peer *p)
{
  int j; io *s; struct peer *g;
  s = &p->ou; /* linking bot's io */

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j];

    if (! peer_STAGE(g, PEER_AUTH_PWD)) continue;
    if (  peer_STAGE(g, PEER_INFO_BOT)) continue;

    io_puts(io1, "j !"); io_puts(io1, myname); io_puts(io1, " "); 
    io_puts(io1, g->name); io_puts(io1, " A @H "); 
    io_puts(io1, p->name); io_puts(io1, "@"); 
    io_puts(io1, myname); io_puts(io1,"\n"); io_flush(io1);

    io_puts(s, "j !"); io_puts(s, myname);  io_puts(s, " "); 
    io_puts(s, g->name); io_puts(s, " A @H "); 
    io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);
  }
  sig_pipedefault();

  say_2peer_str1(p, "el\r\n"); 
}

void bnet_send_join(struct peer *p)
{
  int j; io *s; struct peer *g;

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j]; s = &g->ou;
    if (! peer_STAGE(g, PEER_INFO_BOT)) continue;
    if (! peer_STAGE(g, PEER_INFO_LNK)) continue;

    io_puts(s, "j "); io_puts(s, myname); io_puts(s, " ");
    io_puts(s, p->name); 
    io_puts(s, " A @H "); io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

    s = io1; /* debug */
    io_puts(s, "j "); io_puts(s, myname);  io_puts(s, " ");
    io_puts(s, p->name); 
    io_puts(s, " A @H "); io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

  }
  sig_pipedefault();
}
