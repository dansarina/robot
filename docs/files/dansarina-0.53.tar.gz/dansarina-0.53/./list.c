#include "list.h"

extern void *malloc();
extern void free();

void list_init(list *_list, void (*destroy)(void *data)) 
{
  _list->size = 0; _list->destroy = destroy; _list->head = 0; _list->tail = 0;
}

int list_i_next(list *_list, list_e *e, void *data) 
{
  list_e *new;

  if(!e && _list->size > 0) return -1;

  new = malloc(sizeof *new); if(!new) return -2; 
  new->data = (void*) data;

  if( !_list->size ) {
    /* when list is empty */
    _list->head = new; _list->head->prev = 0; 
    _list->head->next = 0; _list->tail = new;
  }
  else  {
    /* when list is nonempty */
    new->next = e->next; new->prev = e;
    if (!e->next) { _list->tail = new; } else { e->next->prev = new; }
    e->next = new;
  }

  ++_list->size; return 0;
}

int list_delete(list *_list, list_e *e, list_e **r)
{ 
  if ( !e || !_list->size) return -1;

  *r = e->next; free(e->data);

  if (e == _list->head) {
    /* remove from the head */
    _list->head = e->next;

    if (!_list->head) _list->tail = 0; else e->next->prev = 0;
  }

  else {
    /* remove from somewhere else */
    e->prev->next = e->next;
    if (!e->next) _list->tail = e->prev; else e->next->prev = e->prev;
  }

  free(e); --_list->size;
  return 0;
}

void list_destroy(list *_list) 
{
  list_e *n;
  while (_list->size > 0) list_delete(_list, _list->tail, &n);
}
