#include <poll.h>
#include <unistd.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "strerr.h"
#include "breakup.h"
#include "scan.h"
#include "fmt.h"
#include "bnet.h"
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];

void peer_auth(unsigned int i, char *ln, unsigned int len)
{
  struct urecord u; struct message m; char *p; unsigned int n; 
  char bf[32]; char fmt[32]; uint32_t v; uint32_t nlength;

  byte_zero(&m, sizeof m); byte_zero(&u, sizeof u);

  if ( peer_STAGE(user[i], PEER_CONN_NOT) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if ( peer_STAGE(user[i], PEER_CONN_PRG) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if (! peer_STAGE(user[i], PEER_AUTH_USR) ) {
    byte_copy(m.nick, min(NICKLEN - 1, len - 1), ln);
    byte_copy(user[i].name, min(NICKLEN - 1, len - 1), ln);
    user[i].stage |= PEER_AUTH_USR; 

    if (!user_get(&u,m.nick)) {
      say_2peer_str1(&user[i], "I don't know you.\r\n");
      peer_detach(&user[i]);
      return;
    }

    if ( ! user_has_flag(&u,'b')) return;

    user[i].stage |= PEER_INFO_BOT;

    if (u.pn == 0) {
      say_2peer_str1(&user[i], "*hello!\r\n");
      user[i].stage |= PEER_LINK_HEL | PEER_AUTH_PWD; return;
    }

    return; /* never */
  }

  if (! peer_STAGE(user[i], PEER_AUTH_PWD) ) {
    byte_copy(m.nick, str0_len(user[i].name), user[i].name);
    
    if (!user_get(&u,m.nick)) {
      say_2peer_str1(&user[i], "I don't know you, dude.\r\n");
      peer_detach(&user[i]);
      return;
    }

    if ( byte_cmp(u.pass, min(u.pn, len - 1), ln) ) { 
      say_2peer_str1(&user[i], "Wrong password. Goodbye.\r\n");
      peer_detach(&user[i]);
      return;
    }

    user[i].stage |= PEER_AUTH_PWD; bnet_send_join(i);
    say_peer_str3("+++ New peer. Welcome, ", user[i].name, ".\r\n");
    return;
  }

  /* bot related only */

  if (! peer_STAGE(user[i], PEER_LINK_VER) ) {
    if ( !peer_STAGE(user[i], PEER_LINK_HEL) ) 
      strerr_die(1, "Needs VER, but has no HEL" ERRLINE);

    if ( byte_cmp("version", min(7,len), ln) ) {
      say_2peer_str1(&user[i], "bye (expected version command)\r\n");
      peer_detach(&user[i]);
    }
    
    p = ln;

    n = scan_word(bf, 32, p); p += n; ++p;
    n = scan_uint32(p, &v); p += n; ++p;
    
    if (!n || v < 1061700) {
      say_2peer_str1(&user[i], "bye (unsupported version)\r\n");
      peer_detach(&user[i]);
    }
    
    user[i].version = v;
    
    n = scan_uint32(p, &nlength); p += n; ++p;

    if (!n || nlength > NICKLEN) {
      say_2peer_str1(&user[i], "bye (unsupported nick length)\r\n");
      peer_detach(&user[i]);
    }
    
    user[i].nlength = nlength;

    bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;

    say_2peer_str5(&user[i], "version ", bf, " ", fmt, 
                   " dansarina 0.49 <DAL.net>\r\n");    

    user[i].stage |= PEER_LINK_VER; 
    return;
  }

  if (! peer_STAGE(user[i], PEER_LINK_ELK) ) {
    /* ignore everything, but el */
    if ( byte_cmp("el", min(2,len), ln) ) return;

    user[i].stage |= PEER_LINK_ELK; bnet_send_el(i);
    return;
  }

  strerr_die(1, "Wrong algorithm -> " ERRLINE);
}
