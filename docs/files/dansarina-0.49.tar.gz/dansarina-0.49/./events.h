#ifndef EVENTS_H
#define EVENTS_H

struct event { 
  char *name;
  void (*f)();
};

extern int hub_dispatch();
extern int bnt_dispatch();

#endif
