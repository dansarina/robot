#ifndef POLL_H
#define POLL_H

#include <poll.h>

extern int pollwait();
extern int polltimeout();

#endif
