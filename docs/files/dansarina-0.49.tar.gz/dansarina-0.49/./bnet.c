#include <unistd.h>
#include "io.h"
#include "say.h"
#include "peer.h"
#include "poll.h"
#include "scan.h"
#include "breakup.h"
#include "str.h"
#include "byte.h"
#include "min.h"
#include "sig.h"
#include "bnet.h"

/* see dansarina.c */
extern struct peer user[];
extern struct pollfd conn[];
extern int poll_max;
extern char myname[];

void bnet_get_unlink(int i, char *ln)
{
  char *p; unsigned int n; unsigned int len;
  char gone[NICKLEN+1]; char why[64];

  byte_zero(gone, sizeof gone); byte_zero(why, sizeof why);

  p = ln; len = str0_len(p);
  n = scan_word(p, len, p);
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(gone, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }
  
  n = scan_line(why, min(len,sizeof(why)-1), p);

  say_peer_str7("--- Unlink: ", gone, " from ", user[i].name, 
                " (", why, ")\r\n");
}

void bnet_get_link(int i, char *ln)
{
  char *p; unsigned int n; unsigned int len;
  char new[NICKLEN+1]; char hub[NICKLEN+1]; char why[64];

  byte_zero(new, sizeof new); 
  byte_zero(hub, sizeof hub);
  byte_zero(why, sizeof why);

  p = ln; len = str0_len(p);
  n = scan_word(p, len, p);
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(new, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(hub, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;

  if (*p) {
    n = scan_line(why, min(len,sizeof(why)-1), p); 
    p += n + 1; len -= n + 1;
  }

  say_peer_str7("+++ New link: ", new, " <- thru -> ", 
                hub, " (", why, ")\r\n"); 
}

void bnet_get_part(int i, char *ln)
{
  char *p; unsigned int n; char sock[8]; char why[LN_SIZE+1];
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(why, sizeof why);
  
  p = ln; len = str0_len(p);

  n = scan_word(p, len, p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(nick, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(sock, min(len,8-1), p);
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_line(why, min(len, LN_SIZE), p);

  say_peer_str7("--- ", nick, "@", bot, " has left (", why, ")\r\n");
  
}

void bnet_get_join(int i, char *ln)
{
  char *p; unsigned int n; char flag; char sock[8]; char chan[8]; 
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(chan, sizeof chan);

  p = ln; len = str0_len(p);

  n = scan_word(p, len, p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(nick, min(len,8-1), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(chan, min(len,8-1), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(&flag, 1, p); ++p;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(sock, min(len,8-1), p);

  say_peer_str5("+++ ", nick, "@", bot, " has joined the partyline.\r\n");
}

void bnet_get_chatter(int i, char *ln)
{
  char *p; unsigned int n; unsigned int len;
  char nick[2*NICKLEN + 1]; /* u@bot */ char mesg[LN_SIZE];

  byte_zero(mesg, sizeof mesg); 
  byte_zero(nick, sizeof nick);

  p = ln; len = str0_len(p);

  n = scan_word(p, len, p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(nick, min(len,2*NICKLEN), p); 
  p += n + 1; len -= n + 1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_word(p, len, p); 
  p+= n + 1; len -= n +1;
  if (!*p) { bnet_send_bye(i, ln); return; }

  n = scan_line(mesg, min(len, sizeof(mesg) - 1), p); 
  say_peer_str5("<", nick, "> ", mesg, "\r\n");
}

void bnet_get_ping(int i, char *ln)
{
  io_puts(io1, "("); io_puts(io1, user[i].name); io_puts(io1, ") ");
  io_puts(io1, "pi? po! \n"); io_flush(io1);
  say_2peer_str1(&user[i], "po\r\n");
}

void bnet_send_bye(int i, char *ln)
{
  say_2peer_str3(&user[i], "bye (", ln, ")\r\n");
  peer_detach(&user[i]);
}

void bnet_get_bye(int i, char *ln)
{
  io_puts(io1, "Botnet: bye from "); 
  io_puts(io1, user[i].name); io_puts(io1, "\n");
  io_flush(io1);

  peer_detach(&user[i]);
}

void bnet_send_el(int i)
{
  int j; io *s;

  s = &user[i].ou; /* linking bot's io */

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    if (! peer_STAGE(user[j], PEER_AUTH_PWD)) continue;
    if (  peer_STAGE(user[j], PEER_INFO_BOT)) continue;

    io_puts(io1, "j !"); io_puts(io1, myname); io_puts(io1, " "); 
    io_puts(io1, user[j].name); io_puts(io1, " A @H "); 
    io_puts(io1, user[i].name); io_puts(io1, "@"); 
    io_puts(io1, myname); io_puts(io1,"\n"); io_flush(io1);

    io_puts(s, "j !"); io_puts(s, myname);  io_puts(s, " "); 
    io_puts(s, user[j].name); io_puts(s, " A @H "); 
    io_puts(s, user[i].name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);
  }
  sig_pipedefault();

  say_2peer_str1(&user[i], "el\r\n"); 
}

void bnet_send_join(int i)
{
  int j; io *s;

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    if (! peer_STAGE(user[j], PEER_LINK_ELK)) continue;

    s = &user[j].ou;
    io_puts(s, "j "); io_puts(s, myname); io_puts(s, " ");
    io_puts(s, user[i].name); 
    io_puts(s, " A @H "); io_puts(s, user[i].name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

    s = io1;
    io_puts(s, "j "); io_puts(s, myname);  io_puts(s, " ");
    io_puts(s, user[i].name); 
    io_puts(s, " A @H "); io_puts(s, user[i].name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

  }
  sig_pipedefault();
}
