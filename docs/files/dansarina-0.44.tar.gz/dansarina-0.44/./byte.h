#ifndef BYTE_H
#define BYTE_H

#include <stddef.h>

extern void byte_copy();
extern void byte_zero();
extern void byte_copy_r();
extern unsigned int byte_ndx();
extern int byte_cmp();

#endif
