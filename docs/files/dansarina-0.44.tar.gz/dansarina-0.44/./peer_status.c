#include "io.h"
#include "fmt.h"
#include "strerr.h"
#include "peer.h"

extern int poll_max;
extern struct peer user[];

void peer_status()
{
  int i; io *s; char bf[32];
  int y, n; int r;

#if 0
  for (i=0; i < PEERMAX; ++i) {
    s = &user[i].in;
    io_puts(io1,"peer fd: ");
    r = fmt_ulong(bf,(unsigned long) s->f); bf[r]=0;
    if (!r) strerr_die(1,"fmt_ulong\n");
    io_puts(io1,bf); io_puts(io1,"\n");
    io_flush(io1);
  }
#endif

  n = y = 0;

  for (i=0; i < PEERMAX; ++i) { 
    s = &user[i].in; 
    if (s->f == -1) ++n; else ++y; 
  }

  r = fmt_ulong(bf, (unsigned long) y); bf[r]=0;
  io_puts(io1,"+++ Connected peers: "); io_puts(io1,bf); io_puts(io1,"\n");
  r = fmt_ulong(bf, (unsigned long) n); bf[r]=0;
  io_puts(io1,"--- Connected peers: "); io_puts(io1,bf); io_puts(io1,"\n");

  io_flush(io1);
}
