#ifndef EVENTS_H
#define EVENTS_H

struct event { 
  char *name;
  void (*f)(register char *buffer);
};

extern struct event *find();
extern int hub_dispatch();

#endif
