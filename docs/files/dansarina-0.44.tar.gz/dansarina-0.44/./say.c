#include "io.h"
#include "open.h"
#include "strerr.h"
#include "rw.h"
#include "getln.h"
#include "peer.h"
#include "breakup.h"
#include "sig.h"
#include "say.h"

extern struct peer user[];
extern struct peer psv;
extern int poll_max;

void say_file_to(struct message *m, char *path) 
{
  int fd; char ln[80]; char bf[8192]; io file;

  fd = open_read(path); if (fd == -1) strerr_sys(1);
  io_set(&file, read, fd, bf, 8192);

  sig_pipeignore();
  while ( getln(&file,ln,'\n') == 1) {
    io_puts(&psv.ou,"PRIVMSG "); io_puts(&psv.ou,m->nick);
    io_puts(&psv.ou," :"); io_puts(&psv.ou,ln); io_puts(&psv.ou,"\n"); 
    io_flush(&psv.ou);
  }

  close(fd);
}

void say_peer_ln(char *ln, unsigned int len)
{
  int i; io *s;
  sig_pipeignore();
  for (i = 2; i < PEERMAX; ++i) {
    s = &user[i].ou; if (s->f == -1) continue;
    io_put(s, ln, len); io_flush(s);
  }
}

void say_peer_str(char *s1, char *s2, char *s3, char *s4,
                  char *s5, char *s6, char *s7, char *s8)
{
  int i; io *s;
  sig_pipeignore();
  for (i = 2; i < PEERMAX; ++i) {
    s = &user[i].ou; if (s->f == -1) continue;
    if (s1) io_puts(s,s1); if (s2) io_puts(s,s2);
    if (s3) io_puts(s,s3); if (s4) io_puts(s,s4);
    if (s5) io_puts(s,s5); if (s6) io_puts(s,s6);
    if (s7) io_puts(s,s7); if (s8) io_puts(s,s8);
    io_flush(s);
  }

}
