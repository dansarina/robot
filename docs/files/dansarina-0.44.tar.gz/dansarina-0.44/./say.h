#ifndef SAY_H
#define SAY_H

void say_file_to();
void say_peer_ln();
void say_peer_str();

#define say_peer_str1(s1) \
        say_peer_str((s1),0,0,0,0,0,0,0)
#define say_peer_str2(s1,s2) \
        say_peer_str((s1),(s2),0,0,0,0,0,0)
#define say_peer_str3(s1,s2,s3) \
        say_peer_str((s1),(s2),(s3),0,0,0,0,0)
#define say_peer_str4(s1,s2,s3,s4) \
        say_peer_str((s1),(s2),(s3),(s4),0,0,0,0)
#define say_peer_str5(s1,s2,s3,s4,s5) \
        say_peer_str((s1),(s2),(s3),(s4),(s5),0,0,0)
#define say_peer_str6(s1,s2,s3,s4,s5,s6) \
        say_peer_str((s1),(s2),(s3),(s4),(s5),(s6),0,0)
#define say_peer_str7(s1,s2,s3,s4,s5,s6,s7) \
        say_peer_str((s1),(s2),(s3),(s4),(s5),(s6),(s7),0)
#define say_peer_str8(s1,s2,s3,s4,s5,s6,s7,s8) \
        say_peer_str((s1),(s2),(s3),(s4),(s5),(s6),(s7),(s8))

#endif
