#ifndef PEER_H
#define PEER_H

#include "io.h"

#define LN_SIZE 512
#define PEERMAX 256

struct peer {
  char inb[IO_INSIZE];
  char oub[IO_OUTSIZE];
  io in;
  io ou;
  int cont; /* experimental */
};

extern void peer_set();
extern void peer_zero();
extern int peer_feed();
extern int peer_getln();
extern void peer_detach();
extern void peer_attach();
extern void peer_kick();
extern void peer_status();

#endif
