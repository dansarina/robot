#include <ctype.h>
#include "str.h"

void strupper(register char *s)
{
  for (;;) { if(!*s) break; toupper(*s); ++s; }
}
