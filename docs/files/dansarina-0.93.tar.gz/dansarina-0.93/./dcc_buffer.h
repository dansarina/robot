#ifndef DCC_BUFFER_H
#define DCC_BUFFER_H

extern int dcc_buffer(unsigned int socket);

#endif
