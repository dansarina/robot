#ifndef PARSE_H
#define PARSE_H

#include "message.h"

extern void parse_common(struct message *m,register char *b);

#endif
