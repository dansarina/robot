#ifndef DCC_H
#define DCC_H

/* we will use an array of this thing  *
 * to manage all dcc connection we got */

typedef struct _dccset
{
  int fd; char in[8192];
} dccset;

#endif DCC_H
