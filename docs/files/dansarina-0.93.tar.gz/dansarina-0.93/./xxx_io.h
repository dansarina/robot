#ifndef XXX_IO_H
#define XXX_IO_H

#define out(s) fprintf(irc_out,(s)); fflush(irc_out)

#define RD_SIZE 8192

extern char * handle_last_line();
extern void doit();

#endif
