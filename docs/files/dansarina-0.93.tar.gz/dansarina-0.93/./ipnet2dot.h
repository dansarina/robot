#ifndef IPNET2DOT_H
#define IPNET2DOT_H

void ipnet2dot(char *dest, unsigned int size, unsigned long ip);

#endif
