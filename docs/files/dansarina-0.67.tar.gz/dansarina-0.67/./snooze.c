#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

int snooze(int seconds)
{
  struct timeval t;

  t.tv_sec = seconds;
  t.tv_usec  = 0;

  return select(0, NULL, NULL, NULL, &t);
}

#ifdef TEST
#include <setjmp.h>
int main()
{
  jmp_buf env;
  setjmp(env);
  snooze(10);
  return 0;
}

#endif
