#ifndef SNOOZE_H
#define SNOOZE_H

int snooze(int seconds);

#endif
