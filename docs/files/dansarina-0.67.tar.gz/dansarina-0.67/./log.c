#include <errno.h>
#include "log.h"
#include "strerr.h"
#include "io.h"

#define NULL (void*)0

void logthis(char *s)
{
  outs(s); outsflush("\n");
}

void log_strerr_die(int c, char *s)
{
  strerr_die(c, s);
}

void log_strerr_sys(int c, char *s)
{
  outs(s); outsflush(strerror(errno));
  strerr_die(c, NULL);
}
