#include <errno.h>
#include "io.h"
#include "open.h"
#include "strerr.h"
#include "rw.h"
#include "getln.h"
#include "peer.h"
#include "breakup.h"
#include "sig.h"
#include "say.h"

extern struct peer user[];
extern struct peer rs;
extern int poll_max;

#define IMPOLITE "Server is very impolite. Stay away...\n"

void say_thru_rs(char *to, char *bf)
{
  sig_pipeignore(); 
  io_puts(&rs.ou,"PRIVMSG "); io_puts(&rs.ou, to); 
  io_puts(&rs.ou, " :"); io_puts(&rs.ou, bf);
  if (io_flush(&rs.ou) == -1) {
    if (errno == EPIPE) strerr_die(5,IMPOLITE); else strerr_sys(1);
  }
  sig_pipedefault();
}

void say_rs(char *bf) 
{
  sig_pipeignore(); io_puts(&rs.ou,bf); 
  if (io_flush(&rs.ou) == -1) {
    if (errno == EPIPE) strerr_die(5,IMPOLITE); else strerr_sys(1);
  }
  sig_pipedefault();
}

void say_file_to(struct message *m, char *path) 
{
  int fd; char ln[80]; char bf[8192]; io file; int len;

  fd = open_read(path); if (fd == -1) strerr_sys(1);
  io_set(&file, read, fd, bf, 8192);

  sig_pipeignore();
  for (;;) { 
    len = getln(&file,ln,'\n',80);
    if (len == 0) break;
    if (len == -1) strerr_die(1, "say_file_to() -> " ERRLINE);

    io_puts(&rs.ou,"PRIVMSG "); io_puts(&rs.ou,m->nick);
    io_puts(&rs.ou," :"); io_put(&rs.ou,ln,len); io_flush(&rs.ou);
  }

  close(fd);
  sig_pipedefault();
}

void say_peer_ln(char *ln, unsigned int len)
{
  int i; io *s;

  sig_pipeignore();
  for (i = 2; i < PEERMAX; ++i) {
    s = &user[i].ou; if (s->f == -1) continue; if (!user[i].id) continue;
    io_put(s, ln, len); io_flush(s);
  }
  sig_pipedefault();
}

void say_peer_str(char *s1, char *s2, char *s3, char *s4,
                  char *s5, char *s6, char *s7, char *s8)
{
  int j; io *s;

  sig_pipeignore();
  for (j=2; j < PEERMAX; ++j) {
    s = &user[j].ou; if (s->f == -1) continue; if (!user[j].id) continue;
    if (s1) io_puts(s,s1); if (s2) io_puts(s,s2);
    if (s3) io_puts(s,s3); if (s4) io_puts(s,s4);
    if (s5) io_puts(s,s5); if (s6) io_puts(s,s6);
    if (s7) io_puts(s,s7); if (s8) io_puts(s,s8);
    io_flush(s);
  }
  sig_pipedefault();
}

void say_2peer_str(struct peer *p, char *s1, char *s2, char *s3, char *s4,
                                   char *s5, char *s6, char *s7, char *s8)
{
  io *s;

  sig_pipeignore();
  
  s = &p->ou; 
  if (s1) io_puts(s,s1); if (s2) io_puts(s,s2);
  if (s3) io_puts(s,s3); if (s4) io_puts(s,s4);
  if (s5) io_puts(s,s5); if (s6) io_puts(s,s6);
  if (s7) io_puts(s,s7); if (s8) io_puts(s,s8);
  io_flush(s);
  
  sig_pipedefault();
}

void say_party_ln(unsigned int i, char *ln, unsigned int len)
{
  int j; io *s;

  sig_pipeignore();
  for (j = 2; j < PEERMAX; ++j) {
    s = &user[j].ou; if (s->f == -1) continue;
    io_puts(s, user[i].name); io_puts(s, ": "); /* j =/= i */
    io_put(s, ln, len); io_flush(s);
  }
  sig_pipedefault();
}
