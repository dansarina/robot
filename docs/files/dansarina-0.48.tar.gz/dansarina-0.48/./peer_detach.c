#include "peer.h"

void peer_detach(struct peer *p)
{
  peer_zero(p); 
}
