#ifndef STRERR_H
#define STRERR_H

extern void strerr_die(); 
extern void strerr_sys();
extern char *strerror();

#define STRINGIFY(x) #x
#define STRING(x) STRINGIFY(x)
#define ERRLINE __FILE__ ":" STRING(__LINE__)

#endif
