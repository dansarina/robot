#include <poll.h>
#include <unistd.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "strerr.h"
#include "breakup.h"
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];

void peer_auth(unsigned int i, char *ln, unsigned int len)
{
  struct urecord u; struct message m;

  switch(user[i].stage) {
  case 0: /* impossible */
    strerr_die(1, "Wrong stage" ERRLINE);

  case 1: /* telnet, read username */
    byte_copy(m.nick, min(NICKLEN - 1, len - 1), ln);
    byte_copy(user[i].name, min(NICKLEN - 1, len - 1), ln);
      
    if (!user_get(&u,m.nick)) {
      say_2peer_str1(&user[i], "I don't know you.\r\n");
      close(conn[i].fd); conn[i].fd = -1; peer_detach(&user[i]);
      return;
    }
    user[i].stage = 2;
    return;

  case 2: /* read password, dcc and telnet */
    byte_copy(m.nick, str0_len(user[i].name), user[i].name);
    
    if (!user_get(&u,m.nick)) {
      say_2peer_str1(&user[i], "I don't know you, dude.\r\n");
      close(conn[i].fd); conn[i].fd = -1; peer_detach(&user[i]);
      return;
    }

    if ( byte_cmp(u.pass, min(u.pn, len - 1), ln) ) { 
      say_2peer_str1(&user[i], "Wrong password. Goodbye.\r\n");
      close(conn[i].fd); conn[i].fd = -1; peer_detach(&user[i]);
      return;
    }

    user[i].id = 1; /* welcome peer */
    say_peer_str1("+++ New peer authenticated. Welcome, peer.\r\n");
    return;

  case 3: /* link bot */
    return;

  }

  strerr_die(1, "Authentication has bad logic");
}
