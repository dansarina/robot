#include "io.h"
#include "byte.h"
#include "str.h"
#include "peer.h"
#include "handlers.h"
#include "breakup.h"
#include "strerr.h"
#include "scan.h"
#include "say.h"
#include "events.h"

struct event general[] =
{
  { "PING", gen_ping },
  { "JOIN", gen_join },
  { "QUIT", gen_quit },
  { "PART", gen_part },
  { "ERROR", gen_error },
  { 0, 0 }
};

struct event priv[] = 
{
  { "HELP", priv_help },
  { "HELLO", priv_hello },
  { "PASS", priv_pass },
  { 0, 0 }
};

struct event ctcp[] = 
{
  { "SOURCE", ctcp_source },
  { "VERSION", ctcp_version },
  { "PING", ctcp_ping }, 
  { "DCCCHAT", ctcp_chat },
  { 0, 0}
};

static struct event *find(struct event table[], register char *item)
{
  int i;
  for (i=0; table[i].name; ++i)
    if (!byte_cmp(item, str0_len(table[i].name), table[i].name))
      return &table[i]; /* match */
  return 0;
}

static void ctcp_dispatch(char *bf, unsigned int len, unsigned int k)
{
  char ln[LN_SIZE]; char cmd[COMMLEN]; 
  struct event *e; unsigned int p1, p2; 
  unsigned int n;

  n = len;
  if ( k > 2 ) strerr_die(1,"Too many CTCP messages\n"); /* XXX: must loop */
  
  p1 = byte_ndx(bf, len, '\1'); 
  p2 = byte_ndx(bf + p1 + 1, len, '\1');
  p2 += p1; len = p2 - p1; 

  byte_copy(ln, len, bf + p1 + 1);
  
  len = scan_word(cmd, COMMLEN, ln);
  if (!byte_cmp(cmd,3,"DCC")) 
    scan_word(cmd + len, 4, ln + len + 1);

  e = find(ctcp,cmd); if (!e) return; (*e->f)(bf);

}

int hub_dispatch(char *bf, unsigned int len)
{
  int i; char *t; struct event *e;
  struct message m; char cmd[COMMLEN]; char ln[LN_SIZE+1];
  unsigned int k; 

  byte_zero(ln,LN_SIZE+1); byte_copy(ln,len,bf); 

  k = byte_cnt(ln, len, '\1');
  if ( k > 0 && k % 2 == 0 ) { ctcp_dispatch(ln,len,k); return 1; }
 
  t = ln; i = 0;
  if( *t == ':') { while (*t && *++t != ' '); if(!*t) return 0; ++t; }

  i = scan_word(cmd, COMMLEN, t);

  if (!byte_cmp(cmd,7,"PRIVMSG")) {
    breakup(&m,ln); 
    i = scan_word(cmd,COMMLEN,&m.text[1]); 

    if (!byte_cmp(m.para,9,"dansarina")) {
      i = byte_2upper(cmd,i);
      e = find(priv, cmd); if (e) (*e->f)(ln);
    }

    say_peer_str5(m.nick,"@",m.para," -> ",m.text);

    io_puts(io1, m.nick); io_puts(io1, "@"); io_puts(io1,m.para); 
    io_puts(io1, " -> "); io_puts(io1, m.text); io_flush(io1);
    return 1;
  }

  e = find(general, cmd); if (!e) return 0; (*e->f)(ln); return 1;
}
