#include <poll.h>
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];

int peer_attach(int s)
{
  int j; 

  for (j=0; j < PEERMAX; ++j)
    if (conn[j].fd == -1) {
      conn[j].fd = s; conn[j].events = POLLIN;
      peer_zero(&user[j]); peer_set(&user[j],s);
      break;
    }

  if (j == PEERMAX) { peer_kick(s); return -1; }
  if (j > poll_max) poll_max = j; 

  return j;
}
