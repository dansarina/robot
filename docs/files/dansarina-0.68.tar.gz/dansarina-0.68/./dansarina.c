#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <inttypes.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include "io.h"
#include "strerr.h"
#include "socket.h"
#include "poll.h"
#include "exit.h"
#include "peer.h"
#include "byte.h"
#include "ndelay.h"
#include "events.h"
#include "say.h"
#include "conf.h"
#include "scan.h"
#include "ver.h"
#include "lim.h"
#include "log.h"
#include "str.h"

extern void free();

int poll_max; struct pollfd conn[PEERMAX];
struct peer user[PEERMAX]; 

struct peer *rs; /* ircd server */
struct peer *pg; /* plugin daemon */

char myname[NICKLEN+1];
char myuser[USERLEN+1];
char mychan[CHANLEN+1];
char rsserv[SERVLEN+1];

uint32_t rs_port;
uint32_t ls_port;

void plugger_startup() 
{
  char plug[1024]; int fdin; int fdout; int r; struct stat pin; struct peer *p;

  /* create the pipes */

  r = mkdir("./plg", 0700);
  if (r != 0 && errno != EEXIST) 
      log_strerr_sys(1, "fatal: cannot create ./plg: ");

  r = lstat("./plg", &pin);
  if (r != 0) 
    log_strerr_sys(1, "fatal: cannot stat ./plg: ");

  if (! S_ISDIR(pin.st_mode)) 
    log_strerr_die(1, "fatal: ./plg is not a directory.\n");

  r = mkfifo("./plg/in", 0600);
  if (r != 0 && errno != EEXIST)
    log_strerr_sys(1, "fatal: cannot create the fifo ./plg/in: ");

  r = mkfifo("./plg/out", 0600);
  if (r != 0 && errno != EEXIST)
    log_strerr_sys("fatal: cannot create the fifo ./plg/out: ");

  fdin = open_write("./plg/in");
  if (fdin == -1) {
    logthisys("fatal: cannot open ./plg/in for writing: ");
    return;
  }

  fdout = open_read("./plg/out");
  if (fdout == -1) {
    logthisys("fatal: cannot open ./plg/out for reading: ");
    return;
  }

  /* attach fdout to the peer to the array of descriptors */
  pg = peer_attach(fdout); 
  pg->in.f = fdout; /* dansarina reads from it */
  pg->ou.f = fdin; /* dansarina writes to it */
}

static void doit_pg() /* pg = plugger */
{
  char ln[LN_SIZE]; int len;

  logthis("plugger talking...\n");

  do {
    len = getln(&pg->in,ln,'\n', sizeof ln);

    if (len == -1) { 
      if (errno == EWOULDBLOCK) return;
      log_strerr_sys(3, "fatal: doit_pg: ");
    }

    if (len == -2) {
      /* logthis("detail: doit_pg: i read a partial line; nothing to do"); */
      return;
    }
    
    if (len == 0) { 
      logthis("warning: doit_pg: plugger has closed connection");
      peer_detach(pg); plugger_startup();
      return;
    }

    ln[len] = 0; say_rs1(ln);
    
  } while (rs->in.p >= 0); /* eof =/= buffer =/= empty */
}

static void sigchild(int sig)
{
  pid_t pid; int stat; 

  for (;;) {
    pid = waitpid(-1, &stat, WNOHANG); if (pid <= 0) break; 
    /* logthis("sigchild: children terminated\n"); */
    /* set a variable, then log somewhere else */
  }
}

static void siglog(int sig)
{
  logthis("siglog: i just received a signal\n");
}

static void sigterm(int sig)
{
  logthis("siglog: got sigterm\n");
  peer_detach_all(); _exit(0);
}

static void sigint(int sig)
{
  logthis("siglog: got sigint\n");
  peer_detach_all(); _exit(0);
}

/* static void sigtstp(int sig) { logthis("siglog: got sigtstp\n"); } */

static void sigcont(int sig)
{
  logthis("siglog: got sigcont\n");
}

static void doit_rs() /* rs = remote server */
{
  char ln[LN_SIZE]; int len;

  do {
    len = peer_getln(rs, ln);

    if (len == -1) { 
      if (errno == EWOULDBLOCK) return;
      log_strerr_sys(3, "fatal: doit_rs: ");
    }

    if (len == -2) {
      /* logthis("detail: doit_rs: i read a partial line; nothing to do"); */
      return;
    }
    
    if (len == 0) { 
      strerr_die(2,"fatal: doit_rs: server closed on my face; so rude");
    }
  
    if (! sirc_dispatch(ln, len) ) { 
      io_put(io1, ln, len); io_flush(io1);
      say_peer_ln(ln, len);
    }
    
  } while (rs->in.p >= 0); /* eof =/= buffer =/= empty */
}

static void doit_peer(struct peer *p)
{
  char ln[LN_SIZE]; int len;

  logthis("peer talking...\n");

  if (peer_STAGE(p, PEER_CONN_PRG)) { peer_auth(p, 0, 0); return; }

  do {
    len = peer_getln(p, ln);

    if (len == -1) {
      if (errno == EWOULDBLOCK) return;
      logthis("warning: doit_peer: error reading from peer"); 
      peer_detach(p); 
      return;
    }

    if (len == -2) { 
      /* logthis("detail: doit_peer: i read partial line; nothing to do");  */
      return; 
    }

    if (len ==  0) { logthis("doit_peer: peer closed connection"); peer_detach(p); return; }

    io_put(io1, ln, len); io_flush(io1);
    
    /* peer still needs to authenticate */
    if (!peer_STAGE(p, PEER_AUTH_PWD)) { peer_auth(p, ln, len); continue; }

    /* peer asked for something */
    if (ln[0] == '.') { bdot_dispatch(p, &ln[1], --len); continue; }

    /* peer talking, distribute */
    say_party_ln(p, ln, len);

  } while (p->in.p >= 0); /* buffer =/= empty */
}

static void conf()
{
  char port[8]; unsigned int n;

  conf_retr(CONFDB "myname", NICKLEN, myname);
  if (!*myname) strerr_die(1, "conf: set my name in " CONFDB "myname");
  conf_retr(CONFDB "myuser", USERLEN, myuser);
  if (!*myuser) strerr_die(1, "conf: set my name in " CONFDB "myuser");
  conf_retr(CONFDB "mychan", CHANLEN, mychan);
  if (!*mychan) strerr_die(1, "conf: set my channel in " CONFDB "mychan");
  conf_retr(CONFDB "rsserv", SERVLEN, rsserv);
  if (!*rsserv) strerr_die(1, "conf: set my server in " CONFDB "rsserv");

  conf_retr(CONFDB "rsport", 7, port);
  n = scan_uint32(port, &rs_port);
  if (!n) 
    strerr_die(1, "conf: set my remote server port in " CONFDB "rsport");

  conf_retr(CONFDB "myport", 5, port);
  n = scan_uint32(port, &ls_port); 
  if (!n) 
    strerr_die(1, "conf: set my listening port in " CONFDB "myport");
}

void irc_ping()
{
  static unsigned long last = 0;
  unsigned long current;

  if (!last) last = time(NULL);
  current = time(NULL);

  if ( current - last >= 60) {
    last = current; say_rs1("PING :wanna play ping pong? pleaaaase\n");
    logthis("info: if ircd went away, i want a reset by peer");
  }
}

void plugger_verify()
{
  static unsigned long last = 0; unsigned long current;

  if (!last) last = time(NULL);
  current = time(NULL);

  if ( current - last >= 60) {
    last = current; 
    logthis("plugger_verify: verifying if plugger is connected; doing nothing really");
  }
}

void plugger_joke()
{
  static str line; static unsigned long last = 0;
  unsigned long current; char bf[80]; 

  if (!last) last = time(NULL);
  current = time(NULL);

  line.bf = bf; line.n = sizeof bf; line.p = 0;
  str_REWIND(&line); /* line is non-heap memory */ byte_zero(line.bf, line.n);

  if (current - last >= 60*15) {
    last = current; 
    logthis("plugger_joke: joking...");
    str_PUTS(&line, "quote dansa username hostname ");
    str_PUTS(&line, &mychan[1]); str_PUTS0(&line, "\n");
    say_2plugger_str1(pg, line.bf);
  }
}

int irc_connect()
{
  int r; int ir;

  ir = socket_tcp(); 
  if (ir == -1) 
    strerr_2sys(1, "irc_connect: socket_tcp: ", "could not create irc socket");
  
  r = socket_connect_timeout(ir, rsserv, rs_port,5); 
  if (r == -1) 
    strerr_3sys(1,"irc_connect: socket_connect_timeout: ","could not connect to ", rsserv);
  if (r == -2) 
    strerr_3sys(1,"irc_connect: socket_connect_timeout: ","coult not connect to ", rsserv);
  if (! peer_attach(ir) ) 
    strerr_die(1,"irc_connect: can't attach peer");

  rs = &user[0]; /* remote server: im zero now! careful. */

  return ir;
}

void irc_register()
{
  /* XXX: errors will come thru sirc_dispatch() */
  say_rs5("USER ", myuser, " 1 * :/msg ", myname, " hello\r\n");
  say_rs3("NICK ", myname, "\r\n"); say_rs3("JOIN ", mychan, "\r\n");
}

/* 
   A quick guide to socket handling: the listening socket
   takes user[0], the ircd server takes user[1] and the
   plugin system takes user[2]. This leaves 

                     PEERMAX - 3 

   peers available for connections. So, you may notice we
   start at 3 when we scan the peers for i/o activity. For
   the first three peers, as described above, we handle each
   with higher priority and separately.
*/

int server_listen()
{
  int sv;

  sv = socket_bind_reuse_listen(ls_port); 
  if (sv == -1) 
    strerr_2sys(1, "server_listen: ", "socket_bind_reuse_listen: ");

  if (! peer_attach(sv) ) 
    strerr_die(1,"server_listen: can't attach peer");

  return sv;
}

int main()
{
  int sv; int nsocks; int r; int j; int i; int ir; 

  sig_catch(SIGCHLD, sigchild); 
  sig_catch(SIGTERM, sigterm);
  sig_catch(SIGINT, sigint); 
  /* sig_catch(SIGTSTP, sigtstp); */
  sig_catch(SIGCONT, sigcont); 

  conf(); 

  for (j=0; j < PEERMAX; ++j) { 
    user[j].poll = &conn[j]; peer_zero(&user[j]); 
  }

  ir = irc_connect(); irc_register();

  plugger_startup(); /* why now? */ /* why not? */

  for (;;) {
    nsocks = polltimeout(conn, poll_max + 1, 60);

    irc_ping(); plugger_joke();

    if (nsocks == 0) { peer_status(); continue; }

    /* irc server only */
    if (conn[0].revents & (POLLIN | POLLERR)) {
      doit_rs();
    }

    /* peers */
    for (i=1; i < PEERMAX; ++i)
      if (conn[i].revents & (POLLIN | POLLERR | POLLHUP)) {
	struct stat x; 

	if (fstat(user[i].in.f, &x) == 0 && S_ISFIFO(x.st_mode)) /* gotta be plugger */
	  doit_pg(&user[i]); 
	else 
	  doit_peer(&user[i]);
      }

    if (--nsocks <= 0) { continue; }
  }
}
