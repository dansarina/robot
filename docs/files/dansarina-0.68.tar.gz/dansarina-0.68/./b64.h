#ifndef B64_H
#define B64_H

unsigned int b64();

#endif
