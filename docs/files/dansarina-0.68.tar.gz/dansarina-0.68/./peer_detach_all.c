#include "io.h"
#include "peer.h"

extern int poll_max;
extern struct peer user[];

void peer_detach_all()
{
  int i; struct peer *p;

  for (i=0; i < PEERMAX; ++i) { 
    p = &user[i];
    if (p->poll->fd > 0) /* if it has been attached */
      peer_detach(p);
  }
}

