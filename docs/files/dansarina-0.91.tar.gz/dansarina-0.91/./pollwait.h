#ifndef POLLWAIT_H
#define POLLWAIT_H

#include <poll.h>
extern int pollwait(struct pollfd *f, unsigned int n);

#endif
