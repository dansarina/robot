#include <string.h>
#include <stdio.h>
#include "events.h"
#include "handlers.h"

/* an array of events and event handlers */
com events[] = 
{
  { "PING",     ev_ping         },
  { "TOPIC",    ev_topic        },
  { "JOIN",     ev_join         },
  { "QUIT",     ev_quit         },
  { "PART",     ev_part         },
  { "PRIVMSG",  ev_privmsg      },
  { "ERROR",    ev_error        },
  { 0,          0               }
};

com *find(register char *event) 
{
  int i;

  for (i=0; events[i].name; ++i)
    if (! strncmp(event, events[i].name, sizeof(events[i].name)))
      return &events[i];

  return 0;
}

void hub_dispatch_event(register char *b) 
{
  register int i; register char *t;
  char command[COMMLEN]; com *handler;

  t = b; i = 0;

  if( *t == ':') { /* foreign */
      while (*t && *++t != ' ');
      ++t;      
  }

  while( *t && *t != ' ' && i < (COMMLEN - 1)) 
    command[i++] = *t++;
  command[i] = 0;

  /* find handler */
  handler = find(command);

  if( !handler ) {
    printf("--- %s\r\n",b);
    return;
  }

  /* dispatch event */
  (*handler->f)(b);
}

