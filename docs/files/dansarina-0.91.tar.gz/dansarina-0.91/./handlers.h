#ifndef HANDLERS_H
#define HANDLERS_H

extern void ev_ping(register char *buffer);
extern void ev_topic(register char *buffer);
extern void ev_join(register char *buffer);
extern void do_something(struct message *m);
extern void ev_quit(register char *buffer);
extern void ev_part(register char *buffer);
extern void ev_privmsg(register char *buffer);
extern void ev_error(register char *buffer);

#endif
