#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>      /* gethostbyname */
#include <unistd.h>     /* close */
#include <string.h>
#include <stdio.h>
#include "fatal.h"
#include "telnet.h"

unsigned int telnet_open(char *addr, unsigned int port)
{ 
  unsigned int s; struct sockaddr_in n; 
  struct hostent *h; int i;

  s = socket(AF_INET,SOCK_STREAM,0);
  if (s < 0) fatal1("telnet_open: cannot create socket.\r\n");
  memset(&n, 0, sizeof(struct sockaddr_in));
  n.sin_family = AF_INET;
  n.sin_port = htons(port);
 
  h = gethostbyname(addr);
  if(!h) 
  {
    close(s);
    fatal1("telnet_open: cannot resolve hostname\r\n");
  }

  memcpy(&n.sin_addr.s_addr,h->h_addr,h->h_length);

  i = connect(s, (struct sockaddr *) &n, 
                 sizeof(struct sockaddr_in));
  if( i < 0 ) 
  {
    close(s);
    perror("connect");
    fatal1("telnet_open: cannot connect to server\r\n");
  }

  return s;
}

unsigned int telnet_listen(unsigned int port) 
{
  int s; struct sockaddr_in n;

  s = socket(AF_INET, SOCK_STREAM, 0);
  if (s < 0) fatal1("telnet_open: cannot create socket.\r\n");
  memset(&n, 0, sizeof(struct sockaddr_in));

  n.sin_family = AF_INET;
  n.sin_port = htons(port);
  n.sin_addr.s_addr = htonl(INADDR_ANY);

  if ( bind(s,(struct sockaddr *)&n, sizeof (n)) < 0) 
  {
    close(s); 
    perror("bind"); fatal(0,1);
  }

  if ( listen(s,5) < 0 )
  {
    close(s);
    perror("listen"); fatal(0,1);
  }
  
  return s;
}

unsigned int telnet_accept(int s, struct sockaddr *a, socklen_t *len) 
{
  int new;
  new = accept(s, a, len);
  if ( new < 0 ) { perror("accept"); fatal(0,1); }
  return new;
}
