#ifndef TELNET_H
#define TELNET_H

extern unsigned int telnet_open(char *addr, unsigned int port);
extern unsigned int telnet_listen(unsigned int port);
extern unsigned int telnet_accept(int s, struct sockaddr *a, socklen_t *len);
#endif
