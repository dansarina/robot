#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "pollwait.h"
#include "xxx_io.h"
#include "sig.h"
#include "telnet.h"
#include "dcc_buffer.h"

int irc_socket; FILE* irc_out;
int tel_socket; FILE* tel_out;

int main() 
{
  struct pollfd files[5]; unsigned int n; unsigned int m;
  int i; struct sockaddr caddr; int r; int j; socklen_t slen;

  sig_int(); sig_ter();

  for (n=0; n<5; ++n) files[n].fd= -1; /* reset all sockets */
  m = 0; /* max index in files[] */

  tel_socket = telnet_listen(3333);
  tel_out = fdopen(tel_socket,"w");

  files[0].fd = tel_socket;
  files[0].events = POLLIN;

  /* XXX: it blocks here. please fix it. */
  irc_socket = telnet_open("irc.dal.net",7000);
  irc_out = fdopen(irc_socket,"w");

  files[1].fd = irc_socket;
  files[1].events = POLLIN; ++m;

  /* XXX: socket could've been closed. broken pipe. */
  out("USER dansarina 3 * :Dansarina\r\n");
  out("NICK dansarina\r\n");
  out("JOIN #0xff\r\n");

  for (;;) 
  {
    n = pollwait(files, m+1);
    if (files[0].revents & (POLLIN | POLLERR)) 
    { /* something on tel_socket */
      slen = sizeof caddr; 
      r = telnet_accept(files[0].fd, (struct sockaddr*) &caddr, &slen);

      /* place connection */
      for (j=1; j < 5; ++j)
        if (files[j].fd < 0) {files[j].fd = r; break;}

      /* XXX: what if there's no more slots? */
      if (j == 5) {; /* deny this dude */}

      files[j].events = POLLIN;
      if ( j > m) m = j; /* go up the index max */

      if (--n <= 0) /* only one socket was ready */
        continue;
    }

    /* check if irc server is talking */
    if (files[1].revents & (POLLIN | POLLERR)) 
    { 
      doit(); /* bufferize and answer*/

      if (--n <= 0) /* only one socket was ready */
        continue;
    }

    /* loop through each ready socket */
    for (i=2; i <= m; ++i)
    { 
      if (files[i].revents & (POLLIN | POLLERR)) 
      { /* buffer it, but if EOF, then make release files[i] slot */
        if (dcc_buffer(files[i].fd) <= 0) files[i].fd = -1;
      }
    }
  }
  
  exit(0); /* never */
}

