#include <stdlib.h>
#include "strjoin.h"
#include "fatal.h"

char * strjoin(const char *s1, const char *s2, const char *s3, 
               const char *s4, const char *s5, const char *s6) 
{
  unsigned int i; register char *j; register char *s;

  if (s1) i  = strlen(s1);
  if (s2) i += strlen(s2);
  if (s3) i += strlen(s3);
  if (s4) i += strlen(s4);
  if (s5) i += strlen(s5);
  if (s6) i += strlen(s6);

  s = malloc(i + 1);
  if (!s) fatal1("strjoin: no malloc, no fun.\n");

  j = s;

  if (s1) 
    while( (*j++ = *s1++) && *s1);
  if (s2)
    while( (*j++ = *s2++) && *s2);
  if (s3)
    while( (*j++ = *s3++) && *s3);
  if (s4)
    while( (*j++ = *s4++) && *s4);
  if (s5)
    while( (*j++ = *s5++) && *s5);
  if (s6)
    while( (*j++ = *s6++) && *s6);

  *j = 0; /* close it */
  return s;
}

