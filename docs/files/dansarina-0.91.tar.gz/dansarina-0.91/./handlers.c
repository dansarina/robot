#include <string.h>
#include <stdio.h>
#include "message.h"
#include "handlers.h"
#include "parse.h"
#include "topic.h"
#include "say.h"
#include "user.h"

extern FILE* irc_out;

void ev_ping(register char *buffer) 
{
  register char *p; p = buffer;
  while( *p && *p++ != ':');
  printf("+++ PONG :%s\r\n",p);
  fprintf(irc_out,"PONG :%s\r\n",p);
  fflush(irc_out);
}

void ev_topic(register char *buffer) 
{
  struct message m;
  printf("+++ topic: %s\r\n",buffer);
  parse_common(&m,buffer);
  topic_append(&m);
}

void ev_join(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  printf("+++ join: %s\r\n",buffer);

  if ( strncmp(m.host, "64-109-150-120", 14) ) 
    if ( strlen(buffer) % 2 ) 
      do_something(&m);
}

void do_something(struct message *m)
{
  say_channel_to(m,"you look lovely today...\r\n");
}

void ev_quit(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);

  printf("+++ quit: %s\r\n",buffer);
}

void ev_part(register char *buffer) 
{
  struct message m; 
  parse_common(&m, buffer);
  printf("+++ part: %s\r\n",buffer);
}

void ev_privmsg(register char *buffer) 
{
  struct message m; 
  parse_common(&m,buffer);
  printf("+++ priv: %s @ %s -> %s\r\n",
         m.nick,m.para,m.text);

  /* private commands */
  if ( !strncmp(m.para,"dansarina",9) ) 
  {
    if (!strncmp(m.text,":hello",6) ) 
    {
      user_append(&m);
    }
    /* do not continue */
    return;
  }

  /* public commands */
  if (!strncmp(m.text,":.history topic",15) ) 
  {
    topic_history(&m);
  }

  return;
}

void ev_error(register char *buffer) 
{
  printf("+++ ERR: %s\r\n",buffer);
  fclose(irc_out); exit(1);
}

