#include <sys/types.h>
#include <dirent.h>
#include "strerr.h"
#include "scan.h"
#include "min.h"
#include "breakup.h"
#include "plugin.h"

unsigned int plugin_exist(struct message m)
{
  DIR *u; struct dirent *e; unsigned int n; char file[16]; char *s;
  s = &m.text[2];

  n = scan_word(file, min(16,str0_len(s)), s); file[n] = 0;
  u = opendir("./run/"); if (!u) strerr_sys(1);

  for (;;) {
    e = readdir(u); if (!e) return 0;
    if ( e->d_name[0] == '.') continue;
    if (!byte_cmp(e->d_name, min(str0_len(e->d_name),str0_len(file)), file))
      return 1;
  }
}
