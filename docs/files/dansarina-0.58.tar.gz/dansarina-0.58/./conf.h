#ifndef CONF_H
#define CONF_H

extern void conf_retr();
extern void conf_puts();

#define CONFDB "./ctl/"

#endif
