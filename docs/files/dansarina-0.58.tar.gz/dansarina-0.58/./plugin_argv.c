#include "scan.h"
#include "min.h"
#include "breakup.h"
#include "plugin.h"

extern void* malloc();

int plugin_argv(struct message m, char **argv, unsigned int size)
{
  char *s; unsigned int n; char arg[16]; int i;

  s = &m.text[2]; if (!*s) return -1;

  n = scan_word(arg, min(16,str0_len(s)), s); s += n + 1; arg[n] = 0; 
  argv[0] = malloc(n+1); if (!argv[0]) return -1;
  byte_copy(argv[0], n+1, arg);

  n = str0_len(m.nick); 
  if(n) { argv[1] = malloc(n+1); if (!argv[1]) return -1; }
  byte_copy(argv[1], str0_len(m.nick) + 1, m.nick);

  n = str0_len(m.user);
  if (n) { argv[2] = malloc(n+1); if (!argv[2]) return -1; }
  byte_copy(argv[2], str0_len(m.user) + 1, m.user);

  n = str0_len(m.host);
  if (n) { argv[3] = malloc(n+1); if (!argv[3]) return -1; }
  byte_copy(argv[3], str0_len(m.host) + 1, m.host);

  n = str0_len(m.para);
  if (n) { argv[4] = malloc(n+1); if (!argv[4]) return -1; }
  byte_copy(argv[4], str0_len(m.para) + 1, m.para);

  i = 5;

  for (;;) {
    if (!*s) break; if (i == size) break;
    n = scan_word(arg, min(512,str0_len(s)), s); s += n + 1; arg[n] = 0; 
    argv[i] = malloc(n+1); if (!argv[i]) return -1;
    byte_copy(argv[i], n+1, arg); ++i;
  }

  argv[i] = 0; return 0;
}

void plugin_argv_init(char **argv, unsigned int size)
{
  int i; for (i=0; i < 32; ++i) { argv[i] = 0; }
}

void plugin_argv_done(char **argv, unsigned int size)
{
  int i; for (i=0; i < 32; ++i) { if (argv[i]) free(argv[i]); }
}
