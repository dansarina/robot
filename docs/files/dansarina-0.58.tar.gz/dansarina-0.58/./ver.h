#ifndef VER_H
#define VER_H

#define VER "0.58"

#endif
