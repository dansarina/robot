#include <inttypes.h>
#include <stdio.h>
#include <errno.h>
#include "io.h"
#include "strerr.h"
#include "socket.h"
#include "poll.h"
#include "exit.h"
#include "peer.h"
#include "byte.h"
#include "ndelay.h"
#include "events.h"
#include "say.h"
#include "sig.h"
#include "conf.h"
#include "scan.h"
#include "list.h"
#include "ver.h"
#include "bnet.h"
#include "lim.h"

extern void free();

int poll_max; struct pollfd conn[PEERMAX];
struct peer user[PEERMAX]; struct peer *rs;

char myname[NICKLEN+1];
char myuser[USERLEN+1];
char mychan[CHANLEN+1];
char rsserv[SERVLEN+1];

uint32_t rs_port;
uint32_t ls_port;

list robots; 
list people; 

static void doit_rs() /* rs = remote server */
{
  char ln[LN_SIZE]; int len;

  do {
    len = peer_getln(rs, ln);
    
    if (len == -2) return;
    if (len == -1) strerr_sys(3);
    if (len ==  0) strerr_die(2,"Server closed on my face.");
    
    if (! sirc_dispatch(ln, len) ) { 
      io_put(io1, ln, len); io_flush(io1);
      say_peer_ln(ln, len);
    }
    
  } while (rs->in.p); /* buffer =/= empty */
}

static void doit_peer(struct peer *p)
{
  char ln[LN_SIZE]; int len;

  if (peer_STAGE(p, PEER_CONN_PRG)) { peer_auth(p, 0, 0); return; }

  do {
    len = peer_getln(p, ln);
    
    if (len == -2) { return; }
    if (len == -1) { 
      if (peer_STAGE(p, PEER_INFO_BOT)) {
        bnet_robot_del(p->name, strerror(errno));
        peer_detach(p); return;
      }
      bnet_snd_part(p, strerror(errno));
      peer_detach(p); return;
    }
    if (len ==  0) { 
      if (peer_STAGE(p, PEER_INFO_BOT)) {
        bnet_robot_del(p->name, strerror(errno));
        peer_detach(p); return;
      }
      bnet_snd_part(p, "without a trace");
      peer_detach(p); return;
    }

    io_put(io1, ln, len); io_flush(io1);
    
    /* peer still needs to authenticate */
    if (!peer_STAGE(p, PEER_AUTH_PWD)) { peer_auth(p, ln, len); continue; }

    /* bot speaking, parse it */
    if ( peer_STAGE(p, PEER_INFO_BOT)) { bnet_dispatch(p, ln, len); continue; }

    /* peer asked for something */
    if (ln[0] == '.') { bdot_dispatch(p, &ln[1], --len); continue; }

    /* peer talking, distribute */
    say_party_ln(p, ln, len);

  } while (p->in.p); /* buffer =/= empty */
}

static void conf()
{
  char port[8]; unsigned int n;

  conf_retr(CONFDB "myname", NICKLEN, myname);
  if (!*myname) strerr_die(1, "conf: set my name in " CONFDB "myname");
  conf_retr(CONFDB "myuser", USERLEN, myuser);
  if (!*myuser) strerr_die(1, "conf: set my name in " CONFDB "myuser");
  conf_retr(CONFDB "mychan", CHANLEN, mychan);
  if (!*mychan) strerr_die(1, "conf: set my channel in " CONFDB "mychan");
  conf_retr(CONFDB "rsserv", SERVLEN, rsserv);
  if (!*rsserv) strerr_die(1, "conf: set my server in " CONFDB "rsserv");

  conf_retr(CONFDB "rsport", 7, port);
  n = scan_uint32(port, &rs_port);
  if (!n) 
    strerr_die(1, "conf: set my remote server port in " CONFDB "rsport");

  conf_retr(CONFDB "myport", 5, port);
  n = scan_uint32(port, &ls_port); 
  if (!n) 
    strerr_die(1, "conf: set my listening port in " CONFDB "myport");
}

void brasnet()
{
  say_rs1("NICKSERV identify droplets\r\n");
}

int main()
{
  int sv; int nsocks; int r; int j; int i; int ir;

  conf(); list_init(&robots,free); list_init(&people,free);

  for (j=0; j < PEERMAX; ++j) { 
    user[j].poll = &conn[j]; peer_zero(&user[j]); 
  }

  sv = socket_bind_reuse_listen(ls_port); if (sv == -1) strerr_sys(1);
  if (! peer_attach(sv) ) strerr_die(1,"Can't attach peer\n");

  ir = socket_tcp(); if (ir == -1) strerr_sys(1);
  r = socket_connect_timeout(ir, rsserv, rs_port,5); 
  if (r == -1) strerr_sys(1); if (r == -2) strerr_sys(1);
  if (! peer_attach(ir) ) strerr_die(1,"Can't attach peer\n"); 

  rs = &user[1]; /* remote server */

  /* XXX: errors will come thru sirc_dispatch() */
  say_rs5("USER ", myuser, " 1 * :/msg ", myname, " hello\r\n");
  say_rs3("NICK ", myname, "\r\n"); say_rs3("JOIN ", mychan, "\r\n");

  for (;;)
  {
    nsocks = polltimeout(conn, poll_max + 1, 60);

    if (nsocks == 0) { peer_status(); /* bnet_status(); */ continue; }

    if (conn[0].revents & (POLLIN | POLLERR)) {
      struct peer *g;
      r = socket_accept(sv); if (r < 0) strerr_sys(2);
      g = peer_attach(r); if (! g ) continue; g->stage = PEER_CONN_RDY;

      say_2peer_str1(g, "Hi. I am Dansarina " VER "\r\n");
      say_2peer_str1(g, "Please, type username password:\r\n");

      if (--nsocks <= 0) continue;
    }

    /* irc server only */
    if (conn[1].revents & (POLLIN | POLLERR)) {
      doit_rs();
    }

    /* peers */
    for (i=2; i <= poll_max; ++i)
      if (conn[i].revents & (POLLIN | POLLERR)) 
        doit_peer(&user[i]);

    if (--nsocks <= 0) { continue; }
  }

}
