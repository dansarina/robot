#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include "rw.h"
#include "io.h"
#include "ndelay.h"
#include "str.h"
#include "poll.h"
#include "say.h"
#include "breakup.h"
#include "plugin.h"

void plugin(struct message m)
{
  char *nick; char *chan; char *expr; int r; int p; int fd[2]; 
  struct pollfd pl; unsigned int len; char path[1024]; io in; 
  char bf[512]; static str line; static str to; char *argv[32];

  nick = m.nick; chan = m.para; expr = &m.text[2];
  plugin_argv_init(argv, 32); str_REWIND(&to); str_REWIND(&line);

  if(!str_alloc(&line, 512)) strerr_sys(1); 
  if(!str_alloc(&to, 64)) strerr_sys(1);

  if (!str_PUTS(&to, "#")) strerr_sys(1);
  if (!str_PUTS(&to, chan)) strerr_sys(1); str_0(&to);

/*
  if (!str_PUTS(&line, nick)) strerr_sys(1);
  if (!str_PUTS(&line, ", ")) strerr_sys(1);
*/

  if(!plugin_exist(m)) {
    if (!str_PUTS(&line, "no such plugin.\n")) strerr_sys(1);
    str_0(&line); say_thru_rs(to.bf, line.bf); return;
  }

  r = plugin_argv(m,argv,32); if (r == -1) strerr_die(1, "plugin_argv");

  r = pipe(fd); if (r == -1) { strerr_die(1, "pipe"); }
  p = fork(); if (p == -1) { strerr_die(1, "fork"); }

  plugin_argv_done(argv, 32); 

  if (!p) {
    close(fd[0]); dup2(fd[1], 1); 
    r = plugin_path(expr, path, sizeof path); if (r == -1) strerr_sys(1);
    execve(path, argv, 0); 
    if (!str_PUTS(&line, strerror(errno))) strerr_sys(1);
    if (!str_PUTS(&line, "\n")) strerr_sys(1);
    str_0(&line); str_0(&to); say_thru_rs(to.bf, line.bf); return;
  }

  close(fd[1]); 

  r = ndelay_on(fd[0]); if (r == -1) { strerr_die(1, "ndelay_on"); }
  pl.fd = fd[0]; pl.events = POLLIN;

  io_set(&in, read, fd[0], &bf[0], sizeof bf);
  r = polltimeout(&pl, 1, 4);
 
  if (r <= 0) {
    kill(p, SIGKILL);
    if (!str_PUTS(&line, "killed.\n")) strerr_sys(1);
    str_0(&line); say_thru_rs(to.bf, line.bf); return;
  }

  len = getln(&in, line.bf + line.p, '\n', line.n); line.p += len;
  if (len == -1) strerr_die(1, "getln"); if (len == 0) return;
  str_0(&to); str_0(&line); say_rs1(line.bf);
  
  close(fd[0]); str_unalloc(&to); str_unalloc(&line); 
  r = wait(0); if (r == -1) strerr_die(1, "wait"); return;
}
