#ifndef BNET_H
#define BNET_H

typedef struct {
  char name[NICKLEN+1]; 
  char from[NICKLEN+1]; 
  unsigned int u; 
  unsigned int b;
} robot;

typedef struct {
  char botn[NICKLEN+1];
  char name[NICKLEN+1]; 
  char chan[CHANLEN+1]; 
  char sock[8]; char flag[2];
} dude;

extern dude *bnet_dude_add();
extern robot *bnet_robot_add();
extern void bnet_status();

extern void bnet_get_ping();
extern void bnet_get_bye();
extern void bnet_get_chatter();
extern void bnet_get_join();
extern void bnet_get_part();
extern void bnet_get_link();
extern void bnet_get_unlink();
extern void bnet_get_who();
extern void bnet_get_idle();

extern void bnet_send_bye();
extern void bnet_send_el();
extern void bnet_send_join();
extern void bnet_send_priv();

extern void bnet_lout_nij();
extern void bnet_lout_elk();
extern void bnet_lout_thb();
extern void bnet_lout_ver();
extern void bnet_lout_hel();
extern void bnet_lout_pwd();

extern void bnet_lkin_ver();
extern void bnet_lkin_elk();
extern void bnet_auth_usr();
extern void bnet_auth_pwd();

#endif
