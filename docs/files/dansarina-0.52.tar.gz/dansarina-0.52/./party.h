#ifndef PARTY_H
#define PARTY_H

extern void prty_help();
extern void prty_nsense();
extern void prty_link();
extern void prty_unlink();

#endif
