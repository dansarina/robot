#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "strerr.h"
#include "scan.h"
#include "fmt.h"
#include "bnet.h"
#include "rw.h"
#include "peer.h"

/* see dansarina.c */
extern char myname[];

static void peer_auth_usr(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u;
  ln[--len] = 0; byte_copy(p->name, min(NICKLEN - 1, len), ln);

  if (!user_get(&u,p->name)) {
    say_2peer_str1(p, "I don't know you.\r\n"); 
    peer_detach(p); return;
  }

  p->stage |= PEER_AUTH_USR; 
  if (! user_has_flag(&u,'b')) return;
  p->stage |= PEER_INFO_BOT;

  if (u.p_1 == 0) {
    say_2peer_str1(p, "*hello!\r\n");
    p->stage |= PEER_LKIN_HEL | PEER_AUTH_PWD; return;
  }

  say_2peer_str1(p, "passreq\r\n");
}

static void peer_auth_pwd(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u;
   
  if (!user_get(&u,p->name)) {
    say_2peer_str1(p, "I don't know you, dude.\r\n"); 
    peer_detach(p); return;
  }

  if ( byte_cmp(u.pwd_1, min(u.p_1, len - 1), ln) ) { 
    say_2peer_str1(p, "Wrong password. Goodbye.\r\n"); 
    peer_detach(p); return;
  }

  p->stage |= PEER_AUTH_PWD; 
  if (peer_STAGE(p, PEER_INFO_BOT)) {
    p->stage |= PEER_LKIN_HEL;
    say_2peer_str1(p, "*hello!\r\n"); /* sigh */
  }

  bnet_send_join(p);
  say_peer_str3("+++ New peer. Welcome, ", p->name, ".\r\n");
}

static void peer_conn_prg(struct peer *p, char *ln, unsigned int len)
{
  struct sockaddr sa; unsigned int slen; int r; char c;
  
  /* see http://cr.yp.to/docs/connect.html */
  slen = sizeof sa; r = getpeername(p->poll->fd, &sa, &slen);
  
  if (r) {
    read(p->poll->fd, &c, 1); 
    say_peer_str5("*** Link to ", p->name, " failed (",
                  strerror(errno), ")\r\n"); 
    peer_detach(p); return;
  }

  p->stage &= ~PEER_CONN_PRG; p->stage |= PEER_CONN_RDY | PEER_LOUT_HEL;

  if ( peer_STAGE(p, PEER_INFO_BOT)) {
    say_2peer_str2(p, myname, "\r\n"); return;
  }
                                         
  if (! peer_STAGE(p, PEER_INFO_BOT)) {
    say_2peer_str1(p, "Banner. Welcome. User:\r\n"); return;
  }

}

void peer_auth(struct peer *p, char *ln, unsigned int len)
{
  peer_flags(p);

  if ( peer_STAGE(p, PEER_CONN_NOT)) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if ( peer_STAGE(p, PEER_CONN_PRG)) { peer_conn_prg(p, ln, len); return; }
  if ( peer_STAGE(p, PEER_LOUT_ELK)) { bnet_lout_elk(p, ln, len); return; }
  if ( peer_STAGE(p, PEER_LOUT_THB)) { bnet_lout_thb(p, ln, len); return; }
  if ( peer_STAGE(p, PEER_LOUT_VER)) { bnet_lout_ver(p, ln, len); return; } 
  if ( peer_STAGE(p, PEER_LOUT_HEL)) { bnet_lout_hel(p, ln, len); return; }
  if ( peer_STAGE(p, PEER_LOUT_PWD)) { bnet_lout_pwd(p, ln, len); return; }
  if (!peer_STAGE(p, PEER_AUTH_USR)) { peer_auth_usr(p, ln, len); return; }
  if (!peer_STAGE(p, PEER_AUTH_PWD)) { peer_auth_pwd(p, ln, len); return; }
  if (!peer_STAGE(p, PEER_LKIN_VER)) { bnet_lkin_ver(p, ln, len); return; }
  if (!peer_STAGE(p, PEER_LKIN_ELK)) { bnet_lkin_elk(p, ln, len); return; }

  strerr_die(1, "Wrong algorithm -> " ERRLINE);
}
