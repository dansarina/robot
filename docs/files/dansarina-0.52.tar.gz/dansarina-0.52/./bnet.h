#ifndef BNET_H
#define BNET_H

extern void bnet_get_ping();
extern void bnet_get_bye();
extern void bnet_get_chatter();
extern void bnet_get_join();
extern void bnet_get_part();
extern void bnet_get_link();
extern void bnet_get_unlink();
extern void bnet_get_who();

extern void bnet_send_bye();
extern void bnet_send_el();
extern void bnet_send_join();
extern void bnet_send_priv();

extern void bnet_lout_elk();
extern void bnet_lout_thb();
extern void bnet_lout_ver();
extern void bnet_lout_hel();
extern void bnet_lout_pwd();

extern void bnet_lkin_ver();
extern void bnet_lkin_elk();
extern void bnet_auth_usr();
extern void bnet_auth_pwd();

#endif
