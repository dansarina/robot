#ifndef PEER_H
#define PEER_H

#include "io.h"
#include "breakup.h"

#define LN_SIZE 512
#define PEERMAX 16

struct peer {
  char inb[IO_INSIZE];
  char oub[IO_OUTSIZE];
  io in;
  io ou;
  int cont; /* see peer_getln.c */
  int id; /* see peer_auth.c */
  char name[NICKLEN]; /* see peer_auth.c */
  int type; /* experimental */
};

extern void peer_set();
extern void peer_zero();
extern int peer_feed();
extern int peer_getln();
extern void peer_detach();
extern int peer_attach();
extern void peer_kick();
extern void peer_status();
extern void peer_auth();

#endif
