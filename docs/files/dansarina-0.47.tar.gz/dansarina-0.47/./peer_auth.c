#include <poll.h>
#include <unistd.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];

void peer_auth(unsigned int i, char *pass, unsigned int len)
{
  static struct urecord u; struct message m;
  byte_copy(m.nick,str0_len(user[i].name),user[i].name);

  if (!user_get(&u,&m)) {
    say_2peer_str1(&user[i], "Say hello first. /msg dansarina hello\r\n");
    close(conn[i].fd); conn[i].fd = -1; peer_detach(&user[i]);
    return;
  }

  if ( byte_cmp(u.pass.bf, min(u.pass.p,len), pass) ) { 
    say_2peer_str1(&user[i], "Wrong password. Goodbye.\r\n");
    close(conn[i].fd); conn[i].fd = -1; peer_detach(&user[i]);
    return;
  }

  user[i].id = 1; /* welcome peer */
  say_peer_str1("+++ New peer authenticated. Welcome, peer.\r\n");
}
