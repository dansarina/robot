#include <errno.h>
#include "io.h"
#include "strerr.h"
#include "socket.h"
#include "polltimeout.h"
#include "exit.h"
#include "peer.h"
#include "byte.h"
#include "ndelay.h"
#include "events.h"
#include "say.h"
#include "sig.h"

int poll_max; struct pollfd conn[PEERMAX]; 
struct peer user[PEERMAX]; struct peer rs;

int main()
{
  int sv; int nsocks; int r; int j; int i; int ir; char ln[LN_SIZE]; int len;

  /* init all peers */
  for (j=0; j < PEERMAX; ++j) { peer_zero(&user[j]); conn[j].fd = -1; }

  sv = socket_bind_reuse_listen(3333); if (sv == -1) strerr_sys(1);
  if (peer_attach(sv) == -1) strerr_die(1,"Can't attach peer\n");

  ir = socket_tcp(); if (ir == -1) strerr_sys(1);
  r = socket_connect_timeout(ir, "irc.dal.net",7000,5); 
  if (r == -1) strerr_sys(1); if (r == -2) strerr_sys(1);
  if (peer_attach(ir) == -1) strerr_die(1,"Can't attach peer\n"); rs = user[1];

  /* XXX: must check for possible IRC errors */
  say_rs("USER me 1 * :/msg dansarina hello\r\n");
  say_rs("NICK dansarina\r\n"); say_rs("JOIN #0xff\r\n");

  for (;;)
  {
    nsocks = polltimeout(conn, poll_max + 1, 60);

    if (nsocks == 0) { peer_status(); continue; }

    if (conn[0].revents & (POLLIN | POLLERR)) {
      r = socket_accept(sv); if (r < 0) strerr_sys(2);
      i = peer_attach(r); if (i == -1) continue; 

      /* XXX: could use i to set peer type to telnet */

      say_peer_str1("+++ New peer connected (telnet). Welcome, peer.\r\n"); 
      if (--nsocks <= 0) continue;
    }

    /* irc server only */
    if (conn[1].revents & (POLLIN | POLLERR)) {
      do {
        len = peer_getln(&rs, ln);
      
        if (len == -2) { break; }
        if (len == -1) strerr_sys(3);
        if (len ==  0) strerr_die(2,"Server closed.\n");
      
        if (!hub_dispatch(ln, len) ) { 
          io_put(io1, ln, len); io_flush(io1);
          say_peer_ln(ln, len);
        }

      } while (rs.in.p); /* buffer =/= empty */
    }

    /* peers */
    for (i=2; i <= poll_max; ++i)
      if (conn[i].revents & (POLLIN | POLLERR)) {
        do {
          len = peer_getln(&user[i], ln);
      
          if (len == -2) { break; }
          if (len == -1) { 
            peer_detach(&user[i]); conn[i].fd = -1;
            say_peer_str3("--- Peer parted (",strerror(errno),".)\r\n"); 
            break;
          }
          if (len ==  0) { 
            peer_detach(&user[i]); conn[i].fd = -1;
            say_peer_str1("--- Peer parted (EOF)\r\n"); 
            break;
          }

          if (! user[i].id) { peer_auth(i, ln, len); break; }

          say_party_ln(i, ln, len);
        } while (user[i].in.p); /* buffer =/= empty */
      }

    if (--nsocks <= 0) { continue; }
  }

}
