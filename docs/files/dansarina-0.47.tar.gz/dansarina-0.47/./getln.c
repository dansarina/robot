#include "getln.h"
#include "io.h"
#include "byte.h"

int getln(register io *s, register char *line, int sep)
{
  int r; int n; char *x;

  /* returns:
   * -1 error (io error)
   *  0 eof
   *  1 okay
   */

  for (;;)
  {
    r = io_feed(s);
    if (r <= 0) return r; /* eof or error */

    x = io_peek(s);
    n = byte_ndx(x, r, sep);

    if (n < r) /* sep found */
    { 
      byte_copy(line, n, x); /* copy n bytes from x to line */
      io_seek(s, n + 1); /* erase n + 1 bytes */
      *(line + n) = 0; /* close line */
      return 1;
    }

    /* else: don't know what to do */
    return 0;
  }

}
