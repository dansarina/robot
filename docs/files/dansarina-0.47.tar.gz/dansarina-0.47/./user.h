#ifndef USER_H
#define USER_H

#include <inttypes.h>

struct urecord {
  str nick;
  str host;
  str flag;
  str pass;
  uint32_t since; /* creation date */
  uint32_t seen; /* last time seen */
};

extern unsigned int user_count();
extern int user_exists();
extern int user_save();
extern int user_new();
extern int user_get();
extern int user_delete();

#endif
