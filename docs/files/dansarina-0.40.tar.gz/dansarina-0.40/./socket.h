#ifndef SOCKET_H
#define SOCKET_H

extern int socket_tcp(void);
extern int socket_bind_reuse_listen();
extern int socket_accept();
extern int socket_connect_host();
#endif
