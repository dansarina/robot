#include <stddef.h>
#include "peer.h"
#include "byte.h"
#include "io.h"
#include "rw.h"

void peer_set(register struct peer *p, register int fd) 
{
  io_set(&p->in,read,fd,&p->inb[0],sizeof p->inb);
  io_set(&p->ou,write,fd,&p->oub[0],sizeof p->oub);
}

void peer_zero(register struct peer *p)
{
  byte_zero(&p->inb[0], sizeof p->inb);
  byte_zero(&p->oub[0], sizeof p->oub);

  io_set(&p->in,read, -1,&p->inb[0],sizeof p->inb);
  io_set(&p->ou,write,-1,&p->oub[0],sizeof p->oub);
}
