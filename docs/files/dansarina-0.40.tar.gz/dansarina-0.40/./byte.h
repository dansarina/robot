#ifndef BYTE_H
#define BYTE_H

#include <stddef.h>

extern void byte_copy();
extern void byte_zero();
extern void byte_copy_r();
extern size_t byte_ndx();
extern void byte_ascii();

#endif
