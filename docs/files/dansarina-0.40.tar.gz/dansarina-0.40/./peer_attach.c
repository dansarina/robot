#include "peer.h"

void peer_attach(struct peer *p, int socket)
{
  peer_zero(p); peer_set(p, socket);
}
