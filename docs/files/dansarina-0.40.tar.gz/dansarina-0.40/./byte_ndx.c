#include <stddef.h>
#include "byte.h"

size_t byte_ndx(void *b, register size_t n, int c)
{
  register unsigned char *p;
  register unsigned char ch;

  p = b; ch = (unsigned char) c;

  for (;;) 
  {
    if (!n) break; if (*p == ch) break; ++p; --n;
    if (!n) break; if (*p == ch) break; ++p; --n;
    if (!n) break; if (*p == ch) break; ++p; --n;
    if (!n) break; if (*p == ch) break; ++p; --n;
  }
  
  return (size_t)((int)(unsigned int)p - (int)(unsigned int)b);
}
