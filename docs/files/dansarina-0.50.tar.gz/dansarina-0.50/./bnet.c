#include <unistd.h>
#include "io.h"
#include "say.h"
#include "peer.h"
#include "poll.h"
#include "scan.h"
#include "breakup.h"
#include "str.h"
#include "byte.h"
#include "min.h"
#include "sig.h"
#include "bnet.h"

/* see dansarina.c */
extern struct peer user[];
extern struct pollfd conn[];
extern int poll_max;
extern char myname[];

void bnet_get_unlink(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char gone[NICKLEN+1]; char why[64];

  byte_zero(gone, sizeof gone); byte_zero(why, sizeof why);

  s = ln; len = str0_len(s);
  n = scan_word(s, len, s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(gone, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }
  
  n = scan_line(why, min(len,sizeof(why)-1), s);

  say_peer_str7("--- Unlink: ", gone, " from ", p->name, 
                " (", why, ")\r\n");
}

void bnet_get_link(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char new[NICKLEN+1]; char hub[NICKLEN+1]; char why[64];

  byte_zero(new, sizeof new); 
  byte_zero(hub, sizeof hub);
  byte_zero(why, sizeof why);

  s = ln; len = str0_len(s);
  n = scan_word(s, len, s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(new, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(hub, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;

  if (*s) {
    n = scan_line(why, min(len,sizeof(why)-1), s); 
    s += n + 1; len -= n + 1;
  }

  say_peer_str7("+++ New link: ", new, " <- thru -> ", 
                hub, " (", why, ")\r\n"); 
}

void bnet_get_part(struct peer *p, char *ln)
{
  char *s; unsigned int n; char sock[8]; char why[LN_SIZE+1];
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(why, sizeof why);
  
  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(sock, min(len,8-1), s);
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_line(why, min(len, LN_SIZE), s);

  say_peer_str7("--- ", nick, "@", bot, " has left (", why, ")\r\n");
  
}

void bnet_get_join(struct peer *p, char *ln)
{
  char *s; unsigned int n; char flag; char sock[8]; char chan[8]; 
  char bot[NICKLEN+1]; char nick[NICKLEN+1]; unsigned int len;

  byte_zero(bot, sizeof bot); byte_zero(sock, sizeof sock);
  byte_zero(nick, sizeof nick); byte_zero(chan, sizeof chan);

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(bot, min(len,NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,8-1), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(chan, min(len,8-1), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(&flag, 1, s); ++s;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(sock, min(len,8-1), s);

  say_peer_str5("+++ ", nick, "@", bot, " has joined the partyline.\r\n");
}

void bnet_get_chatter(struct peer *p, char *ln)
{
  char *s; unsigned int n; unsigned int len;
  char nick[2*NICKLEN + 1]; /* u@bot */ char mesg[LN_SIZE];

  byte_zero(mesg, sizeof mesg); 
  byte_zero(nick, sizeof nick);

  s = ln; len = str0_len(s);

  n = scan_word(s, len, s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(nick, min(len,2*NICKLEN), s); 
  s += n + 1; len -= n + 1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_word(s, len, s); 
  s+= n + 1; len -= n +1;
  if (!*s) { bnet_send_bye(p, ln); return; }

  n = scan_line(mesg, min(len, sizeof(mesg) - 1), s); 
  say_peer_str5("<", nick, "> ", mesg, "\r\n");
}

void bnet_get_ping(struct peer *p, char *ln)
{
  io_puts(io1, "("); io_puts(io1, p->name); io_puts(io1, ") ");
  io_puts(io1, "pi? po! \n"); io_flush(io1);
  say_2peer_str1(p, "po\r\n");
}

void bnet_send_bye(struct peer *p, char *ln)
{
  say_2peer_str3(p, "bye (", ln, ")\r\n"); peer_detach(p);
}

void bnet_get_bye(struct peer *p, char *ln)
{
  io_puts(io1, "(botnet) bye from "); 
  io_puts(io1, p->name); io_puts(io1, "\n"); io_flush(io1);
  peer_detach(p);
}

void bnet_send_el(struct peer *p)
{
  int j; io *s; struct peer *g;
  s = &p->ou; /* linking bot's io */

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j];

    if (! peer_STAGE(g, PEER_AUTH_PWD)) continue;
    if (  peer_STAGE(g, PEER_INFO_BOT)) continue;

    io_puts(io1, "j !"); io_puts(io1, myname); io_puts(io1, " "); 
    io_puts(io1, g->name); io_puts(io1, " A @H "); 
    io_puts(io1, p->name); io_puts(io1, "@"); 
    io_puts(io1, myname); io_puts(io1,"\n"); io_flush(io1);

    io_puts(s, "j !"); io_puts(s, myname);  io_puts(s, " "); 
    io_puts(s, g->name); io_puts(s, " A @H "); 
    io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);
  }
  sig_pipedefault();

  say_2peer_str1(p, "el\r\n"); 
}

void bnet_send_join(struct peer *p)
{
  int j; io *s; struct peer *g;

  sig_pipeignore();

  for (j = 2; j <= poll_max; ++j) {
    g = &user[j]; s = &g->ou;
    if (! peer_STAGE(g, PEER_LINK_ELK)) continue;

    io_puts(s, "j "); io_puts(s, myname); io_puts(s, " ");
    io_puts(s, p->name); 
    io_puts(s, " A @H "); io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

    s = io1; /* debug */
    io_puts(s, "j "); io_puts(s, myname);  io_puts(s, " ");
    io_puts(s, p->name); 
    io_puts(s, " A @H "); io_puts(s, p->name); io_puts(s, "@"); 
    io_puts(s, myname); io_puts(s,"\n"); io_flush(s);

  }
  sig_pipedefault();
}
