#ifndef HANDLERS_H
#define HANDLERS_H

extern void gen_ping();
extern void gen_join();
extern void gen_quit();
extern void gen_part();
extern void gen_error();

extern void priv_help();
extern void priv_hello();
extern void priv_pass();

extern void ctcp_chat();
extern void ctcp_version();
extern void ctcp_source();
extern void ctcp_ping();

#endif
