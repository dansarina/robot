#ifndef PEER_H
#define PEER_H

#include "io.h"
#include "breakup.h"
#include "poll.h"

#define LN_SIZE 512
#define PEERMAX 16

#define PEER_CONN_NOT 0x0001
#define PEER_CONN_PRG 0x0002
#define PEER_CONN_RDY 0x0004
#define PEER_AUTH_USR 0x0008
#define PEER_AUTH_PWD 0x0010
#define PEER_INFO_BOT 0x0100
#define PEER_LINK_HEL 0x0200
#define PEER_LINK_VER 0x0400
#define PEER_LINK_ELK 0x0800
#define PEER_LINK_RDY 0x1000

#define peer_STAGE(u,x) ((u)->stage & (x))

struct peer {
  char inb[LN_SIZE]; char oub[LN_SIZE]; struct pollfd *poll;
  io in; io ou; int cont; /* see peer_getln.c */
  char name[NICKLEN]; unsigned long stage; /* see peer_auth.c */
  int version; int nlength;
};

extern void peer_set();
extern void peer_zero();
extern int peer_feed();
extern int peer_getln();
extern void peer_detach();
extern struct peer * peer_attach();
extern void peer_kick();
extern void peer_status();
extern void peer_auth();

#endif
