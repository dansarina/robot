#include <poll.h>
#include <unistd.h>
#include "byte.h"
#include "say.h"
#include "min.h"
#include "str.h"
#include "user.h"
#include "strerr.h"
#include "breakup.h"
#include "scan.h"
#include "fmt.h"
#include "bnet.h"
#include "peer.h"

extern int poll_max;
extern struct pollfd conn[];
extern struct peer user[];

void peer_auth(struct peer *p, char *ln, unsigned int len)
{
  struct urecord u; struct message m; char *s; unsigned int n; 
  char bf[32]; char fmt[32]; uint32_t v; uint32_t nlength;

  byte_zero(&m, sizeof m); byte_zero(&u, sizeof u);

  if ( peer_STAGE(p, PEER_CONN_NOT) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if ( peer_STAGE(p, PEER_CONN_PRG) ) {
    strerr_die(1, "Stage not operational " ERRLINE);
  }

  if (! peer_STAGE(p, PEER_AUTH_USR) ) {
    byte_copy(m.nick, min(NICKLEN - 1, len - 1), ln);
    byte_copy(p->name, min(NICKLEN - 1, len - 1), ln);
    p->stage |= PEER_AUTH_USR; 

    if (!user_get(&u,m.nick)) {
      say_2peer_str1(p, "I don't know you.\r\n"); peer_detach(p);
      return;
    }

    if ( ! user_has_flag(&u,'b')) return;

    p->stage |= PEER_INFO_BOT;

    if (u.pn == 0) {
      say_2peer_str1(p, "*hello!\r\n");
      p->stage |= PEER_LINK_HEL | PEER_AUTH_PWD; return;
    }

    return; /* never */
  }

  if (! peer_STAGE(p, PEER_AUTH_PWD) ) {
    byte_copy(m.nick, str0_len(p->name), p->name);
    
    if (!user_get(&u,m.nick)) {
      say_2peer_str1(p, "I don't know you, dude.\r\n"); peer_detach(p);
      return;
    }

    if ( byte_cmp(u.pass, min(u.pn, len - 1), ln) ) { 
      say_2peer_str1(p, "Wrong password. Goodbye.\r\n"); peer_detach(p);
      return;
    }

    p->stage |= PEER_AUTH_PWD; bnet_send_join(p);
    say_peer_str3("+++ New peer. Welcome, ", p->name, ".\r\n");
    return;
  }

  /* bot related only */

  if (! peer_STAGE(p, PEER_LINK_VER) ) {
    if ( !peer_STAGE(p, PEER_LINK_HEL) ) 
      strerr_die(1, "Needs VER, but has no HEL" ERRLINE);

    if ( byte_cmp("version", min(7,len), ln) ) {
      say_2peer_str1(p, "bye (expected version command)\r\n"); 
      peer_detach(p); return;
    }
    
    s = ln;

    n = scan_word(bf, 32, s); s += n; ++s;
    n = scan_uint32(s, &v); s += n; ++s;
    
    if (!n || v < 1061700) {
      say_2peer_str1(p, "bye (unsupported version)\r\n");
      peer_detach(p); return;
    }
    
    p->version = v;
    
    n = scan_uint32(s, &nlength); s += n; ++s;

    if (!n || nlength > NICKLEN) {
      say_2peer_str1(p, "bye (unsupported nick length)\r\n");
      peer_detach(p); return;
    }
    
    p->nlength = nlength;

    bf [ fmt_uint32(bf, v) ] = 0; fmt [ fmt_uint32(fmt, nlength) ] = 0;
    say_2peer_str5(p,"version ", bf," ",fmt," dansarina 0.49 <DAL.net>\r\n");

    p->stage |= PEER_LINK_VER; 
    return;
  }

  if (! peer_STAGE(p, PEER_LINK_ELK) ) {
    /* ignore everything, but el */
    if ( byte_cmp("el", min(2,len), ln) ) return;

    p->stage |= PEER_LINK_ELK; bnet_send_el(p);
    return;
  }

  strerr_die(1, "Wrong algorithm -> " ERRLINE);
}
