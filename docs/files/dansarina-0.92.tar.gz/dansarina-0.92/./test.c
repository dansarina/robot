#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
int main() {

  const char *ipstr = "64.109.150.120";
  struct in_addr ip;
  struct hostent *hp;
  
  if (!inet_aton(ipstr, &ip))
  {
    printf("can't parse IP address %s\r\n", ipstr);
    exit(0);
  }
  
  if ((hp = gethostbyaddr((const char *)&ip,
                          sizeof ip, AF_INET)) == NULL)
  {
    printf("no name associated with %s\r\n", ipstr);
    exit(0);
  }
  
  printf("name associated with %s is %s\n", ipstr, hp->h_name);
}
