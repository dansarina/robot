#ifndef READONCE_H
#define READONCE_H

#include <unistd.h>
extern ssize_t read_once(int f, char *buf, size_t len);

#endif
