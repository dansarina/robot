#ifndef HANDLERS_H
#define HANDLERS_H

extern void gen_ping(register char *buffer);
extern void gen_topic(register char *buffer);
extern void gen_join(register char *buffer);
extern void do_something(struct message *m);
extern void gen_quit(register char *buffer);
extern void gen_part(register char *buffer);
extern void gen_privmsg(register char *buffer);
extern void gen_error(register char *buffer);

extern void priv_help(register char *buffer);
extern void priv_hello(register char *buffer);

extern void ctcp_chat(register char *buffer);
extern void ctcp_version(register char *buffer);
extern void ctcp_finger(register char *buffer);
extern void ctcp_source(register char *buffer);
extern void ctcp_ping(register char *buffer);

#define min(s,p) (s) <= (p) ? (s) : (p)

#endif
