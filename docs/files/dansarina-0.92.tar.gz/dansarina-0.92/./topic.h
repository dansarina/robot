#ifndef TOPIC_H
#define TOPIC_H

#include <time.h> /* time_t */
#include "message.h"

#define DB_TOPIC_LEN PARALEN + NICKLEN + 512 /* to make sure */

/* stores a topic entry from db/topics.db */
struct topic_entry
{
  char channel[PARALEN];
  char nick[NICKLEN];
  time_t time;
  char topic[512];
};

extern void topic_history(struct message *m);
extern void get_topic_entry(struct topic_entry *e, char *line);
extern void topic_append(struct message *m);

#endif
