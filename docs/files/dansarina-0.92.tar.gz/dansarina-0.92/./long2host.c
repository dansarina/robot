#include <stdio.h>
#include <errno.h>
#include "ipnet2dot.h"

int main()
{

  char name[256];

  ipnet2dot(&name[0],255,3373513962UL);
  printf("%s\r\n",name);

  ipnet2dot(&name[0],255,1080923768UL);
  printf("%s\r\n",name);

  exit(0);
}
