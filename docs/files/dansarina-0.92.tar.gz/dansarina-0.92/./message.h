#ifndef MESSAGE_H
#define MESSAGE_H

#define NICKLEN 16 /* RFC says 9 minimum */
#define USERLEN 16 /* RFC says what? */
#define HOSTLEN 64 /* RFC says what? */
#define COMMLEN 32 /* RFC says what? */
#define PARALEN 32 /* RFC says what? */
#define TEXTLEN 512 

struct message 
{
  char nick[NICKLEN];
  char user[USERLEN];
  char host[HOSTLEN];
  char para[PARALEN];
  char text[TEXTLEN];
};

#endif
