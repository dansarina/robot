#include <string.h>
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>  /* sys/socket.h needs it */
#include <sys/socket.h> /* AF_INET */
#include <sys/param.h>  /* ntohl() */
#include "ipnet2dot.h"

void ipnet2dot(char *dst, size_t size, unsigned long ip)
{
  struct hostent *hp; unsigned char *p; u_long ipn; 

  ipn = ntohl(ip); /* network order */
  hp = gethostbyaddr((char*)& ipn, sizeof(ipn), AF_INET);
  if (!hp) 
  { /* no name associated, copy one by one */
    p = (unsigned char*) &ipn;
    snprintf(dst,size,"%u.%u.%u.%u",p[0],p[1],p[2],p[3]);
  }

  /* all fine, just copy size bytes */
  else {strncpy(dst,hp->h_name,size);}
}
