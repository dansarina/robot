#include <stdio.h>
#include <string.h> /* strtok */
#include <stdlib.h> /* free */
#include "xxx_io.h"
#include "events.h"
#include "read_once.h"
#include "lines.h"
#include "strjoin.h"
#include "fatal.h"

extern int irc_socket;

void doit()
{
  char readbuffer[RD_SIZE]; 

  size_t free_bytes; ssize_t read_bytes; 
  char *position; unsigned int n_lines;
  
  char *piece; /* points to &readbuffer[i] for some i */
  unsigned int last_len;

  free_bytes = RD_SIZE - 1; 
  position = &readbuffer[0];

  buffer_again: 
  read_bytes = read_once(irc_socket, position, free_bytes); 

  if (read_bytes < 0) 
  { /* error ocurred */
    perror("read_once");
    fatal1("doit: unrecoverable\r\n");
  }

  if (read_bytes == 0)
  { /* server closed */
    printf("This really shouldn't happen.\r\n"); exit(0);
  }

  free_bytes = free_bytes - read_bytes;  

  /* if no whole line was received */
  n_lines = how_many_lines(readbuffer);
  if (n_lines < 1) 
  { 
    position = &readbuffer[0] + read_bytes;

    if( free_bytes <= 0) free_bytes = RD_SIZE - 1;
    goto buffer_again;
  }

  piece = strtok (readbuffer, "\r\n");

  while (piece) 
  {
    if ( n_lines-- <= 0 ) 
    { 
      position = handle_last_line(readbuffer,piece,&last_len);
      free_bytes = RD_SIZE - 1 - last_len;
      goto buffer_again;
    }
    printf ("### %s\n", piece);
    hub_dispatch_event(piece); /* general table of events */
    piece = strtok (NULL, "\r\n");
  }
}

char * handle_last_line(char *buffer,char *piece,int *len) 
{
   unsigned int slen; register char *new;
   slen = strlen(piece);
  
   /* take a copy, must free */
   new = strjoin1(piece);

   memset(buffer, 0, slen);
   strncpy(buffer, new, slen + 1); free(new);

   *len = slen;
   return buffer + slen;
}


