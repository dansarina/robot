#ifndef LIST_H
#define LIST_H

typedef struct list_e_ {
  void *data;
  struct list_e_ *prev;
  struct list_e_ *next;
} list_e;

typedef struct list_ {
  int           size;
  void          (*destroy)(void *data);
  list_e        *head;
  list_e        *tail;
} list;

void list_init(list *_list, void (*destroy)(void *data));
int list_i_next(list *_list, list_e *e, const void *data);
int list_delete(list *_list, list_e *e, void **data);
void list_destroy(list *_list);

#endif
