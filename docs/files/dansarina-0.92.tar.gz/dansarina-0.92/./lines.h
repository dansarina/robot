#ifndef LINES_H
#define LINES_H

extern unsigned int how_many_lines(register char *s);
extern void line_append(char *path, char *line);

#endif
