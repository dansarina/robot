#include <stdio.h>
#include <errno.h>
#include <stdlib.h> /* free */
#include "say.h"
#include "topic.h"
#include "list.h"
#include "fatal.h"
#include "strjoin.h"
#include "lines.h"

extern FILE* irc_out;

void topic_history(struct message *m)
{
  FILE *file; 
  char line[DB_TOPIC_LEN]; 
  char *copy;
  struct topic_entry entry; 
  list topics; 
  list_e *e;
  int i;

  file = fopen("./db/topics.db","r");
  if (!file)
  {
    if (errno == ENOENT)
    {
      say_channel_to(m,"I know nothing about that.");
      return;
    }
    perror("fopen");
    fatal1("topic_history: fopen\r\n");
  }

  say_channel_to(m,"as far as I remember, they were:");
  list_init(&topics, free);

  /* loads all topics into a linked list */
  i = 0;
  while ( fgets(line,DB_TOPIC_LEN,file) )
  { /* load each line on list */
    copy = strjoin1(line);
    if ( list_i_next(&topics, topics.tail, copy) )
      fatal1("topics_history: loading line\r\n");
  }

  fclose(file);

  /* start from the tail, print 5 last */
  e = topics.tail;
  while ( e )
  {
    if (++i > 5) break;
    get_topic_entry(&entry,(char*)e->data);
    fprintf(irc_out,"PRIVMSG #%s :By %s @ %s. %s\r\n",
            m->para, entry.nick, "time", entry.topic);
    fflush(irc_out); e = e->prev;
  }

  /* free all malloc'ed memory */
  list_destroy(&topics);
}

void get_topic_entry(struct topic_entry *e,
                     char *line)
{
  register char *p; register int i; char time[30];
  p = line; i = 0; 

  /* load channel */ i = 0;
  while( *p && *p != ' ' && i < (PARALEN - 1))
    e->channel[i++] = *p++;
  e->channel[i] = 0; ++p; /* skip space */

  /* load nick */ i = 0;
  while( *p && *p != ' ' && i < (NICKLEN - 1))
    e->nick[i++] = *p++;
  e->nick[i] = 0; ++p; /* skip space */

  /* load time in time[] */ i = 0;
  while( *p && *p != ' ' && i < 30)
    time[i++] = *p++;
  time[i] = 0; ++p; /* skip space */

  /* skip colon */ ++p;

  /* load topic */ i = 0;
  while( *p && i < (512 - 1))
    e->topic[i++] = *p++;
  e->topic[i] = 0;
}

void topic_append(struct message *m)
{
  char topic[DB_TOPIC_LEN];
  time_t t;

  t = time(NULL);

  snprintf(topic, DB_TOPIC_LEN, "%s %s %ld %s\r\n",
           m->para, m->nick, t, m->text);
  line_append("./db/topics.db",topic);
}

