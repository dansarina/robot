#ifndef FATAL_H
#define FATAL_H

#define fatal9(str) fatal( (str), 9)
#define fatal8(str) fatal( (str), 8)
#define fatal6(str) fatal( (str), 6)
#define fatal2(str) fatal( (str), 2)
#define fatal1(str) fatal( (str), 1)
#define fatal0(str) fatal( (str), 0)

extern void fatal(char *s, int e);

#endif
