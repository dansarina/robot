#ifndef DCC_BUFFER_H
#define DCC_BUFFER_H

#define RD_SIZE 8192

extern int dcc_buffer(unsigned int socket);

#endif
