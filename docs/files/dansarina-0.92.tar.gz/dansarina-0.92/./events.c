#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include "events.h"
#include "handlers.h"
#include "message.h"
#include "parse.h"

event general[] = 
{
  { "PING",     gen_ping        },
  { "TOPIC",    gen_topic       },
  { "JOIN",     gen_join        },
  { "QUIT",     gen_quit        },
  { "PART",     gen_part        },
  { "PRIVMSG",  gen_privmsg     },
  { "ERROR",    gen_error       },
  { 0,          0               }
};

event priv[] =
{
  { "HELP",     priv_help       },
  { "HELLO",    priv_hello      },
  { 0,          0               }
};

event ctcp[] =
{
  { "SOURCE",   ctcp_source     },
  { "PING",     ctcp_ping       },
  { "VERSION",  ctcp_version    },
  { "FINGER",   ctcp_finger     },
  { "DCC CHAT", ctcp_chat       },
  { 0,          0               }
};

event *find(event table[], register char *item) 
{
  int i;

  for (i=0; table[i].name; ++i) 
  {
    if ( !strncmp(item, table[i].name, strlen(table[i].name) ))
      return &table[i];
  }

  return 0;
}

void hub_dispatch_event(register char *b) 
{
  event *handler; register int i; struct message m;
  register char *t; char command[COMMLEN]; event *table;

  t = b; i = 0;

  if( *t == ':') { /* foreign */
      while (*t && *++t != ' ');
      ++t;      
  }

  /* load command */
  while( *t && *t != ' ' && i < (COMMLEN - 1)) 
    command[i++] = *t++;
  command[i] = 0;

  /* default table is general */
  table = general;

  if ( !strncmp(&command[0],"PRIVMSG",7) )
  { /* parse and look for CTCP/DCC */
    parse_common(&m,b); 
    
    t = &m.text[1]; /* skip colon */

    /* XXX: not really the proper way to handle CTCP messages */
    /* XXX: CTCP messages may come ANYWHERE in an IRC message */
    /* XXX: here, we expect it contained in its single line   */

    if (*t == 1) 
    { i = 0; ++t; table = ctcp;
      while( *t && *t != ' ' && i < (COMMLEN - 1)) 
        command[i++] = *t++;
      command[i] = 0;

      if ( !strncmp(&command[0],"DCC",3) )
      { /* append next word */ command[i++] = *t++;
        while( *t && *t != ' ' && i < (COMMLEN - 1 - strlen(command))) 
          command[i++] = *t++;
        command[i] = 0;
      }
    }
    else
    { /* just a privage message */ table = priv; i=0;
      while( *t && *t != ' ' && i < (COMMLEN - 1)) 
        command[i++] = *t++;
      command[i] = 0;
    }
  }

  /* find handler */
  handler = find(table,command);

  if( !handler ) {
    printf("--- %s\r\n",b);
    return;
  }

  /* dispatch event */
  (*handler->f)(b);
}
